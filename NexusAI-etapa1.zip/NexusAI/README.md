# NEXUS AI (Android, Kotlin + Compose)

Asistente personal con IA para Galaxy Note 9 (Android 10, ARM64).

## Estado por etapas
| Etapa | Contenido | Estado |
|---|---|---|
| 1 | Estructura, tema AMOLED/violeta, núcleo animado, navegación, pantallas | Funciona en dispositivo |
| 2 | Chat + IA en la nube (Retrofit + backend propio) | Pendiente |
| 3 | SpeechRecognizer + TextToSpeech (español) | Pendiente |
| 4 | Room + DataStore + motor offline | Pendiente |
| 5 | Intents: abrir apps, volumen, brillo | Pendiente |
| 6 | Pruebas, optimización, APK | Pendiente |

## Requisitos
- Android Studio Koala o superior, JDK 17.
- Dispositivo con Depuración USB activada, o emulador API 29+.

## Abrir y ejecutar
1. Descomprime y abre la carpeta `NexusAI` en Android Studio.
2. Espera a que Gradle sincronice (si falta `gradle-wrapper.jar`, Studio lo resuelve
   con `gradle-wrapper.properties`; si no, ejecuta `gradle wrapper --gradle-version 8.7`).
3. Conecta el Note 9 y pulsa **Run**.
4. APK: `Build > Build APK(s)` (debug) o `Build > Generate Signed Bundle / APK` (release).

## Claves de API
Nunca van en la app. Desde la Etapa 2 la app llamará a tu backend por HTTPS,
y es el backend quien guarda la clave de Claude.

## Pendiente conocido
- Ícono de lanzador provisional (usa el del sistema).
- Los ajustes aún no persisten (DataStore en Etapa 4).

## Compilar el APK sin Android Studio (GitHub Actions)
1. Crea un repositorio en github.com y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** > **Build APK** > **Run workflow**.
3. Al terminar (~5-8 min), abre la ejecución y descarga **nexus-ai-debug-apk** (Artifacts).
4. Descomprime, copia `app-debug.apk` al Note 9 y ábrelo (permite "instalar apps desconocidas").

## Etapa 2: IA en la nube (dos modos)
- **Directo:** la app llama a Gemini con la clave pegada en Ajustes (DataStore, solo en el teléfono).
- **Backend:** si hay token, la app usa el Worker de `backend/worker.js` (la clave vive en Cloudflare).
- Selección automática: `ai/HybridAiProvider.kt`. Proveedor intercambiable: `ai/AiProvider.kt`.
- Al reinstalar una nueva compilación debug, desinstala antes la anterior (la firma cambia).

## v0.2.0
- Logo minimalista (vector) + ícono adaptable de la app.
- Historial de chats con Room (abrir, borrar, nuevo chat).
- Reintentos automáticos y cambio de modelo si Gemini está saturado (503) o no disponible (404).
- Markdown básico, botón copiar, indicador de escritura, animaciones de entrada.
- Se quitaron del menú de Ajustes los controles que aún no hacían nada (memoria, voz); vuelven con sus etapas.
