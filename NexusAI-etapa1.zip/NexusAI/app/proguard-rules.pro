# Reglas R8 (se ampliarán en etapas 2 y 4)
