package com.nexus.ai.data

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

data class GPart(val text: String? = null)
data class GContent(val role: String? = null, val parts: List<GPart>? = null)
data class GRequest(val systemInstruction: GContent, val contents: List<GContent>)
data class GCandidate(val content: GContent? = null)
data class GResponse(val candidates: List<GCandidate>? = null)

interface GeminiApi {
    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    suspend fun generate(
        @Header("x-goog-api-key") key: String,
        @Body body: GRequest
    ): GResponse
}
