package com.nexus.ai.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.util.launchAssistant
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Actúa cuando NEXUS lo pide desde el chat y, si el usuario lo activa en Ajustes,
 * detecta el doble toque de los botones de volumen para abrir el asistente en cualquier app.
 * No procesa eventos de pantalla por su cuenta.
 */
class NexusAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NexusAccessibilityService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var volumeTrigger = false
    private var lastCode = 0
    private var lastDown = 0L
    private var swallowUp = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        scope.launch {
            SettingsRepo(applicationContext).prefs.collect { volumeTrigger = it.volumeTrigger }
        }
    }

    /** Doble toque en Vol+ o Vol−: abre NEXUS. Un toque normal sigue ajustando el volumen. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!volumeTrigger) return false
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (event.action == KeyEvent.ACTION_UP) {
            if (swallowUp == code) {
                swallowUp = 0
                return true
            }
            return false
        }
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false
        val now = SystemClock.uptimeMillis()
        if (code == lastCode && now - lastDown in 1..350) {
            lastCode = 0
            lastDown = 0
            swallowUp = code
            // El primer toque ya movió el volumen un paso: se deshace para que el gesto sea neutro.
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.adjustSuggestedStreamVolume(
                if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE,
                AudioManager.USE_DEFAULT_STREAM_TYPE, 0
            )
            launchAssistant(this, vibrate = true)
            return true
        }
        lastCode = code
        lastDown = now
        return false
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: String): Boolean = when (action) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        "screenshot" -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        else -> false
    }

    fun readScreen(maxChars: Int = 3500): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        collect(root, out, maxChars)
        return out.toString().trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: StringBuilder, max: Int) {
        if (node == null || out.length >= max) return
        if (node.isPassword) return // nunca se lee contenido de campos de contraseña
        if (node.isVisibleToUser) {
            val t = node.text?.toString() ?: node.contentDescription?.toString()
            if (!t.isNullOrBlank()) {
                out.append(t.trim().take(200))
                if (node.isClickable) out.append(" [botón]")
                out.append('\n')
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, max)
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 6) {
                if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                cur = cur.parent
                depth++
            }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        if (target.isPassword) return false // no se escribe en campos de contraseña
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return node.performAction(action)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }
}
