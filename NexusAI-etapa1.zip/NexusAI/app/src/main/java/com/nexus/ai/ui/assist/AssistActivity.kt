package com.nexus.ai.ui.assist

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.MainActivity
import com.nexus.ai.ui.chat.ACTION_PREFIX
import com.nexus.ai.ui.chat.ATTACH_PREFIX
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.chat.IMAGE_PREFIX
import com.nexus.ai.ui.components.AiCore
import com.nexus.ai.ui.components.CoreState
import com.nexus.ai.ui.components.rememberMicGate
import com.nexus.ai.ui.components.renderMarkdown
import com.nexus.ai.ui.theme.NexusTheme
import com.nexus.ai.voice.VoiceEngine

/**
 * Panel flotante de NEXUS: se abre sobre cualquier app (doble volumen, botón de asistente,
 * mosaico de Ajustes rápidos o acceso directo) y conversa por voz sin abrir la app completa.
 */
class AssistActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()
    private var invocation by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexusTheme(darkTheme = true) {
                AssistPanel(vm, invocation, onClose = { finish() }, onOpenApp = {
                    startActivity(
                        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    finish()
                })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        invocation++
    }

    override fun onStop() {
        super.onStop()
        // Si el usuario sale del panel (Inicio, otra app), se deja de escuchar y de hablar.
        vm.stopVoiceChat()
        val micOk = androidx.core.content.ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        // Mientras el diálogo del permiso está abierto no se cierra el panel.
        if (micOk && !isChangingConfigurations) finish()
    }
}

@Composable
private fun AssistPanel(vm: ChatViewModel, invocation: Int, onClose: () -> Unit, onOpenApp: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val vState by vm.voiceState.collectAsStateWithLifecycle()
    val active by vm.voiceActive.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val err by vm.voiceError.collectAsStateWithLifecycle()
    val chat by vm.state.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    var shown by remember { mutableStateOf(false) }

    val gate = rememberMicGate { vm.startVoiceChat() }
    LaunchedEffect(invocation) {
        shown = true
        vm.newChat()
        gate()
    }

    val lastReply = chat.messages.lastOrNull {
        !it.fromUser && !it.text.startsWith(ACTION_PREFIX) &&
            !it.text.startsWith(IMAGE_PREFIX) && !it.text.startsWith(ATTACH_PREFIX)
    }?.text.orEmpty()
    val lastAction = chat.messages.lastOrNull { it.text.startsWith(ACTION_PREFIX) }
        ?.text?.removePrefix(ACTION_PREFIX).orEmpty()

    val core = when {
        chat.thinking -> CoreState.THINKING
        vState == VoiceEngine.State.LISTENING -> CoreState.LISTENING
        vState == VoiceEngine.State.SPEAKING -> CoreState.SPEAKING
        else -> CoreState.IDLE
    }
    val status = when {
        chat.thinking -> chat.status ?: "Pensando…"
        vState == VoiceEngine.State.LISTENING -> "Te escucho…"
        vState == VoiceEngine.State.SPEAKING -> "Hablando…"
        active -> "Un momento…"
        else -> "Toca el micrófono para hablar"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClose
            ),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = shown,
            enter = slideInVertically(tween(320)) { it } + fadeIn(tween(320)),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(220))
        ) {
            Surface(
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = cs.surface.copy(alpha = 0.97f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                Column(
                    Modifier.navigationBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AiCore(core, Modifier.size(110.dp))
                    Text(status, style = MaterialTheme.typography.titleSmall, color = cs.tertiary)
                    if (partial.isNotBlank()) {
                        Text(
                            "“$partial”",
                            color = cs.onSurface,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (chat.thinking && lastAction.isNotBlank()) {
                        Text(lastAction, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    if (lastReply.isNotBlank()) {
                        Box(Modifier.heightIn(max = 220.dp).fillMaxWidth()) {
                            Text(
                                renderMarkdown(lastReply, Color.Transparent),
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurface,
                                modifier = Modifier.verticalScroll(rememberScrollState())
                            )
                        }
                    }
                    err?.let {
                        Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                    chat.error?.let {
                        Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Filled.Close, contentDescription = "Cerrar", tint = cs.onSurfaceVariant)
                        }
                        FilledIconButton(
                            onClick = {
                                if (chat.thinking) vm.stop()
                                else if (active) vm.stopVoiceChat() else gate()
                            },
                            modifier = Modifier.size(60.dp)
                        ) {
                            Icon(
                                if (chat.thinking || active) Icons.Filled.Stop else Icons.Filled.Mic,
                                contentDescription = if (active) "Detener" else "Hablar"
                            )
                        }
                        IconButton(onClick = onOpenApp) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Abrir NEXUS", tint = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.answerPending(false) },
            title = { Text("NEXUS quiere actuar") },
            text = { Text(p.description) },
            confirmButton = { TextButton(onClick = { vm.answerPending(true) }) { Text("Permitir") } },
            dismissButton = { TextButton(onClick = { vm.answerPending(false) }) { Text("Cancelar") } }
        )
    }
}
