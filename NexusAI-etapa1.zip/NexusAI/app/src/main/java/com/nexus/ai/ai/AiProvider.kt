package com.nexus.ai.ai

import com.nexus.ai.data.ChatTurn

/** Abstracción del proveedor de IA: backend propio, Gemini directo, y mañana Claude u otro. */
interface AiProvider {
    suspend fun reply(history: List<ChatTurn>): Result<String>
}

sealed class AiError(message: String) : Exception(message) {
    object NotConfigured : AiError("Falta configurar la IA. Ve a Ajustes y pega tu clave de Gemini.")
    object InvalidUrl : AiError("La URL del backend debe empezar con https://")
    object Unauthorized : AiError("Token incorrecto. Revísalo en Ajustes.")
    object InvalidKey : AiError("La clave de Gemini no es válida. Revísala en Ajustes.")
    object Quota : AiError("Límite gratuito alcanzado. Intenta de nuevo en un minuto.")
    object ModelNotFound : AiError("Gemini no encontró ningún modelo disponible para tu clave (404).")
    object Network : AiError("No se pudo conectar. Revisa tu internet.")
    class Server(msg: String) : AiError("Error: $msg")
}
