package com.nexus.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceOption(val name: String, val label: String)

/**
 * Reconocimiento de voz (SpeechRecognizer) y síntesis (TextToSpeech) en español.
 * Es un singleton: lo comparten el chat, la pantalla de voz y los ajustes.
 */
class VoiceEngine private constructor(private val ctx: Context) {

    enum class State { IDLE, LISTENING, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _voices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val voices: StateFlow<List<VoiceOption>> = _voices.asStateFlow()

    /** Se llama (en el hilo principal) cuando termina de hablar. */
    var onSpeakDone: (() -> Unit)? = null

    /** Se llama cuando el reconocimiento falla o no oyó nada. */
    var onListenFailed: (() -> Unit)? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var resultHandler: ((String) -> Unit)? = null

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _state.value = State.LISTENING
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(errorCode: Int) {
            _state.value = State.IDLE
            _partial.value = ""
            when (errorCode) {
                SpeechRecognizer.ERROR_CLIENT -> {}
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    _error.value = "No te escuché. Intenta de nuevo."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    _error.value = "Falta el permiso del micrófono."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    _error.value = "Sin conexión para reconocer la voz."
                else -> _error.value = "No se pudo escuchar (código $errorCode)."
            }
            onListenFailed?.invoke()
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            _state.value = State.IDLE
            _partial.value = ""
            if (text.isNotBlank()) resultHandler?.invoke(text.trim()) else onListenFailed?.invoke()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull().orEmpty()
            if (t.isNotBlank()) _partial.value = t
        }
    }

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                for (l in listOf(Locale("es", "MX"), Locale("es", "ES"), Locale("es"))) {
                    val r = t.setLanguage(l)
                    if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) break
                }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == LAST_ID) finishSpeaking()
                    }

                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onError(utteranceId: String?) {
                        finishSpeaking()
                    }
                })
                ttsReady = true
                refreshVoices()
            } else {
                _error.value = "No se pudo iniciar la voz del teléfono."
            }
        }
    }

    private fun refreshVoices() {
        val list = try {
            tts?.voices.orEmpty()
                .filter { it.locale.language == "es" }
                .sortedBy { it.name }
                .map {
                    val place = it.locale.displayCountry.ifBlank { it.locale.language }
                    val kind = if (it.isNetworkConnectionRequired) "en línea" else "sin conexión"
                    VoiceOption(it.name, "$place · $kind · ${it.name.takeLast(14)}")
                }
        } catch (e: Exception) {
            emptyList()
        }
        _voices.value = list
    }

    private fun finishSpeaking() {
        main.post {
            _state.value = State.IDLE
            onSpeakDone?.invoke()
        }
    }

    fun clearError() {
        _error.value = null
    }

    /** Empieza a escuchar. El resultado final llega a [onResult]. Debe llamarse en el hilo principal. */
    fun listen(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            _error.value = "Este teléfono no tiene reconocimiento de voz disponible."
            onListenFailed?.invoke()
            return
        }
        stopSpeaking()
        _error.value = null
        resultHandler = onResult
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val lang = if (Locale.getDefault().language == "es") Locale.getDefault().toLanguageTag() else "es-ES"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        _partial.value = ""
        _state.value = State.LISTENING
        r.startListening(intent)
    }

    /** Termina de escuchar y entrega lo que se alcanzó a oír. */
    fun finishListening() {
        recognizer?.stopListening()
    }

    /** Cancela sin entregar nada. */
    fun cancelListening() {
        recognizer?.cancel()
        if (_state.value == State.LISTENING) _state.value = State.IDLE
        _partial.value = ""
    }

    fun speak(raw: String, rate: Float, pitch: Float, voiceName: String) {
        val t = tts
        if (t == null || !ttsReady) {
            _error.value = "La voz aún no está lista."
            return
        }
        val text = cleanForSpeech(raw)
        if (text.isBlank()) return
        cancelListening()
        t.setSpeechRate(rate.coerceIn(0.3f, 3f))
        t.setPitch(pitch.coerceIn(0.3f, 2f))
        if (voiceName.isNotBlank()) {
            t.voices?.firstOrNull { it.name == voiceName }?.let { t.setVoice(it) }
        }
        val chunks = chunk(text, 3500)
        chunks.forEachIndexed { i, c ->
            val id = if (i == chunks.lastIndex) LAST_ID else "nexus_part_$i"
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
        _state.value = State.SPEAKING
    }

    /** Detiene la voz sin disparar [onSpeakDone]. */
    fun stopSpeaking() {
        tts?.stop()
        if (_state.value == State.SPEAKING) _state.value = State.IDLE
    }

    private fun chunk(text: String, max: Int): List<String> {
        if (text.length <= max) return listOf(text)
        val out = mutableListOf<String>()
        var rest = text
        while (rest.length > max) {
            var cut = maxOf(rest.lastIndexOf('.', max), rest.lastIndexOf(' ', max))
            if (cut <= 0) cut = max
            out.add(rest.substring(0, cut).trim())
            rest = rest.substring(cut).trim()
        }
        if (rest.isNotBlank()) out.add(rest)
        return out
    }

    companion object {
        private const val LAST_ID = "nexus_last"

        @Volatile
        private var instance: VoiceEngine? = null

        fun get(context: Context): VoiceEngine = instance ?: synchronized(this) {
            instance ?: VoiceEngine(context.applicationContext).also { instance = it }
        }

        /** Quita Markdown, código, enlaces y emojis para que suene natural al leerlo. */
        fun cleanForSpeech(src: String): String {
            var s = src.replace(Regex("```[\\s\\S]*?```"), " Te dejé el código en pantalla. ")
            s = s.replace(Regex("`([^`]*)`"), "\$1")
            s = s.replace(Regex("https?://\\S+"), " enlace ")
            s = s.replace(Regex("(?m)^\\s*[-•]\\s+"), "")
            s = s.replace(Regex("[*#>|~]"), "")
            s = s.replace(Regex("[\\p{So}\\p{Sk}]"), "")
            s = s.replace(Regex("\\s+"), " ").trim()
            if (s.length > 1500) {
                val cut = s.lastIndexOf('.', 1500)
                s = if (cut > 300) s.substring(0, cut + 1) else s.substring(0, 1500)
            }
            return s
        }
    }
}
