package com.nexus.ai.ai

import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.SettingsRepo
import kotlinx.coroutines.flow.first

/** Si hay token de backend usa el backend; si no, usa la clave directa de Gemini. */
class HybridAiProvider(
    private val backend: AiProvider,
    private val direct: AiProvider,
    private val settings: SettingsRepo
) : AiProvider {
    override suspend fun reply(history: List<ChatTurn>): Result<String> {
        val c = settings.config.first()
        return when {
            c.token.isNotBlank() -> backend.reply(history)
            c.geminiKey.isNotBlank() -> direct.reply(history)
            else -> Result.failure(AiError.NotConfigured)
        }
    }
}
