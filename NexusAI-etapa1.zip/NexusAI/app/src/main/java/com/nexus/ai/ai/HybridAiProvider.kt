package com.nexus.ai.ai

import android.content.Context
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.util.isOnline
import kotlinx.coroutines.flow.first

/**
 * Enruta cada petición:
 *  - LOCAL: solo el modelo del teléfono (privacidad total).
 *  - CLOUD: solo nube (backend o Gemini).
 *  - AUTO: nube si hay conexión y clave; si no hay red, la nube está saturada o no configurada,
 *    cae al modelo local cuando existe.
 */
class HybridAiProvider(
    private val ctx: Context,
    private val backend: AiProvider,
    private val direct: AiProvider,
    private val local: LocalAiProvider,
    private val settings: SettingsRepo
) : AiProvider {

    private suspend fun cloud(history: List<ChatTurn>, options: AiOptions): Result<String> {
        val c = settings.config.first()
        return when {
            c.token.isNotBlank() -> backend.reply(history, options)
            c.geminiKey.isNotBlank() -> direct.reply(history, options)
            else -> Result.failure(AiError.NotConfigured)
        }
    }

    override suspend fun reply(history: List<ChatTurn>, options: AiOptions): Result<String> {
        val route = settings.prefs.first().route
        if (route == "LOCAL") return local.reply(history, options)
        if (route == "CLOUD") return cloud(history, options)

        val hasLocal = local.isAvailable()
        val needsMedia = history.lastOrNull()?.media != null
        if (!isOnline(ctx)) {
            return if (hasLocal && !needsMedia) local.reply(history, options)
            else Result.failure(if (needsMedia && hasLocal) AiError.LocalNoMedia else AiError.Network)
        }
        val r = cloud(history, options)
        if (r.isSuccess || !hasLocal || needsMedia) return r
        val e = r.exceptionOrNull()
        val recoverable = e === AiError.Network || e === AiError.Busy || e === AiError.Quota ||
            e === AiError.NotConfigured || e === AiError.ModelNotFound
        return if (recoverable) local.reply(history, options) else r
    }
}
