package com.nexus.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.ui.chat.ACTION_PREFIX
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.chat.IMAGE_PREFIX
import com.nexus.ai.ui.components.AiCore
import com.nexus.ai.ui.components.CoreState
import com.nexus.ai.ui.components.rememberMicGate
import com.nexus.ai.ui.components.renderMarkdown
import com.nexus.ai.voice.VoiceEngine

/** Conversación manos libres: escucha, piensa, responde en voz alta y vuelve a escuchar. */
@Composable
fun VoiceScreen(vm: ChatViewModel) {
    val vState by vm.voiceState.collectAsStateWithLifecycle()
    val active by vm.voiceActive.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val err by vm.voiceError.collectAsStateWithLifecycle()
    val chat by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    val lastReply = chat.messages.lastOrNull {
        !it.fromUser && !it.text.startsWith(ACTION_PREFIX) && !it.text.startsWith(IMAGE_PREFIX)
    }?.text.orEmpty()

    val gate = rememberMicGate { vm.startVoiceChat() }
    DisposableEffect(Unit) {
        onDispose { vm.stopVoiceChat() }
    }

    val core = when {
        chat.thinking -> CoreState.THINKING
        vState == VoiceEngine.State.LISTENING -> CoreState.LISTENING
        vState == VoiceEngine.State.SPEAKING -> CoreState.SPEAKING
        else -> CoreState.IDLE
    }
    val status = when {
        chat.thinking -> "Pensando…"
        vState == VoiceEngine.State.LISTENING -> "Escuchando…"
        vState == VoiceEngine.State.SPEAKING -> "Hablando…"
        active -> "Un momento…"
        else -> "Toca el micrófono para conversar"
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AiCore(core, Modifier.size(200.dp))
        Text(status, style = MaterialTheme.typography.titleMedium, color = cs.tertiary)
        if (partial.isNotBlank()) {
            Text(
                "“$partial”",
                style = MaterialTheme.typography.bodyLarge,
                color = cs.onSurface,
                textAlign = TextAlign.Center
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Text(
                renderMarkdown(lastReply, Color.Transparent),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                modifier = Modifier.verticalScroll(rememberScrollState())
            )
        }
        err?.let {
            Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
        LargeFloatingActionButton(
            onClick = { if (active) vm.stopVoiceChat() else gate() },
            containerColor = cs.primary
        ) {
            Icon(if (active) Icons.Filled.Stop else Icons.Filled.Mic, contentDescription = if (active) "Terminar" else "Hablar")
        }
    }
}
