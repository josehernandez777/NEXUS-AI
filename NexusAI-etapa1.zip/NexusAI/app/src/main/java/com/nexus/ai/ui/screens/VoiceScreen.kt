package com.nexus.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.AiCore
import com.nexus.ai.ui.components.CoreState

/** ETAPA 1: solo UI. El reconocimiento y la síntesis de voz reales llegan en la Etapa 3. */
@Composable
fun VoiceScreen() {
    var listening by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterVertically)
    ) {
        AiCore(if (listening) CoreState.LISTENING else CoreState.IDLE, Modifier.size(260.dp))
        Text(
            if (listening) "Escuchando…" else "Toca para hablar",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.tertiary
        )
        LargeFloatingActionButton(
            onClick = { listening = !listening },
            containerColor = MaterialTheme.colorScheme.primary
        ) { Icon(Icons.Filled.Mic, contentDescription = "Hablar") }
    }
}
