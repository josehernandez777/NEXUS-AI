package com.nexus.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.ui.chat.ChatMessage
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.components.NexusLogo
import com.nexus.ai.ui.components.TypingDots
import com.nexus.ai.ui.components.renderMarkdown
import kotlinx.coroutines.delay

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val total = state.messages.size + (if (state.thinking) 1 else 0) + (if (state.error != null) 1 else 0)

    LaunchedEffect(total) {
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexusLogo(Modifier.size(36.dp), animated = false)
            Text(
                "NEXUS",
                style = MaterialTheme.typography.titleLarge,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
            IconButton(onClick = { vm.newChat() }) {
                Icon(Icons.Filled.Add, contentDescription = "Nuevo chat")
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(state.messages, key = { _, m -> m.id }) { index, m ->
                    MessageRow(m, animate = index == state.messages.lastIndex)
                }
                if (state.thinking) {
                    item(key = "typing") { TypingBubble() }
                }
                state.error?.let { err ->
                    item(key = "error") { ErrorBubble(err, onRetry = { vm.retry() }) }
                }
            }
            if (state.messages.isEmpty() && !state.thinking && state.error == null) {
                EmptyState(onPick = { vm.send(it) })
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe a NEXUS…") },
                shape = RoundedCornerShape(24.dp),
                maxLines = 4
            )
            FilledIconButton(
                onClick = { vm.send(input); input = "" },
                enabled = input.isNotBlank() && !state.thinking
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar") }
        }
    }
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NexusLogo(Modifier.size(150.dp))
        Spacer(Modifier.height(16.dp))
        Text("Hola, soy NEXUS", style = MaterialTheme.typography.headlineSmall)
        Text(
            "¿En qué te ayudo hoy?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        listOf("Ayúdame a planear mi día", "Explícame algo en simple", "Dame una idea creativa").forEach {
            SuggestionPill(it) { onPick(it) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SuggestionPill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        text,
        color = MaterialTheme.colorScheme.tertiary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, MaterialTheme.colorScheme.outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    )
}

@Composable
private fun MessageRow(m: ChatMessage, animate: Boolean) {
    if (animate) {
        val visible = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = visible,
            enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 4 }
        ) { MessageContent(m) }
    } else {
        MessageContent(m)
    }
}

@Composable
private fun MessageContent(m: ChatMessage) {
    val mine = m.fromUser
    val cs = MaterialTheme.colorScheme
    val shape = if (mine) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
    else RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = shape,
            color = if (mine) cs.primary else cs.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            if (mine) {
                Text(
                    m.text,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    color = cs.onPrimary
                )
            } else {
                val codeBg = cs.background.copy(alpha = 0.6f)
                val styled = remember(m.text) { renderMarkdown(m.text, codeBg) }
                Text(
                    styled,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    color = cs.onSurface
                )
            }
        }
        if (!mine) CopyButton(m.text)
    }
}

@Composable
private fun CopyButton(text: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    IconButton(
        onClick = { clipboard.setText(AnnotatedString(text)); copied = true },
        modifier = Modifier.size(32.dp)
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = "Copiar",
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TypingBubble() {
    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        TypingDots(Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
    }
}

@Composable
private fun ErrorBubble(message: String, onRetry: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
            TextButton(onClick = onRetry) { Text("Reintentar") }
        }
    }
}
