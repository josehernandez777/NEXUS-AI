package com.nexus.ai.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.ai.AiMode
import com.nexus.ai.ui.chat.ACTION_PREFIX
import com.nexus.ai.ui.chat.ATTACH_PREFIX
import com.nexus.ai.ui.chat.ChatMessage
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.chat.IMAGE_PREFIX
import com.nexus.ai.ui.components.CodeBlock
import com.nexus.ai.ui.components.CodeBlockView
import com.nexus.ai.ui.components.NexusLogo
import com.nexus.ai.ui.components.TextBlock
import com.nexus.ai.ui.components.TypingDots
import com.nexus.ai.ui.components.parseBlocks
import com.nexus.ai.ui.components.rememberMicGate
import com.nexus.ai.ui.components.renderMarkdown
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Purple700
import com.nexus.ai.ui.theme.Violet500
import com.nexus.ai.util.saveToGallery
import com.nexus.ai.util.shareImage
import com.nexus.ai.voice.VoiceEngine
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val voiceState by vm.voiceState.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val voiceError by vm.voiceError.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    var input by remember { mutableStateOf("") }
    var attach by remember { mutableStateOf<Uri?>(null) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attach = uri
    }
    val listState = rememberLazyListState()
    val total = state.messages.size + (if (state.thinking) 1 else 0) + (if (state.error != null) 1 else 0)
    val listening = voiceState == VoiceEngine.State.LISTENING

    val micGate = rememberMicGate {
        vm.dictate { text -> input = (input + " " + text).trim() }
    }

    LaunchedEffect(total) {
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexusLogo(Modifier.size(36.dp), animated = false)
            Text(
                "NEXUS",
                style = MaterialTheme.typography.titleLarge,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
            IconButton(onClick = { vm.newChat() }) {
                Icon(Icons.Filled.Add, contentDescription = "Nuevo chat")
            }
        }
        ModeRow(mode) { vm.setMode(it) }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(state.messages, key = { _, m -> m.id }) { index, m ->
                    MessageRow(
                        m,
                        animate = index == state.messages.lastIndex,
                        typewriter = m.id == state.liveId,
                        onSpeak = { vm.speak(it) }
                    )
                }
                if (state.thinking) {
                    item(key = "typing") { TypingBubble(state.status) }
                }
                state.error?.let { err ->
                    item(key = "error") { ErrorBubble(err, onRetry = { vm.retry() }) }
                }
            }
            if (state.messages.isEmpty() && !state.thinking && state.error == null) {
                EmptyState(onPick = { vm.send(it) })
            }
        }

        voiceError?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }

        AnimatedVisibility(visible = attach != null, enter = fadeIn(tween(200)), exit = fadeOut(tween(150))) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📎 Imagen lista para enviar", color = MaterialTheme.colorScheme.tertiary)
                    IconButton(onClick = { attach = null }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Quitar imagen", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = { pickImage.launch("image/*") }) {
                Icon(
                    Icons.Filled.Image,
                    contentDescription = "Adjuntar imagen",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        if (listening) "Escuchando… $partial" else if (attach != null) "Pregunta sobre la imagen…" else "Escribe a NEXUS…",
                        maxLines = 1
                    )
                },
                shape = RoundedCornerShape(24.dp),
                maxLines = 5
            )
            IconButton(onClick = { if (listening) vm.finishListening() else micGate() }) {
                Icon(
                    if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = if (listening) "Terminar de dictar" else "Dictar",
                    tint = if (listening) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Crossfade(targetState = state.thinking, animationSpec = tween(200), label = "sendstop") { busy ->
                if (busy) {
                    FilledIconButton(onClick = { vm.stop() }) {
                        Icon(Icons.Filled.Stop, contentDescription = "Detener")
                    }
                } else {
                    FilledIconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val img = attach
                            if (img != null) vm.sendWithImage(input, img) else vm.send(input)
                            input = ""
                            attach = null
                        },
                        enabled = input.isNotBlank() || attach != null
                    ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar") }
                }
            }
        }
    }
}

@Composable
private fun ModeRow(selected: AiMode, onSelect: (AiMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AiMode.entries.forEach { m ->
            ModePill(m.label, selected = m == selected) { onSelect(m) }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    val base = Modifier.clip(shape)
    val styled = if (selected) base.background(Brush.linearGradient(listOf(Violet500, Magenta)))
    else base.border(1.dp, cs.outline.copy(alpha = 0.5f), shape)
    Text(
        label,
        color = if (selected) Color.White else cs.onSurfaceVariant,
        style = MaterialTheme.typography.labelLarge,
        modifier = styled.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NexusLogo(Modifier.size(150.dp))
        Spacer(Modifier.height(16.dp))
        Text("Hola, soy NEXUS", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Pregúntame, créame código, imágenes o pídeme que use tu teléfono.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        listOf(
            "Crea una imagen de un lobo neón en la ciudad",
            "Abre YouTube y busca música lo-fi",
            "Escríbeme una app de notas en Kotlin"
        ).forEach {
            SuggestionPill(it) { onPick(it) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SuggestionPill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        text,
        color = MaterialTheme.colorScheme.tertiary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, MaterialTheme.colorScheme.outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    )
}

@Composable
private fun MessageRow(m: ChatMessage, animate: Boolean, typewriter: Boolean, onSpeak: (String) -> Unit) {
    if (animate) {
        val visible = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = visible,
            enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 4 }
        ) { MessageContent(m, typewriter, onSpeak) }
    } else {
        MessageContent(m, false, onSpeak)
    }
}

@Composable
private fun MessageContent(m: ChatMessage, typewriter: Boolean, onSpeak: (String) -> Unit) {
    when {
        m.text.startsWith(ACTION_PREFIX) -> ActionChip(m.text)
        m.text.startsWith(IMAGE_PREFIX) -> ImageBubble(m.text)
        m.text.startsWith(ATTACH_PREFIX) -> AttachBubble(m.text)
        m.fromUser -> UserBubble(m.text)
        else -> AssistantBubble(m, typewriter, onSpeak)
    }
}

@Composable
private fun UserBubble(text: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                .background(Brush.linearGradient(listOf(Violet500, Purple700, Magenta.copy(alpha = 0.9f))))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text, color = Color.White)
        }
    }
}

@Composable
private fun AttachBubble(text: String) {
    val body = text.removePrefix(ATTACH_PREFIX)
    val path = body.substringBefore('\n')
    val caption = body.substringAfter('\n', "")
    val bmp by produceState<ImageBitmap?>(initialValue = null, path) {
        value = withContext(Dispatchers.IO) { decodeImage(path) }
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                .background(Brush.linearGradient(listOf(Violet500, Purple700, Magenta.copy(alpha = 0.9f))))
                .padding(6.dp)
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = "Imagen adjunta",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(it.width.toFloat() / it.height.toFloat())
                        .clip(RoundedCornerShape(14.dp))
                )
            }
            if (caption.isNotBlank()) {
                Text(caption, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun ActionChip(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = cs.tertiary.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, cs.tertiary.copy(alpha = 0.25f))
    ) {
        Text(
            text,
            color = cs.tertiary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

private fun decodeImage(path: String): ImageBitmap? {
    val f = File(path)
    if (!f.exists()) return null
    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
    return BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
}

@Composable
private fun ImageBubble(text: String) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val body = text.removePrefix(IMAGE_PREFIX)
    val path = body.substringBefore('\n')
    val caption = body.substringAfter('\n', "")
    val loaded by produceState(initialValue = Pair<ImageBitmap?, Boolean>(null, false), path) {
        val bmp = withContext(Dispatchers.IO) { decodeImage(path) }
        value = Pair(bmp, true)
    }
    val bmp = loaded.first

    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = cs.surfaceVariant.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.25f)),
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column {
            when {
                bmp != null -> Image(
                    bitmap = bmp,
                    contentDescription = caption,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                )
                loaded.second -> Text(
                    "La imagen ya no está disponible.",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
                else -> Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            if (caption.isNotBlank()) {
                Text(
                    caption,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            if (bmp != null) {
                Row {
                    TextButton(onClick = {
                        val uri = saveToGallery(ctx, File(path))
                        Toast.makeText(
                            ctx,
                            if (uri != null) "Guardada en Imágenes/NEXUS" else "No se pudo guardar",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) { Text("Guardar") }
                    TextButton(onClick = { shareImage(ctx, File(path)) }) { Text("Compartir") }
                }
            }
        }
    }
}

@Composable
private fun AssistantBubble(m: ChatMessage, typewriter: Boolean, onSpeak: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var shown by remember(m.id) { mutableIntStateOf(if (typewriter) 0 else m.text.length) }
    LaunchedEffect(m.id, typewriter) {
        if (typewriter) {
            val step = maxOf(5, m.text.length / 150)
            while (shown < m.text.length) {
                shown = minOf(m.text.length, shown + step)
                delay(16)
            }
        } else {
            shown = m.text.length
        }
    }
    val visible = m.text.take(shown)
    val blocks = remember(visible) { parseBlocks(visible) }
    val codeBg = cs.background.copy(alpha = 0.6f)

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
            color = cs.surfaceVariant.copy(alpha = 0.92f),
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.25f)),
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Column(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                blocks.forEach { b ->
                    when (b) {
                        is TextBlock -> {
                            if (b.md.isNotBlank()) {
                                Text(renderMarkdown(b.md.trimEnd(), codeBg), color = cs.onSurface)
                            }
                        }
                        is CodeBlock -> {
                            CodeBlockView(b.lang, b.code)
                        }
                    }
                }
            }
        }
        if (shown >= m.text.length) {
            Row {
                CopyButton(m.text)
                IconButton(onClick = { onSpeak(m.text) }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Leer en voz alta",
                        modifier = Modifier.size(16.dp),
                        tint = cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CopyButton(text: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    IconButton(
        onClick = { clipboard.setText(AnnotatedString(text)); copied = true },
        modifier = Modifier.size(32.dp)
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = "Copiar",
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TypingBubble(status: String?) {
    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TypingDots()
            Crossfade(targetState = status, animationSpec = tween(300), label = "status") { st ->
                if (st != null) {
                    Text(
                        st,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ErrorBubble(message: String, onRetry: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
            TextButton(onClick = onRetry) { Text("Reintentar") }
        }
    }
}
