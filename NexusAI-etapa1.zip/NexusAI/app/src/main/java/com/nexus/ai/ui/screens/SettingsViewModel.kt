package com.nexus.ai.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.data.BackendConfig
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.UiPrefs
import com.nexus.ai.data.db.NexusDb
import com.nexus.ai.voice.VoiceEngine
import com.nexus.ai.voice.VoiceOption
import java.io.File
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()
    private val engine = VoiceEngine.get(app)

    val config: StateFlow<BackendConfig?> =
        repo.config.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val prefs: StateFlow<UiPrefs> =
        repo.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, UiPrefs())

    val voices: StateFlow<List<VoiceOption>> = engine.voices

    fun save(url: String, token: String, geminiKey: String) {
        viewModelScope.launch { repo.save(BackendConfig(url, token, geminiKey)) }
    }

    fun setConfirm(value: Boolean) { viewModelScope.launch { repo.setConfirm(value) } }
    fun setAurora(value: Boolean) { viewModelScope.launch { repo.setAurora(value) } }
    fun setVoice(name: String) { viewModelScope.launch { repo.setVoice(name) } }
    fun setRate(value: Float) { viewModelScope.launch { repo.setRate(value) } }
    fun setPitch(value: Float) { viewModelScope.launch { repo.setPitch(value) } }
    fun setAutoSpeak(value: Boolean) { viewModelScope.launch { repo.setAutoSpeak(value) } }

    fun previewVoice() {
        val p = prefs.value
        engine.speak("Hola, soy NEXUS. Así es como sueno.", p.rate, p.pitch, p.voiceName)
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.deleteAll()
            File(getApplication<Application>().filesDir, "images").deleteRecursively()
        }
    }
}
