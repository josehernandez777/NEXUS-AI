package com.nexus.ai.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.data.BackendConfig
import com.nexus.ai.data.SettingsRepo
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    val config: StateFlow<BackendConfig?> =
        repo.config.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun save(url: String, token: String, geminiKey: String) {
        viewModelScope.launch { repo.save(BackendConfig(url, token, geminiKey)) }
    }
}
