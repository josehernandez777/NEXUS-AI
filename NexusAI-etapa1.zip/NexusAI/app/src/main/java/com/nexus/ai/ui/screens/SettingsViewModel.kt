package com.nexus.ai.ui.screens

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.data.BackendConfig
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.UiPrefs
import com.nexus.ai.ai.LocalAiProvider
import com.nexus.ai.data.db.MemoryEntity
import com.nexus.ai.data.db.NexusDb
import com.nexus.ai.memory.MemoryStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import com.nexus.ai.voice.VoiceEngine
import com.nexus.ai.voice.VoiceOption
import java.io.File
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()
    private val engine = VoiceEngine.get(app)
    private val memoryDao = NexusDb.get(app).memoryDao()
    private val memoryStore = MemoryStore(memoryDao)

    val memories: StateFlow<List<MemoryEntity>> =
        memoryDao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _modelMsg = MutableStateFlow<String?>(null)
    /** Mensaje de estado de la importación del modelo local. */
    val modelMsg: StateFlow<String?> = _modelMsg.asStateFlow()

    val config: StateFlow<BackendConfig?> =
        repo.config.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val prefs: StateFlow<UiPrefs> =
        repo.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, UiPrefs())

    val voices: StateFlow<List<VoiceOption>> = engine.voices

    fun save(url: String, token: String, geminiKey: String) {
        viewModelScope.launch { repo.save(BackendConfig(url, token, geminiKey)) }
    }

    fun setConfirm(value: Boolean) { viewModelScope.launch { repo.setConfirm(value) } }
    fun setAurora(value: Boolean) { viewModelScope.launch { repo.setAurora(value) } }
    fun setVoice(name: String) { viewModelScope.launch { repo.setVoice(name) } }
    fun setRate(value: Float) { viewModelScope.launch { repo.setRate(value) } }
    fun setPitch(value: Float) { viewModelScope.launch { repo.setPitch(value) } }
    fun setAutoSpeak(value: Boolean) { viewModelScope.launch { repo.setAutoSpeak(value) } }

    fun setRoute(value: String) { viewModelScope.launch { repo.setRoute(value) } }
    fun setMemoryOn(value: Boolean) { viewModelScope.launch { repo.setMemoryOn(value) } }
    fun setVolumeTrigger(value: Boolean) { viewModelScope.launch { repo.setVolumeTrigger(value) } }
    fun setDynamicColor(value: Boolean) { viewModelScope.launch { repo.setDynamicColor(value) } }

    fun addMemory(text: String) {
        viewModelScope.launch { memoryStore.remember(text, "manual") }
    }
    fun deleteMemory(id: Long) { viewModelScope.launch { memoryDao.delete(id) } }
    fun clearMemory() { viewModelScope.launch { memoryDao.deleteAll() } }

    /** Copia el modelo .task elegido al almacenamiento privado de la app. */
    fun importModel(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _modelMsg.value = "Copiando el modelo… (puede tardar un minuto)"
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    var name = "modelo.task"
                    var size = -1L
                    app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val si = c.getColumnIndex(OpenableColumns.SIZE)
                            if (ni >= 0) name = c.getString(ni) ?: name
                            if (si >= 0) size = c.getLong(si)
                        }
                    }
                    require(name.endsWith(".task") || name.endsWith(".bin") || name.endsWith(".litertlm")) {
                        "el archivo debe ser un modelo .task (Gemma para MediaPipe)"
                    }
                    val dir = LocalAiProvider.modelDir(app)
                    if (size > 0) require(dir.usableSpace > size + 200_000_000L) { "no hay espacio suficiente" }
                    dir.listFiles()?.forEach { it.delete() }
                    val dest = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    app.contentResolver.openInputStream(uri)!!.use { input ->
                        dest.outputStream().use { input.copyTo(it, 1 shl 16) }
                    }
                    dest.absolutePath
                }
            }
            result.onSuccess {
                repo.setLocalModel(it)
                _modelMsg.value = "Modelo local listo ✓"
            }.onFailure {
                _modelMsg.value = "No se pudo importar: " + (it.message ?: "error")
            }
        }
    }

    fun removeModel() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LocalAiProvider.modelDir(getApplication()).listFiles()?.forEach { it.delete() } }
            repo.setLocalModel("")
            _modelMsg.value = "Modelo local eliminado"
        }
    }

    fun previewVoice() {
        val p = prefs.value
        engine.speak("Hola, soy NEXUS. Así es como sueno.", p.rate, p.pitch, p.voiceName)
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.deleteAll()
            File(getApplication<Application>().filesDir, "images").deleteRecursively()
            File(getApplication<Application>().filesDir, "attachments").deleteRecursively()
        }
    }
}
