package com.nexus.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Purple700
import com.nexus.ai.ui.theme.Violet300
import com.nexus.ai.ui.theme.Violet500

enum class CoreState { IDLE, LISTENING, THINKING, SPEAKING }

/** Núcleo animado de la IA. Su ritmo cambia según el estado. */
@Composable
fun AiCore(state: CoreState, modifier: Modifier = Modifier.size(220.dp)) {
    val spin = when (state) {
        CoreState.IDLE -> 8000
        CoreState.LISTENING -> 3500
        CoreState.THINKING -> 1200
        CoreState.SPEAKING -> 2200
    }
    val pulseMs = when (state) {
        CoreState.IDLE -> 2800
        CoreState.LISTENING -> 1200
        CoreState.THINKING -> 700
        CoreState.SPEAKING -> 500
    }
    val t = rememberInfiniteTransition(label = "core")
    val rotation by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(spin, easing = LinearEasing)), label = "rot"
    )
    val pulse by t.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(tween(pulseMs), RepeatMode.Reverse), label = "pulse"
    )

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(
            brush = Brush.radialGradient(listOf(Violet500.copy(alpha = 0.45f), Color.Transparent), c, r),
            radius = r * pulse, center = c
        )
        val coreR = r * 0.48f
        drawCircle(
            brush = Brush.radialGradient(listOf(Violet300, Violet500, Purple700), c, coreR),
            radius = coreR * pulse, center = c
        )
        val ring = r * 0.78f
        rotate(rotation, pivot = c) {
            val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            val tl = Offset(c.x - ring, c.y - ring)
            val sz = Size(ring * 2, ring * 2)
            drawArc(Magenta, 0f, 80f, false, tl, sz, style = stroke)
            drawArc(Violet300, 180f, 80f, false, tl, sz, style = stroke)
        }
    }
}
