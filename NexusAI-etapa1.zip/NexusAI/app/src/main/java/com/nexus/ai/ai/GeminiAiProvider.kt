package com.nexus.ai.ai

import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.GContent
import com.nexus.ai.data.GPart
import com.nexus.ai.data.GRequest
import com.nexus.ai.data.GeminiApi
import com.nexus.ai.data.SettingsRepo
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import retrofit2.HttpException

private const val SYSTEM =
    "Eres NEXUS, un asistente personal. Responde siempre en español, de forma clara y breve."

/** Modo directo: la app llama a Gemini con la clave que el usuario pegó en Ajustes. */
class GeminiAiProvider(
    private val api: GeminiApi,
    private val settings: SettingsRepo
) : AiProvider {

    override suspend fun reply(history: List<ChatTurn>): Result<String> {
        val key = settings.config.first().geminiKey.trim()
        if (key.isEmpty()) return Result.failure(AiError.NotConfigured)
        val contents = toContents(history)
        if (contents.isEmpty()) return Result.failure(AiError.Server("mensaje vacío"))
        return try {
            val res = api.generate(key, GRequest(GContent(null, listOf(GPart(SYSTEM))), contents))
            val text = res.candidates?.firstOrNull()?.content?.parts
                ?.joinToString("") { it.text ?: "" }
            if (text.isNullOrBlank()) Result.failure(AiError.Server("Gemini no devolvió texto"))
            else Result.success(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            when (e.code()) {
                400, 401, 403 -> Result.failure(AiError.InvalidKey)
                429 -> Result.failure(AiError.Quota)
                else -> Result.failure(AiError.Server("HTTP ${e.code()}"))
            }
        } catch (e: IOException) {
            Result.failure(AiError.Network)
        } catch (e: Exception) {
            Result.failure(AiError.Server("respuesta no válida"))
        }
    }

    /** Gemini exige alternar user/model, empezando por user: unimos turnos seguidos del mismo rol. */
    private fun toContents(history: List<ChatTurn>): List<GContent> {
        val out = mutableListOf<Pair<String, StringBuilder>>()
        for (t in history) {
            val role = if (t.role == "assistant") "model" else "user"
            val text = t.content.take(4000)
            if (text.isBlank()) continue
            val last = out.lastOrNull()
            if (last != null && last.first == role) last.second.append("\n").append(text)
            else out.add(role to StringBuilder(text))
        }
        while (out.isNotEmpty() && out.first().first != "user") out.removeAt(0)
        return out.map { GContent(it.first, listOf(GPart(it.second.toString()))) }
    }
}
