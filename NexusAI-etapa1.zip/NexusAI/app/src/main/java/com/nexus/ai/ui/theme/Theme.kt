package com.nexus.ai.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// Oscuro AMOLED pulido: negro real de fondo y capas de superficie violetas muy sutiles
// para que las tarjetas se distingan sin brillar.
private val DarkColors = darkColorScheme(
    primary = Violet500,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2A1B52),
    onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = Magenta,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF3A1546),
    onSecondaryContainer = Color(0xFFFBD7FF),
    tertiary = Violet300,
    onTertiary = Color(0xFF1B0B3D),
    background = AmoledBlack,
    onBackground = Color(0xFFEDE9FE),
    surface = SurfaceDark,
    onSurface = Color(0xFFEDE9FE),
    surfaceVariant = SurfaceDark2,
    onSurfaceVariant = Violet300,
    surfaceTint = Violet500,
    outline = Color(0xFF4B3C75),
    outlineVariant = Color(0xFF2B2145),
    error = Color(0xFFFF8A95),
    errorContainer = Color(0xFF3B1219),
    onErrorContainer = Color(0xFFFFD9DD),
    surfaceContainerLowest = AmoledBlack,
    surfaceContainerLow = Color(0xFF0A0712),
    surfaceContainer = Color(0xFF110C1D),
    surfaceContainerHigh = Color(0xFF181226),
    surfaceContainerHighest = Color(0xFF201833),
)

private val LightColors = lightColorScheme(
    primary = Purple700,
    onPrimary = Color.White,
    secondary = Magenta,
    tertiary = Violet500,
    background = LightBg,
    surface = Color.White,
    surfaceVariant = Color(0xFFEDE5FF),
    onSurfaceVariant = Purple700,
    outline = Color(0xFFB7A6E6),
)

private val NexusShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun NexusTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamic: Boolean = false,
    content: @Composable () -> Unit
) {
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(ctx).copy(background = AmoledBlack)
            else dynamicLightColorScheme(ctx)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = scheme, shapes = NexusShapes, content = content)
}
