package com.nexus.ai.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)
data class ChatUiState(val messages: List<ChatMessage> = emptyList(), val thinking: Boolean = false)

/**
 * ETAPA 1: solo gestiona el estado de la UI.
 * La respuesta es un texto temporal; en la ETAPA 2 se sustituye por AiProvider (Retrofit + backend).
 */
class ChatViewModel : ViewModel() {
    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    private var nextId = 0L

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        _state.update { it.copy(messages = it.messages + ChatMessage(nextId++, clean, true), thinking = true) }
        viewModelScope.launch {
            delay(900)
            val reply = ChatMessage(nextId++, "Interfaz lista. La IA se conecta en la Etapa 2.", false)
            _state.update { it.copy(messages = it.messages + reply, thinking = false) }
        }
    }
}
