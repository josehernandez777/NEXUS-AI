package com.nexus.ai.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.actions.ActionExecutor
import com.nexus.ai.actions.ActionParser
import com.nexus.ai.actions.ActionResult
import com.nexus.ai.actions.ParsedAction
import com.nexus.ai.actions.str
import com.nexus.ai.ai.AiMode
import com.nexus.ai.ai.AiOptions
import com.nexus.ai.ai.AiProvider
import com.nexus.ai.ai.BackendAiProvider
import com.nexus.ai.ai.GeminiAiProvider
import com.nexus.ai.ai.HybridAiProvider
import com.nexus.ai.ai.Prompts
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.Net
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.UiPrefs
import com.nexus.ai.data.db.ConversationEntity
import com.nexus.ai.data.db.MessageEntity
import com.nexus.ai.data.db.NexusDb
import com.nexus.ai.images.ImageGenerator
import com.nexus.ai.util.isAccessibilityEnabled
import com.nexus.ai.util.isOnline
import com.nexus.ai.voice.VoiceEngine
import java.io.File
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Los mensajes que empiezan así son registros de acciones del teléfono, no texto para la IA. */
const val ACTION_PREFIX = "⚙️ "

/** Mensajes con una imagen generada: "🖼 <ruta>\n<descripción>". */
const val IMAGE_PREFIX = "🖼 "

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val thinking: Boolean = false,
    val error: String? = null,
    val liveId: Long? = null
)

data class PendingAction(val description: String, val answer: CompletableDeferred<Boolean>)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx = app.applicationContext
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()
    private val engine = VoiceEngine.get(appCtx)
    private val executor = ActionExecutor(appCtx, ImageGenerator(appCtx, Net.gemini, repo))
    private val provider: AiProvider = HybridAiProvider(
        BackendAiProvider(Net.api, repo),
        GeminiAiProvider(Net.gemini, repo),
        repo
    )

    private val currentId = MutableStateFlow<Long?>(null)
    private val thinking = MutableStateFlow(false)
    private val error = MutableStateFlow<String?>(null)
    private val liveId = MutableStateFlow<Long?>(null)
    private val voiceMode = MutableStateFlow(false)
    private val _pending = MutableStateFlow<PendingAction?>(null)

    val pending: StateFlow<PendingAction?> = _pending.asStateFlow()
    val currentConversationId: StateFlow<Long?> = currentId.asStateFlow()

    val voiceActive: StateFlow<Boolean> = voiceMode.asStateFlow()
    val voiceState: StateFlow<VoiceEngine.State> = engine.state
    val partial: StateFlow<String> = engine.partial
    val voiceError: StateFlow<String?> = engine.error

    private val prefs: StateFlow<UiPrefs> =
        repo.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, UiPrefs())

    val mode: StateFlow<AiMode> = prefs
        .map { AiMode.from(it.mode) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AiMode.EQUILIBRADO)

    val conversations: StateFlow<List<ConversationEntity>> = dao.conversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val state: StateFlow<ChatUiState> = combine(
        currentId.flatMapLatest { id ->
            if (id == null) flowOf(emptyList<MessageEntity>()) else dao.messages(id)
        },
        thinking,
        error,
        liveId
    ) { msgs, th, err, live ->
        ChatUiState(msgs.map { ChatMessage(it.id, it.text, it.fromUser) }, th, err, live)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChatUiState())

    init {
        // Si la conversación abierta se borra (por ejemplo desde Ajustes), volvemos a un chat nuevo.
        viewModelScope.launch {
            dao.conversations().collect {
                val id = currentId.value
                if (id != null && dao.exists(id) == 0) currentId.value = null
            }
        }
        // Conversación por voz: al terminar de hablar, vuelve a escuchar.
        engine.onSpeakDone = { if (voiceMode.value) startVoiceListen() }
        engine.onListenFailed = { voiceMode.value = false }
    }

    // ---------- Voz ----------

    fun startVoiceChat() {
        voiceMode.value = true
        engine.clearError()
        startVoiceListen()
    }

    fun stopVoiceChat() {
        voiceMode.value = false
        engine.cancelListening()
        engine.stopSpeaking()
    }

    private fun startVoiceListen() {
        engine.listen { text -> send(text) }
    }

    /** Dictado: lo que se oye se entrega a [onText] (por ejemplo, para rellenar el cuadro de texto). */
    fun dictate(onText: (String) -> Unit) {
        engine.listen(onText)
    }

    fun finishListening() {
        engine.finishListening()
    }

    fun speak(text: String) {
        val p = prefs.value
        engine.speak(text, p.rate, p.pitch, p.voiceName)
    }

    // ---------- Chat ----------

    fun setMode(m: AiMode) {
        viewModelScope.launch { repo.setMode(m.name) }
    }

    fun answerPending(ok: Boolean) {
        _pending.value?.answer?.complete(ok)
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || thinking.value) return
        viewModelScope.launch {
            error.value = null
            val now = System.currentTimeMillis()
            var id = currentId.value
            if (id == null) {
                id = dao.insertConversation(ConversationEntity(title = clean.take(40), updatedAt = now))
                currentId.value = id
            }
            dao.insertMessage(MessageEntity(conversationId = id, text = clean, fromUser = true, createdAt = now))
            dao.touch(id, now)
            requestReply(id)
        }
    }

    fun retry() {
        val id = currentId.value ?: return
        if (thinking.value) return
        viewModelScope.launch {
            error.value = null
            requestReply(id)
        }
    }

    fun newChat() {
        engine.stopSpeaking()
        currentId.value = null
        error.value = null
        liveId.value = null
    }

    fun open(id: Long) {
        engine.stopSpeaking()
        currentId.value = id
        error.value = null
        liveId.value = null
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            dao.messagesOnce(id)
                .filter { it.text.startsWith(IMAGE_PREFIX) }
                .forEach { m ->
                    runCatching { File(m.text.removePrefix(IMAGE_PREFIX).substringBefore('\n')).delete() }
                }
            dao.deleteConversation(id)
            if (currentId.value == id) currentId.value = null
        }
    }

    private suspend fun requestReply(id: Long) {
        thinking.value = true
        try {
            if (!isOnline(appCtx)) {
                error.value = "Sin conexión a internet."
                return
            }
            val m = mode.value
            val options = AiOptions(
                Prompts.system(m, isAccessibilityEnabled(appCtx), voiceMode.value),
                m.models, m.maxTokens, m.temperature
            )
            val turns = dao.messagesOnce(id)
                .filter { !it.text.startsWith(ACTION_PREFIX) && !it.text.startsWith(IMAGE_PREFIX) }
                .takeLast(20)
                .map { ChatTurn(if (it.fromUser) "user" else "assistant", it.text) }
                .toMutableList()

            var steps = 0
            while (steps < 6) {
                steps++
                val result = provider.reply(turns, options)
                val raw = result.getOrNull()
                if (raw == null) {
                    error.value = result.exceptionOrNull()?.message ?: "Error desconocido."
                    return
                }
                val parsed = ActionParser.parse(raw)
                if (parsed.actions.isEmpty()) {
                    val finalText = parsed.text.ifBlank { raw.trim() }
                    saveAssistant(id, finalText, live = true)
                    if (voiceMode.value || prefs.value.autoSpeak) speak(finalText)
                    return
                }
                if (parsed.text.isNotBlank()) saveAssistant(id, parsed.text, live = false)

                val results = runActions(parsed.actions)
                val log = results.joinToString("\n") { (a, r) ->
                    (if (r.ok) "✓ " else "✗ ") + executor.describe(a) + (if (r.ok) "" else " — " + r.message)
                }
                saveAssistant(id, ACTION_PREFIX + log, live = false)
                results.forEach { (a, r) ->
                    r.imagePath?.let { path ->
                        saveAssistant(id, IMAGE_PREFIX + path + "\n" + (a.args.str("prompt") ?: ""), live = false)
                    }
                }

                if (results.none { (a, _) -> executor.returnsData(a.tool) }) return

                turns.add(ChatTurn("assistant", raw))
                turns.add(
                    ChatTurn(
                        "user",
                        "RESULTADO_ACCIONES:\n" + results.joinToString("\n") { (a, r) -> "${a.tool}: ${r.message}" }
                    )
                )
            }
            error.value = "Hice demasiados pasos seguidos y me detuve por seguridad."
        } finally {
            thinking.value = false
            if (voiceMode.value && engine.state.value == VoiceEngine.State.IDLE) {
                if (error.value != null) voiceMode.value = false else startVoiceListen()
            }
        }
    }

    private suspend fun runActions(actions: List<ParsedAction>): List<Pair<ParsedAction, ActionResult>> {
        val out = mutableListOf<Pair<ParsedAction, ActionResult>>()
        for (a in actions.take(5)) {
            if (prefs.value.confirm && executor.needsConfirmation(a)) {
                val allowed = ask(executor.describe(a))
                if (!allowed) {
                    out.add(a to ActionResult(false, "el usuario canceló la acción"))
                    continue
                }
            }
            out.add(a to executor.execute(a))
        }
        return out
    }

    private suspend fun ask(description: String): Boolean {
        val deferred = CompletableDeferred<Boolean>()
        _pending.value = PendingAction(description, deferred)
        val ok = deferred.await()
        _pending.value = null
        return ok
    }

    private suspend fun saveAssistant(id: Long, text: String, live: Boolean) {
        val now = System.currentTimeMillis()
        val newId = dao.insertMessage(
            MessageEntity(conversationId = id, text = text, fromUser = false, createdAt = now)
        )
        dao.touch(id, now)
        if (live) liveId.value = newId
    }
}
