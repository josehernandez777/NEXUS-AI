package com.nexus.ai.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.ai.AiProvider
import com.nexus.ai.ai.BackendAiProvider
import com.nexus.ai.ai.GeminiAiProvider
import com.nexus.ai.ai.HybridAiProvider
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.Net
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.db.ConversationEntity
import com.nexus.ai.data.db.MessageEntity
import com.nexus.ai.data.db.NexusDb
import com.nexus.ai.util.isOnline
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val thinking: Boolean = false,
    val error: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()
    private val provider: AiProvider = HybridAiProvider(
        BackendAiProvider(Net.api, repo),
        GeminiAiProvider(Net.gemini, repo),
        repo
    )

    private val currentId = MutableStateFlow<Long?>(null)
    private val thinking = MutableStateFlow(false)
    private val error = MutableStateFlow<String?>(null)

    val currentConversationId: StateFlow<Long?> = currentId.asStateFlow()

    val conversations: StateFlow<List<ConversationEntity>> = dao.conversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val state: StateFlow<ChatUiState> = combine(
        currentId.flatMapLatest { id ->
            if (id == null) flowOf(emptyList<MessageEntity>()) else dao.messages(id)
        },
        thinking,
        error
    ) { msgs, th, err ->
        ChatUiState(msgs.map { ChatMessage(it.id, it.text, it.fromUser) }, th, err)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChatUiState())

    init {
        // Si la conversación abierta se borra (por ejemplo desde Ajustes), volvemos a un chat nuevo.
        viewModelScope.launch {
            dao.conversations().collect {
                val id = currentId.value
                if (id != null && dao.exists(id) == 0) currentId.value = null
            }
        }
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || thinking.value) return
        viewModelScope.launch {
            error.value = null
            val now = System.currentTimeMillis()
            var id = currentId.value
            if (id == null) {
                id = dao.insertConversation(ConversationEntity(title = clean.take(40), updatedAt = now))
                currentId.value = id
            }
            dao.insertMessage(MessageEntity(conversationId = id, text = clean, fromUser = true, createdAt = now))
            dao.touch(id, now)
            requestReply(id)
        }
    }

    fun retry() {
        val id = currentId.value ?: return
        if (thinking.value) return
        viewModelScope.launch {
            error.value = null
            requestReply(id)
        }
    }

    fun newChat() {
        currentId.value = null
        error.value = null
    }

    fun open(id: Long) {
        currentId.value = id
        error.value = null
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            dao.deleteConversation(id)
            if (currentId.value == id) currentId.value = null
        }
    }

    private suspend fun requestReply(id: Long) {
        thinking.value = true
        try {
            if (!isOnline(getApplication<Application>())) {
                error.value = "Sin conexión a internet."
                return
            }
            val history = dao.messagesOnce(id)
                .takeLast(20)
                .map { ChatTurn(if (it.fromUser) "user" else "assistant", it.text) }
            val result = provider.reply(history)
            val text = result.getOrNull()
            if (text != null) {
                val now = System.currentTimeMillis()
                dao.insertMessage(MessageEntity(conversationId = id, text = text, fromUser = false, createdAt = now))
                dao.touch(id, now)
            } else {
                error.value = result.exceptionOrNull()?.message ?: "Error desconocido."
            }
        } finally {
            thinking.value = false
        }
    }
}
