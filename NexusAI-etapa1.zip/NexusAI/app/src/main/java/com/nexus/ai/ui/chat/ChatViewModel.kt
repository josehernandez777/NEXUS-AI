package com.nexus.ai.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.ai.AiProvider
import com.nexus.ai.ai.BackendAiProvider
import com.nexus.ai.ai.GeminiAiProvider
import com.nexus.ai.ai.HybridAiProvider
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.Net
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.util.isOnline
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: Long,
    val text: String,
    val fromUser: Boolean,
    val isError: Boolean = false
)

data class ChatUiState(val messages: List<ChatMessage> = emptyList(), val thinking: Boolean = false)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val provider: AiProvider = HybridAiProvider(
        BackendAiProvider(Net.api, repo),
        GeminiAiProvider(Net.gemini, repo),
        repo
    )
    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    private var nextId = 0L

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || _state.value.thinking) return
        append(clean, fromUser = true)
        _state.update { it.copy(thinking = true) }
        viewModelScope.launch {
            if (!isOnline(getApplication<Application>())) {
                append("Sin conexión a internet.", fromUser = false, isError = true)
                return@launch
            }
            val history = _state.value.messages
                .filter { !it.isError }
                .takeLast(20)
                .map { ChatTurn(if (it.fromUser) "user" else "assistant", it.text) }
            provider.reply(history).fold(
                onSuccess = { append(it, fromUser = false) },
                onFailure = { append(it.message ?: "Error desconocido.", fromUser = false, isError = true) }
            )
        }
    }

    private fun append(text: String, fromUser: Boolean, isError: Boolean = false) {
        _state.update {
            it.copy(
                messages = it.messages + ChatMessage(nextId++, text, fromUser, isError),
                thinking = if (fromUser) it.thinking else false
            )
        }
    }
}
