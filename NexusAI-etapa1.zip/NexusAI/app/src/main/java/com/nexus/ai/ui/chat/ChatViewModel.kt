package com.nexus.ai.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.actions.ActionExecutor
import com.nexus.ai.actions.ActionParser
import com.nexus.ai.actions.ActionResult
import com.nexus.ai.actions.ParsedAction
import com.nexus.ai.actions.str
import com.nexus.ai.ai.AiMode
import com.nexus.ai.ai.AiOptions
import com.nexus.ai.ai.AiProvider
import com.nexus.ai.ai.BackendAiProvider
import com.nexus.ai.ai.GeminiAiProvider
import com.nexus.ai.ai.HybridAiProvider
import com.nexus.ai.ai.LocalAiProvider
import com.nexus.ai.ai.Prompts
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.Net
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.UiPrefs
import com.nexus.ai.data.db.ConversationEntity
import com.nexus.ai.data.db.MessageEntity
import com.nexus.ai.data.db.NexusDb
import com.nexus.ai.images.ImageGenerator
import com.nexus.ai.memory.MemoryStore
import com.nexus.ai.util.prepareImageForAi
import com.nexus.ai.util.isAccessibilityEnabled
import com.nexus.ai.voice.VoiceEngine
import java.io.File
import android.net.Uri
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Los mensajes que empiezan así son registros de acciones del teléfono, no texto para la IA. */
const val ACTION_PREFIX = "⚙️ "

/** Mensajes con una imagen generada: "🖼 <ruta>\n<descripción>". */
const val IMAGE_PREFIX = "🖼 "

/** Mensajes del usuario con una imagen adjunta: "📎 <ruta>\n<texto>". */
const val ATTACH_PREFIX = "📎 "

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val thinking: Boolean = false,
    val error: String? = null,
    val liveId: Long? = null,
    /** Qué está haciendo NEXUS ahora mismo (para mostrarlo mientras piensa). */
    val status: String? = null
)

data class PendingAction(val description: String, val answer: CompletableDeferred<Boolean>)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx = app.applicationContext
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()
    private val engine = VoiceEngine.get(appCtx)
    private val memory = MemoryStore(NexusDb.get(app).memoryDao())
    private val executor = ActionExecutor(appCtx, ImageGenerator(appCtx, Net.gemini, repo), memory)
    private val provider: AiProvider = HybridAiProvider(
        appCtx,
        BackendAiProvider(Net.api, repo),
        GeminiAiProvider(Net.gemini, repo),
        LocalAiProvider(appCtx, repo),
        repo
    )
    private var replyJob: Job? = null
    private val status = MutableStateFlow<String?>(null)

    private val currentId = MutableStateFlow<Long?>(null)
    private val thinking = MutableStateFlow(false)
    private val error = MutableStateFlow<String?>(null)
    private val liveId = MutableStateFlow<Long?>(null)
    private val voiceMode = MutableStateFlow(false)
    private val _pending = MutableStateFlow<PendingAction?>(null)

    val pending: StateFlow<PendingAction?> = _pending.asStateFlow()
    val currentConversationId: StateFlow<Long?> = currentId.asStateFlow()

    val voiceActive: StateFlow<Boolean> = voiceMode.asStateFlow()
    val voiceState: StateFlow<VoiceEngine.State> = engine.state
    val partial: StateFlow<String> = engine.partial
    val voiceError: StateFlow<String?> = engine.error

    private val prefs: StateFlow<UiPrefs> =
        repo.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, UiPrefs())

    val mode: StateFlow<AiMode> = prefs
        .map { AiMode.from(it.mode) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AiMode.EQUILIBRADO)

    val conversations: StateFlow<List<ConversationEntity>> = dao.conversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val state: StateFlow<ChatUiState> = combine(
        currentId.flatMapLatest { id ->
            if (id == null) flowOf(emptyList<MessageEntity>()) else dao.messages(id)
        },
        thinking,
        error,
        liveId,
        status
    ) { msgs, th, err, live, st ->
        ChatUiState(msgs.map { ChatMessage(it.id, it.text, it.fromUser) }, th, err, live, st)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChatUiState())

    init {
        // Si la conversación abierta se borra (por ejemplo desde Ajustes), volvemos a un chat nuevo.
        viewModelScope.launch {
            dao.conversations().collect {
                val id = currentId.value
                if (id != null && dao.exists(id) == 0) currentId.value = null
            }
        }
    }

    private fun bindVoiceCallbacks() {
        // Conversación por voz: al terminar de hablar, vuelve a escuchar.
        // El motor es compartido (chat y asistente), así que se enlaza al iniciar cada conversación.
        engine.onSpeakDone = { if (voiceMode.value) startVoiceListen() }
        engine.onListenFailed = { voiceMode.value = false }
    }

    override fun onCleared() {
        replyJob?.cancel()
        if (voiceMode.value) {
            engine.cancelListening()
            engine.stopSpeaking()
            engine.onSpeakDone = null
            engine.onListenFailed = null
        }
        super.onCleared()
    }

    // ---------- Voz ----------

    fun startVoiceChat() {
        bindVoiceCallbacks()
        voiceMode.value = true
        engine.clearError()
        startVoiceListen()
    }

    fun stopVoiceChat() {
        voiceMode.value = false
        engine.cancelListening()
        engine.stopSpeaking()
    }

    private fun startVoiceListen() {
        engine.listen { text -> send(text) }
    }

    /** Dictado: lo que se oye se entrega a [onText] (por ejemplo, para rellenar el cuadro de texto). */
    fun dictate(onText: (String) -> Unit) {
        engine.listen(onText)
    }

    fun finishListening() {
        engine.finishListening()
    }

    fun speak(text: String) {
        val p = prefs.value
        engine.speak(text, p.rate, p.pitch, p.voiceName)
    }

    // ---------- Chat ----------

    fun setMode(m: AiMode) {
        viewModelScope.launch { repo.setMode(m.name) }
    }

    fun answerPending(ok: Boolean) {
        _pending.value?.answer?.complete(ok)
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || thinking.value) return
        launchReply(clean)
    }

    /** Envía un mensaje con una imagen adjunta (la analiza la IA multimodal en la nube). */
    fun sendWithImage(text: String, uri: Uri) {
        if (thinking.value) return
        launchReply(text.trim(), uri)
    }

    private fun launchReply(clean: String, image: Uri? = null) {
        replyJob = viewModelScope.launch {
            error.value = null
            thinking.value = true
            status.value = if (image != null) "Preparando la imagen…" else null
            val now = System.currentTimeMillis()
            var attachedPath: String? = null
            if (image != null) {
                attachedPath = prepareImageForAi(appCtx, image)?.absolutePath
                if (attachedPath == null) {
                    error.value = "No pude leer esa imagen."
                    thinking.value = false
                    status.value = null
                    return@launch
                }
            }
            var id = currentId.value
            if (id == null) {
                val title = clean.ifBlank { "Imagen" }.take(40)
                id = dao.insertConversation(ConversationEntity(title = title, updatedAt = now))
                currentId.value = id
            }
            val body = if (attachedPath != null) ATTACH_PREFIX + attachedPath + "\n" + clean else clean
            dao.insertMessage(MessageEntity(conversationId = id, text = body, fromUser = true, createdAt = now))
            dao.touch(id, now)
            requestReply(id)
        }
    }

    /** Detiene la respuesta en curso (también si está en medio de una cadena de acciones). */
    fun stop() {
        replyJob?.cancel()
        _pending.value?.answer?.complete(false)
        _pending.value = null
        engine.stopSpeaking()
        thinking.value = false
        status.value = null
    }

    fun retry() {
        val id = currentId.value ?: return
        if (thinking.value) return
        replyJob = viewModelScope.launch {
            error.value = null
            requestReply(id)
        }
    }

    fun newChat() {
        engine.stopSpeaking()
        currentId.value = null
        error.value = null
        liveId.value = null
    }

    fun open(id: Long) {
        engine.stopSpeaking()
        currentId.value = id
        error.value = null
        liveId.value = null
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            dao.messagesOnce(id)
                .filter { it.text.startsWith(IMAGE_PREFIX) || it.text.startsWith(ATTACH_PREFIX) }
                .forEach { m ->
                    val path = m.text.removePrefix(IMAGE_PREFIX).removePrefix(ATTACH_PREFIX).substringBefore('\n')
                    runCatching { File(path).delete() }
                }
            dao.deleteConversation(id)
            if (currentId.value == id) currentId.value = null
        }
    }

    private suspend fun requestReply(id: Long) {
        thinking.value = true
        try {
            val p = prefs.value
            val m = mode.value
            val privateMode = p.route == "LOCAL"
            val mem = if (p.memoryOn) memory.promptBlock() else ""
            val options = AiOptions(
                Prompts.system(m, isAccessibilityEnabled(appCtx), voiceMode.value, mem),
                m.models, m.maxTokens, m.temperature,
                localSystem = Prompts.localSystem(mem, voiceMode.value)
            )
            val stored = dao.messagesOnce(id).takeLast(24)
            // Solo las 2 imágenes adjuntas más recientes viajan completas (ahorra datos y tokens).
            val lastAttach = stored.filter { it.text.startsWith(ATTACH_PREFIX) }.takeLast(2).map { it.id }.toSet()
            val turns = stored
                .filter { !it.text.startsWith(ACTION_PREFIX) && !it.text.startsWith(IMAGE_PREFIX) }
                .takeLast(20)
                .map { msg ->
                    val role = if (msg.fromUser) "user" else "assistant"
                    if (msg.text.startsWith(ATTACH_PREFIX)) {
                        val body = msg.text.removePrefix(ATTACH_PREFIX)
                        val path = body.substringBefore('\n')
                        val caption = body.substringAfter('\n', "").ifBlank { "Describe y analiza esta imagen." }
                        val b64 = if (msg.id in lastAttach) imageToBase64(path) else null
                        if (b64 != null) ChatTurn(role, caption, "image/jpeg", b64)
                        else ChatTurn(role, "[imagen adjuntada antes] $caption")
                    } else ChatTurn(role, msg.text)
                }
                .toMutableList()

            val maxSteps = 12
            var steps = 0
            while (steps < maxSteps) {
                steps++
                status.value = if (steps == 1) null else "Pensando el siguiente paso…"
                val result = provider.reply(turns, options)
                val raw = result.getOrNull()
                if (raw == null) {
                    error.value = result.exceptionOrNull()?.message ?: "Error desconocido."
                    return
                }
                val parsed = if (privateMode) com.nexus.ai.actions.Parsed(raw.trim(), emptyList())
                else ActionParser.parse(raw)
                if (parsed.actions.isEmpty()) {
                    val finalText = parsed.text.ifBlank { raw.trim() }
                    saveAssistant(id, finalText, live = true)
                    if (voiceMode.value || p.autoSpeak) speak(finalText)
                    return
                }
                if (parsed.text.isNotBlank()) saveAssistant(id, parsed.text, live = false)

                val results = runActions(parsed.actions, privateMode)
                val log = results.joinToString("\n") { (a, r) ->
                    (if (r.ok) "✓ " else "✗ ") + executor.describe(a) + (if (r.ok) "" else " — " + r.message)
                }
                saveAssistant(id, ACTION_PREFIX + log, live = false)
                results.forEach { (a, r) ->
                    r.imagePath?.let { path ->
                        saveAssistant(id, IMAGE_PREFIX + path + "\n" + (a.args.str("prompt") ?: ""), live = false)
                    }
                }

                if (results.none { (a, _) -> executor.returnsData(a.tool) }) return

                val media = results.firstOrNull { it.second.media != null }?.second
                turns.add(ChatTurn("assistant", raw))
                turns.add(
                    ChatTurn(
                        "user",
                        "RESULTADO_ACCIONES:\n" + results.joinToString("\n") { (a, r) -> "${a.tool}: ${r.message}" },
                        media?.mime, media?.media
                    )
                )
            }
            error.value = "Hice $maxSteps pasos seguidos y me detuve por seguridad. Dime si quieres que continúe."
        } catch (e: CancellationException) {
            throw e
        } finally {
            thinking.value = false
            status.value = null
            _pending.value = null
            if (voiceMode.value && engine.state.value == VoiceEngine.State.IDLE) {
                if (error.value != null) voiceMode.value = false else startVoiceListen()
            }
        }
    }

    private suspend fun imageToBase64(path: String): String? = kotlinx.coroutines.withContext(
        kotlinx.coroutines.Dispatchers.IO
    ) {
        runCatching {
            android.util.Base64.encodeToString(File(path).readBytes(), android.util.Base64.NO_WRAP)
        }.getOrNull()
    }

    private suspend fun runActions(
        actions: List<ParsedAction>,
        privateMode: Boolean
    ): List<Pair<ParsedAction, ActionResult>> {
        val out = mutableListOf<Pair<ParsedAction, ActionResult>>()
        for (a in actions.take(5)) {
            if (privateMode && executor.usesNetwork(a.tool)) {
                out.add(a to ActionResult(false, "bloqueado: el modo Privado no usa internet"))
                continue
            }
            val mustAsk = executor.alwaysConfirm(a) || (prefs.value.confirm && executor.needsConfirmation(a))
            if (mustAsk) {
                status.value = "Esperando tu permiso…"
                val allowed = ask(executor.describe(a))
                if (!allowed) {
                    out.add(a to ActionResult(false, "el usuario canceló la acción"))
                    continue
                }
            }
            status.value = executor.statusText(a)
            out.add(a to executor.execute(a))
        }
        return out
    }

    private suspend fun ask(description: String): Boolean {
        val deferred = CompletableDeferred<Boolean>()
        _pending.value = PendingAction(description, deferred)
        val ok = deferred.await()
        _pending.value = null
        return ok
    }

    private suspend fun saveAssistant(id: Long, text: String, live: Boolean) {
        val now = System.currentTimeMillis()
        val newId = dao.insertMessage(
            MessageEntity(conversationId = id, text = text, fromUser = false, createdAt = now)
        )
        dao.touch(id, now)
        if (live) liveId.value = newId
    }
}
