package com.nexus.ai.ui.navigation

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.NexusSplash
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet500
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.components.AuroraBackground
import com.nexus.ai.ui.screens.ChatScreen
import com.nexus.ai.ui.screens.HistoryScreen
import com.nexus.ai.ui.screens.SettingsScreen
import com.nexus.ai.ui.screens.SettingsViewModel
import com.nexus.ai.ui.screens.VoiceScreen

private enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Chat("chat", "Chat", Icons.Filled.Chat),
    History("history", "Historial", Icons.Filled.History),
    Voice("voice", "Voz", Icons.Filled.Mic),
    Settings("settings", "Ajustes", Icons.Filled.Settings)
}

@Composable
fun NexusRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    // ViewModel compartido entre Chat e Historial (ligado a la actividad).
    val chatVm: ChatViewModel = viewModel()
    val settingsVm: SettingsViewModel = viewModel()
    val prefs by settingsVm.prefs.collectAsStateWithLifecycle()
    val pending by chatVm.pending.collectAsStateWithLifecycle()
    val dark = isSystemInDarkTheme()
    var showSplash by rememberSaveable { mutableStateOf(true) }

    fun navigateTo(route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (prefs.aurora && dark) AuroraBackground()

        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            bottomBar = {
                NexusBottomBar(current) { navigateTo(it) }
            }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Dest.Chat.route,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding),
                enterTransition = {
                    val dir = if (destIndex(targetState.destination.route) >= destIndex(initialState.destination.route)) 1 else -1
                    fadeIn(tween(340, delayMillis = 70)) +
                        slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { (it / 9) * dir }
                },
                exitTransition = { fadeOut(tween(160)) },
                popEnterTransition = {
                    val dir = if (destIndex(targetState.destination.route) >= destIndex(initialState.destination.route)) 1 else -1
                    fadeIn(tween(340, delayMillis = 70)) +
                        slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { (it / 9) * dir }
                },
                popExitTransition = { fadeOut(tween(160)) }
            ) {
                composable(Dest.Chat.route) { ChatScreen(chatVm, onOpenVoice = { navigateTo(Dest.Voice.route) }) }
                composable(Dest.History.route) {
                    HistoryScreen(chatVm, onOpened = { navigateTo(Dest.Chat.route) })
                }
                composable(Dest.Voice.route) { VoiceScreen(chatVm) }
                composable(Dest.Settings.route) { SettingsScreen() }
            }
        }

        if (showSplash) NexusSplash(onFinished = { showSplash = false })
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { chatVm.answerPending(false) },
            title = { Text("NEXUS quiere actuar") },
            text = { Text(p.description) },
            confirmButton = {
                TextButton(onClick = { chatVm.answerPending(true) }) { Text("Permitir") }
            },
            dismissButton = {
                TextButton(onClick = { chatVm.answerPending(false) }) { Text("Cancelar") }
            }
        )
    }
}

private fun destIndex(route: String?): Int = Dest.entries.indexOfFirst { it.route == route }

@Composable
private fun NexusBottomBar(current: String?, onSelect: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.background(cs.background.copy(alpha = 0.92f))) {
        // Línea fina con degradado neón arriba de la barra.
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Cyan400.copy(alpha = 0.55f), Violet500.copy(alpha = 0.65f), Magenta.copy(alpha = 0.55f), Color.Transparent)
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Dest.entries.forEach { d ->
                BarItem(d, selected = current == d.route, modifier = Modifier.weight(1f)) { onSelect(d.route) }
            }
        }
    }
}

@Composable
private fun BarItem(d: Dest, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a by animateFloatAsState(if (selected) 1f else 0f, tween(280), label = "sel")
    val k by animateFloatAsState(if (selected) 1.12f else 1f, spring(dampingRatio = 0.45f, stiffness = 380f), label = "selk")
    val pillW by animateFloatAsState(if (selected) 60f else 34f, spring(dampingRatio = 0.7f, stiffness = 420f), label = "pill")
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .width(pillW.dp)
                .height(32.dp)
                .clip(RoundedCornerShape(50))
                .background(Brush.linearGradient(listOf(Violet500, Magenta)), RoundedCornerShape(50), alpha = a * 0.95f),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                d.icon,
                contentDescription = d.label,
                tint = if (selected) Color.White else cs.onSurfaceVariant,
                modifier = Modifier.size(22.dp).graphicsLayer { scaleX = k; scaleY = k }
            )
        }
        Text(
            d.label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) cs.tertiary else cs.onSurfaceVariant,
            modifier = Modifier.padding(top = 3.dp)
        )
    }
}
