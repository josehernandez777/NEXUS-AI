package com.nexus.ai.dev

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Servidor HTTP local embebido (solo 127.0.0.1) para previsualizar proyectos sin internet.
 * Inyecta un pequeño «shim» que da respaldo a APIs pesadas en móviles (WebGL, AudioContext…).
 */
object LocalServer {
    private var server: ServerSocket? = null
    @Volatile
    private var root: File? = null
    private val token = UUID.randomUUID().toString().replace("-", "").take(10)

    private const val SHIM = """(function(){try{
var g=HTMLCanvasElement.prototype.getContext;
HTMLCanvasElement.prototype.getContext=function(t,a){var r=g.call(this,t,a);
if(!r&&t==='webgl2'){r=g.call(this,'webgl',a)||g.call(this,'experimental-webgl',a)}
if(!r&&t==='webgl'){r=g.call(this,'experimental-webgl',a)}
return r};
window.AudioContext=window.AudioContext||window.webkitAudioContext;
window.requestAnimationFrame=window.requestAnimationFrame||function(f){return setTimeout(f,16)};
var d=window.devicePixelRatio||1;if(d>2){try{Object.defineProperty(window,'devicePixelRatio',{get:function(){return 2}})}catch(e){}}
window.addEventListener('error',function(e){var b=document.getElementById('__nx_err');
if(!b&&document.body){b=document.createElement('div');b.id='__nx_err';
b.style.cssText='position:fixed;left:0;right:0;bottom:0;background:#FF0055;color:#fff;font:12px monospace;padding:6px 10px;z-index:99999';
document.body.appendChild(b)}
if(b)b.textContent='ERROR: '+e.message+' (linea '+e.lineno+')'});
}catch(e){}})();"""

    @Synchronized
    fun ensure(rootDir: File): Int {
        root = rootDir
        server?.let { if (!it.isClosed) return it.localPort }
        val addr = InetAddress.getByName("127.0.0.1")
        val s = try {
            ServerSocket(8765, 20, addr)
        } catch (e: Exception) {
            ServerSocket(0, 20, addr)
        }
        server = s
        thread(isDaemon = true, name = "nexus-http") {
            while (!s.isClosed) {
                val c = try {
                    s.accept()
                } catch (e: Exception) {
                    break
                }
                thread(isDaemon = true) { runCatching { handle(c) } }
            }
        }
        return s.localPort
    }

    fun urlFor(ctx: Context, project: String, entry: String): String {
        val port = ensure(ProjectStore.rootDir(ctx))
        return "http://127.0.0.1:$port/$token/$project/${entry.ifEmpty { "index.html" }}"
    }

    private fun readLine(input: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun mime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html; charset=utf-8"
        "js", "mjs" -> "application/javascript; charset=utf-8"
        "css" -> "text/css; charset=utf-8"
        "json" -> "application/json; charset=utf-8"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "ico" -> "image/x-icon"
        "txt", "md" -> "text/plain; charset=utf-8"
        else -> "application/octet-stream"
    }

    private fun inject(html: String): String {
        val tags = StringBuilder()
        if (!Regex("name\\s*=\\s*[\"']viewport", RegexOption.IGNORE_CASE).containsMatchIn(html)) {
            tags.append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">")
        }
        tags.append("<script>").append(SHIM).append("</script>")
        val spots = listOf("<head[^>]*>", "<html[^>]*>", "<!doctype[^>]*>")
        for (p in spots) {
            val m = Regex(p, RegexOption.IGNORE_CASE).find(html)
            if (m != null) {
                val at = m.range.last + 1
                return html.substring(0, at) + tags + html.substring(at)
            }
        }
        return tags.toString() + html
    }

    private fun handle(c: Socket) {
        c.use { sock ->
            sock.soTimeout = 5000
            val input = BufferedInputStream(sock.getInputStream())
            val reqLine = readLine(input) ?: return
            while (true) {
                val h = readLine(input) ?: break
                if (h.isEmpty()) break
            }
            val parts = reqLine.split(' ')
            if (parts.size < 2) return
            val method = parts[0]
            val target = URLDecoder.decode(parts[1].substringBefore('?').substringBefore('#'), "UTF-8")
            val out = sock.getOutputStream()

            fun send(code: Int, msg: String, mime: String, body: ByteArray) {
                val head = "HTTP/1.1 $code $msg\r\nContent-Type: $mime\r\nContent-Length: ${body.size}\r\n" +
                    "Cache-Control: no-store\r\nConnection: close\r\n\r\n"
                out.write(head.toByteArray())
                if (method != "HEAD") out.write(body)
                out.flush()
            }

            val base = root
            val segs = target.trim('/').split('/').filter { it.isNotEmpty() }
            if (base == null || segs.isEmpty() || segs[0] != token) {
                send(403, "Forbidden", "text/plain", "403".toByteArray())
                return
            }
            if (segs.size == 1) {
                val names = (base.listFiles() ?: emptyArray()).filter { it.isDirectory }.map { it.name }.sorted()
                val html = "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'>" +
                    "<body style='background:#05050A;color:#00FFCC;font:16px sans-serif;padding:20px'><h2>NEXUS · Proyectos</h2>" +
                    names.joinToString("") { "<p><a style='color:#FFB700' href='/$token/$it/'>$it</a></p>" } + "</body>"
                send(200, "OK", "text/html; charset=utf-8", html.toByteArray())
                return
            }
            var f = File(base, segs.drop(1).joinToString("/")).canonicalFile
            val basePath = base.canonicalPath + File.separator
            if (!f.path.startsWith(basePath) || f.name.startsWith(".")) {
                send(403, "Forbidden", "text/plain", "403".toByteArray())
                return
            }
            if (f.isDirectory) f = File(f, "index.html")
            if (!f.exists() || !f.isFile) {
                send(404, "Not Found", "text/plain; charset=utf-8", "404 · no existe".toByteArray())
                return
            }
            val type = mime(f.name)
            val body = if (type.startsWith("text/html")) inject(f.readText()).toByteArray() else f.readBytes()
            send(200, "OK", type, body)
        }
    }
}
