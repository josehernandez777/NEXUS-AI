package com.nexus.ai.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// Oscuro AMOLED pulido: negro real de fondo y capas de superficie violetas muy sutiles
// para que las tarjetas se distingan sin brillar.
private val DarkColors = darkColorScheme(
    primary = Violet500,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF22125A),
    onPrimaryContainer = Color(0xFFE4DBFF),
    secondary = Magenta,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF4A0A22),
    onSecondaryContainer = Color(0xFFFFD9E3),
    tertiary = Gold,
    onTertiary = Color(0xFF241800),
    tertiaryContainer = Color(0xFF3A2A00),
    onTertiaryContainer = Color(0xFFFFE3A0),
    background = AmoledBlack,
    onBackground = Color(0xFFE8ECF8),
    surface = SurfaceDark,
    onSurface = Color(0xFFE8ECF8),
    surfaceVariant = SurfaceDark2,
    onSurfaceVariant = Color(0xFFA9B3D6),
    surfaceTint = Cyan400,
    outline = Color(0xFF3A4066),
    outlineVariant = Color(0xFF232740),
    error = Magenta,
    errorContainer = Color(0xFF4A0A22),
    onErrorContainer = Color(0xFFFFD9E3),
    surfaceContainerLowest = AmoledBlack,
    surfaceContainerLow = Color(0xFF08080F),
    surfaceContainer = Color(0xFF0E0E1A),
    surfaceContainerHigh = Color(0xFF151524),
    surfaceContainerHighest = Color(0xFF1C1C30),
)

private val LightColors = lightColorScheme(
    primary = Purple700,
    onPrimary = Color.White,
    secondary = Magenta,
    tertiary = Violet500,
    background = LightBg,
    surface = Color.White,
    surfaceVariant = Color(0xFFEDE5FF),
    onSurfaceVariant = Purple700,
    outline = Color(0xFFB7A6E6),
)

private val NexusShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun NexusTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamic: Boolean = false,
    content: @Composable () -> Unit
) {
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(ctx).copy(background = AmoledBlack)
            else dynamicLightColorScheme(ctx)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = scheme, shapes = NexusShapes, typography = NexusTypography, content = content)
}
