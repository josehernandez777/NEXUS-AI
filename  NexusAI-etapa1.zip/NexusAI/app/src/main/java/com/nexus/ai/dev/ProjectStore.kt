package com.nexus.ai.dev

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.nexus.ai.actions.ActionResult
import java.io.File

data class FileInfo(var bytes: Int = 0, var lines: Int = 0, var updated: Long = 0L)
data class Decision(var ts: Long = 0L, var text: String = "")
data class ProjectMeta(
    var name: String = "",
    var created: Long = 0L,
    var updated: Long = 0L,
    var files: MutableMap<String, FileInfo> = mutableMapOf(),
    /** Árbol de dependencias: archivo -> archivos / paquetes que usa. */
    var deps: MutableMap<String, MutableList<String>> = mutableMapOf(),
    var globals: MutableMap<String, String> = mutableMapOf(),
    var decisions: MutableList<Decision> = mutableListOf(),
    var packages: MutableList<String> = mutableListOf()
)

/**
 * Proyectos de código que NEXUS crea en el teléfono. Cada uno guarda sus archivos, el árbol de
 * dependencias, variables globales y decisiones de arquitectura, para retomarlo días después.
 * Los archivos se copian también a Descargas/NexusProjects.
 */
class ProjectStore(private val ctx: Context) {

    companion object {
        private val ALLOWED = setOf("html", "htm", "css", "js", "mjs", "json", "svg", "txt", "md")
        private val gson = Gson()

        fun rootDir(ctx: Context): File =
            File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "projects").apply { mkdirs() }

        fun sanitizeProject(raw: String?): String? {
            val s = raw.orEmpty().trim().lowercase().replace(Regex("\\s+"), "-")
                .replace(Regex("[^a-z0-9_-]"), "").take(40)
            return s.ifEmpty { null }
        }

        fun sanitizePath(raw: String?): String? {
            val p = raw.orEmpty().trim().replace('\\', '/').trimStart('/')
            if (p.isEmpty()) return null
            val segs = p.split('/')
            if (segs.size > 3) return null
            if (segs.any { it.isEmpty() || it == "." || it == ".." || it.startsWith(".") }) return null
            if (segs.any { !Regex("[A-Za-z0-9_.\\-]+").matches(it) }) return null
            val ext = p.substringAfterLast('.', "").lowercase()
            if (ext !in ALLOWED) return null
            return p
        }
    }

    private class Pending(var last: Int, val sb: StringBuilder)

    private val root = rootDir(ctx)
    private val pending = HashMap<String, Pending>()

    private fun dir(project: String) = File(root, project).apply { mkdirs() }
    private fun metaFile(project: String) = File(dir(project), ".nexus.json")

    fun meta(project: String): ProjectMeta {
        val f = metaFile(project)
        val m = runCatching { gson.fromJson(f.readText(), ProjectMeta::class.java) }.getOrNull()
        return m ?: ProjectMeta(name = project, created = System.currentTimeMillis())
    }

    private fun saveMeta(m: ProjectMeta) {
        m.updated = System.currentTimeMillis()
        runCatching { metaFile(m.name).writeText(gson.toJson(m)) }
    }

    fun list(): List<ProjectMeta> =
        (root.listFiles() ?: emptyArray()).filter { it.isDirectory && File(it, ".nexus.json").exists() }
            .map { meta(it.name) }
            .sortedByDescending { it.updated }

    /** Recibe un archivo (completo o por partes), lo valida y lo guarda. */
    fun receive(projectRaw: String?, pathRaw: String?, content: String, part: Int, parts: Int): ActionResult {
        val project = sanitizeProject(projectRaw)
            ?: return ActionResult(false, "falta el nombre del proyecto (project=\"mi-proyecto\")")
        val path = sanitizePath(pathRaw)
            ?: return ActionResult(false, "ruta de archivo no válida «${pathRaw.orEmpty()}». Usa nombres simples con extensión html, css, js, json, svg, txt o md (máx. 3 niveles)")
        val key = "$project/$path"
        var text = content
        if (parts > 1) {
            if (part == 1) {
                pending[key] = Pending(1, StringBuilder(content))
            } else {
                val st = pending[key]
                if (st == null || st.last != part - 1) {
                    return ActionResult(false, "falta la parte ${if (st == null) 1 else st.last + 1}/$parts de $path; reenvía desde part=1/$parts")
                }
                st.sb.append('\n').append(content)
                st.last = part
            }
            if (part < parts) {
                return ActionResult(true, "parte $part/$parts de $path recibida. Envía ahora la parte ${part + 1}/$parts, continuando justo donde terminó (corta siempre en saltos de línea, sin repetir).")
            }
            text = pending.remove(key)!!.sb.toString()
        } else {
            pending.remove(key)
        }

        val rep = SyntaxCheck.check(path, text)
        if (rep.errors.isNotEmpty()) {
            return ActionResult(
                false,
                "NO guardé $path: tiene errores de sintaxis.\n- " + rep.errors.joinToString("\n- ") +
                    "\nCorrígelo y reenvía el archivo COMPLETO (si es largo, en partes más pequeñas con part=1/N)."
            )
        }

        val f = File(dir(project), path)
        f.parentFile?.mkdirs()
        f.writeText(text)

        val m = meta(project)
        m.name = project
        val now = System.currentTimeMillis()
        m.files[path] = FileInfo(text.toByteArray().size, text.count { it == '\n' } + 1, now)
        val deps = extractDeps(path, text)
        if (deps.isEmpty()) m.deps.remove(path) else m.deps[path] = deps.toMutableList()
        deps.filter { it.startsWith("http") }.forEach { if (it !in m.packages) m.packages.add(it) }
        saveMeta(m)

        val exported = export(project, path, text.toByteArray())

        val entry = entryOf(m)
        val w = JsonObject().apply {
            addProperty("type", "project")
            addProperty("name", project)
            addProperty("saved", path)
            addProperty("entry", entry ?: "")
            add("files", JsonArray().also { a -> m.files.keys.sorted().forEach { a.add(it) } })
            addProperty("export", exported ?: "")
            addProperty("warnings", rep.warnings.size)
        }
        val msg = buildString {
            append("guardado $path en el proyecto «$project» (${m.files[path]?.lines} líneas)")
            if (exported != null) append("; copia en $exported")
            if (rep.warnings.isNotEmpty()) append("\nAvisos: " + rep.warnings.joinToString("; "))
        }
        return ActionResult(true, msg, widget = w.toString())
    }

    fun entryOf(m: ProjectMeta): String? =
        if ("index.html" in m.files) "index.html" else m.files.keys.sorted().firstOrNull { it.endsWith(".html") }

    fun projectWidget(project: String): String? {
        val p = sanitizeProject(project) ?: return null
        if (!File(root, p).exists()) return null
        val m = meta(p)
        return JsonObject().apply {
            addProperty("type", "project")
            addProperty("name", p)
            addProperty("entry", entryOf(m) ?: "")
            add("files", JsonArray().also { a -> m.files.keys.sorted().forEach { a.add(it) } })
            addProperty("saved", "")
            addProperty("export", "")
            addProperty("warnings", 0)
        }.toString()
    }

    fun read(projectRaw: String?, pathRaw: String?): ActionResult {
        val p = sanitizeProject(projectRaw) ?: return ActionResult(false, "falta el proyecto")
        val path = sanitizePath(pathRaw) ?: return ActionResult(false, "ruta no válida")
        val f = File(File(root, p), path)
        if (!f.exists()) return ActionResult(false, "no existe $path en «$p»")
        val t = f.readText()
        val cut = if (t.length > 14000) t.take(14000) + "\n…(recortado, el archivo tiene ${t.length} caracteres)" else t
        return ActionResult(true, "CONTENIDO de $p/$path:\n$cut")
    }

    fun note(projectRaw: String?, kind: String?, key: String?, text: String?): ActionResult {
        val p = sanitizeProject(projectRaw) ?: return ActionResult(false, "falta el proyecto")
        if (!File(root, p).exists()) return ActionResult(false, "el proyecto «$p» no existe todavía")
        val m = meta(p)
        val body = text.orEmpty().trim().take(240)
        when ((kind ?: "decision").lowercase()) {
            "global", "variable" -> {
                val k = key.orEmpty().trim().take(40)
                if (k.isEmpty()) return ActionResult(false, "falta la clave de la variable global")
                m.globals[k] = body
            }
            "dependency", "dependencia", "package", "paquete" -> {
                if (body.isEmpty()) return ActionResult(false, "falta el paquete")
                if (body !in m.packages) m.packages.add(body)
            }
            else -> {
                if (body.isEmpty()) return ActionResult(false, "falta el texto de la decisión")
                m.decisions.add(Decision(System.currentTimeMillis(), body))
                while (m.decisions.size > 25) m.decisions.removeAt(0)
            }
        }
        saveMeta(m)
        return ActionResult(true, "anotado en «$p»")
    }

    fun summary(): String {
        val l = list()
        if (l.isEmpty()) return "No hay proyectos todavía."
        return l.joinToString("\n") { m ->
            "• ${m.name}: ${m.files.size} archivos (${m.files.keys.sorted().joinToString(", ")})"
        }
    }

    /** Memoria técnica de los proyectos recientes para el prompt. */
    fun promptBlock(): String {
        val l = list().take(3)
        if (l.isEmpty()) return ""
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        for (m in l) {
            val days = ((now - m.updated) / 86_400_000L).toInt()
            sb.append("• ${m.name} (hace ${if (days == 0) "menos de un día" else "$days d"}): ")
            sb.append(m.files.entries.sortedBy { it.key }.joinToString(", ") { "${it.key} (${it.value.lines} l)" })
            if (m.deps.isNotEmpty()) {
                sb.append("\n  dependencias: ")
                sb.append(m.deps.entries.joinToString("; ") { it.key + "→" + it.value.joinToString("+") { d -> d.removePrefix("https://").take(40) } })
            }
            if (m.globals.isNotEmpty()) sb.append("\n  globales: " + m.globals.entries.joinToString("; ") { "${it.key}=${it.value}" })
            if (m.decisions.isNotEmpty()) sb.append("\n  decisiones: " + m.decisions.takeLast(8).joinToString(" | ") { it.text })
            sb.append('\n')
        }
        return sb.toString().take(2400).trim()
    }

    private fun extractDeps(path: String, text: String): List<String> {
        val out = linkedSetOf<String>()
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext == "html" || ext == "htm") {
            Regex("""<script[^>]+src\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                .findAll(text).forEach { out.add(it.groupValues[1]) }
            Regex("""<link[^>]+href\s*=\s*["']([^"']+\.css[^"']*)["']""", RegexOption.IGNORE_CASE)
                .findAll(text).forEach { out.add(it.groupValues[1]) }
        }
        if (ext == "js" || ext == "mjs") {
            Regex("""(?:import|export)[^'"\n]*?from\s*["']([^"']+)["']""").findAll(text).forEach { out.add(it.groupValues[1]) }
            Regex("""import\s*\(\s*["']([^"']+)["']\s*\)""").findAll(text).forEach { out.add(it.groupValues[1]) }
        }
        if (ext == "css") {
            Regex("""@import\s+(?:url\()?["']([^"']+)["']""").findAll(text).forEach { out.add(it.groupValues[1]) }
        }
        return out.take(20).toList()
    }

    private fun mime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "text/javascript"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "md" -> "text/markdown"
        else -> "text/plain"
    }

    /** Copia el archivo a Descargas/NexusProjects/<proyecto>/ (sin permisos especiales). */
    private fun export(project: String, path: String, data: ByteArray): String? = runCatching {
        val sub = path.substringBeforeLast('/', "")
        val rel = Environment.DIRECTORY_DOWNLOADS + "/NexusProjects/" + project +
            (if (sub.isEmpty()) "" else "/$sub") + "/"
        val name = path.substringAfterLast('/')
        val res = ctx.contentResolver
        val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        var uri: android.net.Uri? = null
        res.query(
            coll, arrayOf(MediaStore.MediaColumns._ID),
            MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=?",
            arrayOf(rel, name), null
        )?.use { c -> if (c.moveToFirst()) uri = ContentUris.withAppendedId(coll, c.getLong(0)) }
        if (uri == null) {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime(name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            }
            uri = res.insert(coll, v)
        }
        val u = uri ?: return@runCatching null
        res.openOutputStream(u, "wt")?.use { it.write(data) }
        "Descargas/NexusProjects/$project"
    }.getOrNull()
}
