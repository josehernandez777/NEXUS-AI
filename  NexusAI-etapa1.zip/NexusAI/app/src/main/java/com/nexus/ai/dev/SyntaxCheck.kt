package com.nexus.ai.dev

import org.json.JSONException
import org.json.JSONTokener

/**
 * Sandbox sintáctico: revisa HTML, JS, CSS, JSON y SVG antes de guardar o mostrar,
 * para no entregar código trunco o corrupto.
 */
object SyntaxCheck {
    class Report(val errors: List<String>, val warnings: List<String>)

    private val VOID = setOf(
        "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
        "param", "source", "track", "wbr", "!doctype"
    )
    private val OPTIONAL_CLOSE = setOf(
        "p", "li", "td", "th", "tr", "thead", "tbody", "tfoot", "option", "optgroup",
        "dt", "dd", "colgroup", "caption"
    )

    fun check(path: String, content: String): Report {
        val ext = path.substringAfterLast('.', "").lowercase()
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (content.isBlank()) {
            errors.add("el archivo está vacío")
            return Report(errors, warnings)
        }
        when (ext) {
            "html", "htm" -> markup(content, errors, warnings, true)
            "svg" -> markup(content, errors, warnings, false)
            "js", "mjs" -> js(content, 1, errors, "JS")
            "json" -> json(content, errors, "JSON")
            "css" -> css(content, 1, errors, "CSS")
        }
        if (ext == "js" || ext == "html" || ext == "htm") {
            if (Regex("""getContext\(\s*['"]webgl2?['"]""").containsMatchIn(content)) {
                warnings.add("usa WebGL: el visor móvil añade respaldo automático, pero conviene un plan B en Canvas 2D")
            }
        }
        return Report(errors.take(8), warnings.take(8))
    }

    // ---------- JSON ----------
    private fun json(src: String, errors: MutableList<String>, label: String) {
        try {
            val t = JSONTokener(src)
            t.nextValue()
            if (t.nextClean() != '\u0000') errors.add("$label: hay texto extra después del JSON")
        } catch (e: JSONException) {
            errors.add("$label inválido: ${e.message}")
        }
    }

    // ---------- CSS ----------
    private fun css(src: String, lineOffset: Int, errors: MutableList<String>, label: String) {
        var depth = 0
        var line = lineOffset
        var openLine = lineOffset
        var i = 0
        val n = src.length
        while (i < n) {
            val c = src[i]
            if (c == '\n') line++
            if (c == '/' && i + 1 < n && src[i + 1] == '*') {
                val e = src.indexOf("*/", i + 2)
                if (e < 0) {
                    errors.add("$label línea $line: comentario /* sin cerrar")
                    return
                }
                line += src.substring(i, e).count { it == '\n' }
                i = e + 2
                continue
            }
            if (c == '"' || c == '\'') {
                var j = i + 1
                while (j < n && src[j] != c && src[j] != '\n') {
                    if (src[j] == '\\') j++
                    j++
                }
                i = j + 1
                continue
            }
            if (c == '{') {
                if (depth == 0) openLine = line
                depth++
            }
            if (c == '}') {
                depth--
                if (depth < 0) {
                    errors.add("$label línea $line: '}' de más")
                    return
                }
            }
            i++
        }
        if (depth > 0) errors.add("$label: falta cerrar '{' abierta en la línea $openLine")
    }

    // ---------- JS ----------
    private fun js(src: String, lineOffset: Int, errors: MutableList<String>, label: String) {
        val stack = ArrayList<Pair<Char, Int>>()
        val tmplMarks = ArrayList<Int>()
        var line = lineOffset
        var i = 0
        val n = src.length
        var last = '\u0000'

        fun err(msg: String) {
            if (errors.size < 8) errors.add("$label línea $line: $msg")
        }

        fun scanTemplate(start: Int): Int {
            var j = start
            while (j < n) {
                val d = src[j]
                if (d == '\\') {
                    if (j + 1 < n && src[j + 1] == '\n') line++
                    j += 2
                } else if (d == '\n') {
                    line++
                    j++
                } else if (d == '`') {
                    return j + 1
                } else if (d == '$' && j + 1 < n && src[j + 1] == '{') {
                    stack.add('{' to line)
                    tmplMarks.add(stack.size)
                    return j + 2
                } else {
                    j++
                }
            }
            err("plantilla ` sin cerrar")
            return n
        }

        val regexPrev = "(,=:[!&|?{};+-*%<>~^"
        while (i < n) {
            val c = src[i]
            if (c == '\n') {
                line++
                i++
                continue
            }
            if (c == '/' && i + 1 < n && src[i + 1] == '/') {
                while (i < n && src[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < n && src[i + 1] == '*') {
                val e = src.indexOf("*/", i + 2)
                if (e < 0) {
                    err("comentario /* sin cerrar")
                    return
                }
                line += src.substring(i, e).count { it == '\n' }
                i = e + 2
                continue
            }
            if (c == '"' || c == '\'') {
                var j = i + 1
                var closed = false
                while (j < n) {
                    val d = src[j]
                    if (d == '\\') {
                        if (j + 1 < n && src[j + 1] == '\n') line++
                        j += 2
                        continue
                    }
                    if (d == c) {
                        closed = true
                        j++
                        break
                    }
                    if (d == '\n') break
                    j++
                }
                if (!closed) err("cadena sin cerrar")
                i = j
                last = c
                continue
            }
            if (c == '`') {
                i = scanTemplate(i + 1)
                last = '`'
                continue
            }
            if (c == '/') {
                val isRegex = last == '\u0000' || regexPrev.indexOf(last) >= 0
                if (isRegex) {
                    var j = i + 1
                    var inClass = false
                    var ok = false
                    while (j < n && src[j] != '\n') {
                        val d = src[j]
                        if (d == '\\') {
                            j += 2
                            continue
                        }
                        if (d == '[') inClass = true
                        if (d == ']') inClass = false
                        if (d == '/' && !inClass) {
                            ok = true
                            j++
                            break
                        }
                        j++
                    }
                    if (ok) {
                        while (j < n && src[j].isLetter()) j++
                        i = j
                        last = 'r'
                        continue
                    }
                }
                last = '/'
                i++
                continue
            }
            when (c) {
                '(', '[', '{' -> stack.add(c to line)
                ')', ']', '}' -> {
                    if (stack.isEmpty()) {
                        err("'$c' de más")
                        return
                    }
                    val top = stack.last()
                    val want = when (top.first) {
                        '(' -> ')'
                        '[' -> ']'
                        else -> '}'
                    }
                    if (want != c) {
                        err("se esperaba '$want' (abierto en la línea ${top.second}) pero hay '$c'")
                        return
                    }
                    val sizeBefore = stack.size
                    stack.removeAt(stack.size - 1)
                    if (c == '}' && tmplMarks.isNotEmpty() && tmplMarks.last() == sizeBefore) {
                        tmplMarks.removeAt(tmplMarks.size - 1)
                        i = scanTemplate(i + 1)
                        last = '`'
                        continue
                    }
                }
            }
            if (!c.isWhitespace()) last = c
            i++
        }
        if (stack.isNotEmpty()) {
            val t = stack.last()
            val name = when (t.first) {
                '(' -> "paréntesis '('"
                '[' -> "corchete '['"
                else -> "llave '{'"
            }
            if (errors.size < 8) errors.add("$label: falta cerrar $name abierto en la línea ${t.second} (¿se cortó el código?)")
        }
    }

    // ---------- HTML / SVG ----------
    private fun markup(src: String, errors: MutableList<String>, warnings: MutableList<String>, html: Boolean) {
        val stack = ArrayList<Pair<String, Int>>()
        var i = 0
        var line = 1
        var lastPos = 0
        val n = src.length

        fun lineAt(pos: Int): Int {
            while (lastPos < pos && lastPos < n) {
                if (src[lastPos] == '\n') line++
                lastPos++
            }
            return line
        }

        fun err(msg: String) {
            if (errors.size < 8) errors.add(msg)
        }

        while (i < n) {
            val lt = src.indexOf('<', i)
            if (lt < 0) break
            if (src.startsWith("<!--", lt)) {
                val e = src.indexOf("-->", lt + 4)
                if (e < 0) {
                    err("línea ${lineAt(lt)}: comentario <!-- sin cerrar")
                    return
                }
                i = e + 3
                continue
            }
            if (src.startsWith("<![CDATA[", lt)) {
                val e = src.indexOf("]]>", lt)
                i = if (e < 0) n else e + 3
                continue
            }
            if (lt + 1 >= n) break
            val nx = src[lt + 1]
            if (!(nx.isLetter() || nx == '/' || nx == '!' || nx == '?')) {
                i = lt + 1
                continue
            }
            // Busca el '>' que cierra la etiqueta, respetando comillas.
            var j = lt + 1
            var q = '\u0000'
            var end = -1
            while (j < n) {
                val d = src[j]
                if (q != '\u0000') {
                    if (d == q) q = '\u0000'
                } else if (d == '"' || d == '\'') {
                    q = d
                } else if (d == '>') {
                    end = j
                    break
                }
                j++
            }
            if (end < 0) {
                err("línea ${lineAt(lt)}: etiqueta sin cerrar '>' (¿se cortó el código?)")
                return
            }
            val inner = src.substring(lt + 1, end)
            if (inner.startsWith("!") || inner.startsWith("?")) {
                i = end + 1
                continue
            }
            if (inner.startsWith("/")) {
                val name = inner.substring(1).trim().lowercase()
                val idx = stack.indexOfLast { it.first == name }
                if (idx < 0) {
                    err("línea ${lineAt(lt)}: </$name> cierra una etiqueta que no se abrió")
                } else {
                    for (k in stack.size - 1 downTo idx + 1) {
                        val o = stack[k]
                        if (o.first !in OPTIONAL_CLOSE) {
                            err("<${o.first}> (línea ${o.second}) no se cerró antes de </$name> en la línea ${lineAt(lt)}")
                        }
                    }
                    while (stack.size > idx) stack.removeAt(stack.size - 1)
                }
                i = end + 1
                continue
            }
            val selfClose = inner.endsWith("/")
            val name = inner.trimEnd('/').trim().split(Regex("\\s+"))[0].lowercase()
            val tagLine = lineAt(lt)
            if (html && (name == "script" || name == "style") && !selfClose) {
                val closeIdx = src.indexOf("</$name", end + 1, ignoreCase = true)
                if (closeIdx < 0) {
                    err("línea $tagLine: <$name> sin cerrar (¿se cortó el código?)")
                    return
                }
                val body = src.substring(end + 1, closeIdx)
                val attrs = inner.lowercase()
                val bodyLine = tagLine + src.substring(lt, end + 1).count { it == '\n' }
                if (body.isNotBlank()) {
                    if (name == "style") css(body, bodyLine, errors, "CSS en HTML")
                    else if (!attrs.contains("src=")) {
                        val isJson = attrs.contains("json") || attrs.contains("importmap")
                        val isOther = attrs.contains("text/template") || attrs.contains("x-shader") || attrs.contains("text/x-")
                        if (isJson) json(body, errors, "JSON en HTML")
                        else if (!isOther) js(body, bodyLine, errors, "JS en HTML")
                    }
                }
                val ce = src.indexOf('>', closeIdx)
                i = if (ce < 0) n else ce + 1
                continue
            }
            if (!selfClose && name !in VOID) stack.add(name to tagLine)
            i = end + 1
        }
        for (o in stack) {
            if (o.first !in OPTIONAL_CLOSE) {
                err("<${o.first}> abierta en la línea ${o.second} nunca se cerró (¿se cortó el código?)")
            }
        }
        if (html && src.contains("<html", ignoreCase = true) && !src.contains("viewport", ignoreCase = true)) {
            warnings.add("falta <meta name=\"viewport\"> para móvil (se añade solo en la vista previa)")
        }
    }
}
