package com.nexus.ai.actions

import android.content.Context
import com.google.gson.Gson
import java.text.Normalizer

/**
 * Protocolo de ejecución única (idempotencia): una acción de sistema que ya quedó COMPLETADA
 * no se vuelve a invocar en turnos siguientes salvo orden directa del usuario.
 */
class ActionLedger(ctx: Context) {
    data class Entry(var key: String = "", var label: String = "", var turn: Int = 0, var tool: String = "")

    private val sp = ctx.applicationContext.getSharedPreferences("nexus_ledger", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val sideEffect = setOf(
        "open_app", "youtube_search", "play_music", "web_search", "open_url", "navigate", "dial", "sms",
        "set_alarm", "set_timer", "set_volume", "set_brightness", "flashlight", "open_settings",
        "generate_image", "remember"
    )
    private val stateTools = setOf("flashlight", "set_volume", "set_brightness")

    private val toolWords = mapOf(
        "generate_image" to listOf("imagen", "foto", "dibuj", "ilustr", "genera", "crea", "pinta"),
        "open_app" to listOf("abre", "abrir", "inicia", "lanza", "ejecuta"),
        "youtube_search" to listOf("youtube", "video"),
        "play_music" to listOf("musica", "cancion", "pon ", "reproduc", "tema"),
        "web_search" to listOf("busca", "google", "investiga"),
        "open_url" to listOf("abre", "enlace", "pagina", "link"),
        "navigate" to listOf("ruta", "navega", "llevame", "como llego", "mapa"),
        "dial" to listOf("llama", "marca", "telefono"),
        "sms" to listOf("mensaje", "sms", "escribe", "manda"),
        "set_alarm" to listOf("alarma", "despiert"),
        "set_timer" to listOf("temporizador", "timer", "cronometro", "minutos"),
        "set_volume" to listOf("volumen", "sube", "baja"),
        "set_brightness" to listOf("brillo"),
        "flashlight" to listOf("linterna", "luz", "enciende", "apaga"),
        "open_settings" to listOf("ajustes", "configuracion", "wifi", "bluetooth"),
        "remember" to listOf("recuerda", "acuerdate", "guarda")
    )
    private val repeat = Regex("(otra vez|de nuevo|nuevamente|vuelve a|repite|repetir|otra mas|una mas|otro mas|again)")

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun load(conv: Long): MutableList<Entry> = runCatching {
        gson.fromJson(sp.getString("c$conv", "[]"), Array<Entry>::class.java).toMutableList()
    }.getOrDefault(mutableListOf())

    private fun save(conv: Long, l: List<Entry>) {
        sp.edit().putString("c$conv", gson.toJson(l.takeLast(60))).apply()
    }

    fun keyOf(a: ParsedAction): String =
        a.tool + "|" + a.args.entrySet().sortedBy { it.key }.joinToString(",") { it.key + "=" + it.value.toString() }

    private fun directOrder(a: ParsedAction, userText: String): Boolean {
        val u = norm(userText)
        if (repeat.containsMatchIn(u)) return true
        if (toolWords[a.tool].orEmpty().any { u.contains(it) }) return true
        val tokens = a.args.entrySet().filter { it.value.isJsonPrimitive }
            .flatMap { norm(it.value.asString).split(Regex("[^a-z0-9]+")) }
            .filter { it.length >= 4 }
        return tokens.any { u.contains(it) }
    }

    /** null = se puede ejecutar; texto = motivo por el que se omite. */
    fun check(conv: Long, a: ParsedAction, turn: Int, userText: String): String? {
        if (a.tool !in sideEffect) return null
        val e = load(conv).firstOrNull { it.key == keyOf(a) } ?: return null
        if (e.turn == turn) return "ya estaba COMPLETADO en este mismo turno"
        if (directOrder(a, userText)) return null
        return "ya estaba COMPLETADO antes y el usuario no pidió repetirlo"
    }

    fun complete(conv: Long, a: ParsedAction, label: String, turn: Int) {
        if (a.tool !in sideEffect) return
        val l = load(conv)
        val k = keyOf(a)
        l.removeAll { it.key == k || (a.tool in stateTools && it.tool == a.tool) }
        l.add(Entry(k, label, turn, a.tool))
        save(conv, l)
    }

    /** Bloque para el prompt: lo ya hecho, para que la IA no lo repita. */
    fun block(conv: Long): String =
        load(conv).takeLast(15).joinToString("\n") { "✓ COMPLETADO: ${it.label}" }
}
