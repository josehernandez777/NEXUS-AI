package com.nexus.ai.actions

import com.google.gson.JsonObject
import com.google.gson.JsonParser

data class ParsedAction(val tool: String, val args: JsonObject)
data class Parsed(val text: String, val actions: List<ParsedAction>)

private val ALIASES = mapOf(
    "query" to listOf("q", "search", "search_query", "searchQuery", "term", "keywords", "consulta", "busqueda", "búsqueda", "text", "title", "song", "video", "name"),
    "app" to listOf("name", "app_name", "appName", "nombre", "package", "application"),
    "place" to listOf("destination", "location", "address", "destino", "lugar", "query"),
    "number" to listOf("phone", "phone_number", "phoneNumber", "telefono", "teléfono", "numero", "número", "tel"),
    "text" to listOf("message", "msg", "content", "texto", "body", "mensaje"),
    "url" to listOf("link", "uri", "address", "enlace"),
    "page" to listOf("section", "setting", "screen"),
    "percent" to listOf("level", "value", "porcentaje", "volume", "brightness"),
    "action" to listOf("type", "name", "accion", "acción"),
    "prompt" to listOf("description", "descripcion", "descripción", "query", "text", "image", "idea"),
    "seconds" to listOf("duration", "segundos", "time"),
    "hour" to listOf("hora", "hours"),
    "fact" to listOf("memory", "recuerdo", "dato", "text", "info", "note"),
    "minute" to listOf("minuto", "minutes", "min")
)

// Claves de texto principal: si solo llega un valor, se usa para cualquiera de ellas.
private val MAIN_KEYS = setOf("query", "app", "place", "url", "text", "page", "action", "prompt", "fact")

private fun JsonObject.direct(key: String): String? {
    val e = get(key) ?: return null
    return if (e.isJsonPrimitive) e.asString else null
}

fun JsonObject.str(key: String): String? {
    direct(key)?.let { return it }
    ALIASES[key]?.forEach { alt -> direct(alt)?.let { return it } }
    if (key in MAIN_KEYS) {
        val prims = entrySet().filter { it.value.isJsonPrimitive }
        if (prims.size == 1) return prims[0].value.asString
    }
    return null
}

fun JsonObject.num(key: String): Double? = str(key)?.toDoubleOrNull()

fun JsonObject.bool(key: String): Boolean? = str(key)?.lowercase()?.let { it == "true" }

object ActionParser {
    private val re = Regex("""\[\[ACTION\s*(\{.*?\})\s*\]\]""", RegexOption.DOT_MATCHES_ALL)

    // Bloques de archivo con código en bruto (sin escapar JSON): ahorra tokens y evita errores.
    private val fileRe = Regex(
        "\\[\\[FILE\\s+([^\\]\\n]*)\\]\\][ \\t]*\\r?\\n?(.*?)\\r?\\n?\\[\\[/FILE\\]\\]",
        RegexOption.DOT_MATCHES_ALL
    )
    private val attrRe = Regex("(\\w+)\\s*=\\s*\"([^\"]*)\"")

    private fun fileAction(header: String, content: String): ParsedAction {
        val attrs = attrRe.findAll(header).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
        val o = JsonObject()
        o.addProperty("project", attrs["project"] ?: attrs["proyecto"] ?: "")
        o.addProperty("path", attrs["path"] ?: attrs["file"] ?: attrs["archivo"] ?: "")
        o.addProperty("content", content)
        var part = 1
        var parts = 1
        val pv = attrs["part"] ?: attrs["parte"]
        if (pv != null) {
            if (pv.contains("/")) {
                part = pv.substringBefore('/').trim().toIntOrNull() ?: 1
                parts = pv.substringAfter('/').trim().toIntOrNull() ?: 1
            } else {
                part = pv.trim().toIntOrNull() ?: 1
                parts = (attrs["parts"] ?: attrs["partes"])?.trim()?.toIntOrNull() ?: part
            }
        }
        o.addProperty("part", part.coerceAtLeast(1))
        o.addProperty("parts", parts.coerceAtLeast(1))
        return ParsedAction("create_file", o)
    }

    /** Acorta el contenido de los archivos ya guardados para no inflar el contexto. */
    fun compact(raw: String): String = fileRe.replace(raw) { m ->
        val body = m.groupValues[2]
        val tail = if (body.length > 300) body.takeLast(300) else body
        "[[FILE " + m.groupValues[1] + "]]\n…(contenido enviado, ${body.length} caracteres)…\n" + tail + "\n[[/FILE]]"
    }

    fun parse(raw0: String): Parsed {
        val actions = mutableListOf<ParsedAction>()
        var raw = raw0
        for (m in fileRe.findAll(raw0)) {
            actions.add(fileAction(m.groupValues[1], m.groupValues[2]))
        }
        raw = fileRe.replace(raw, "")
        val open = raw.indexOf("[[FILE")
        if (open >= 0) {
            actions.add(ParsedAction("file_truncated", JsonObject()))
            raw = raw.substring(0, open)
        }
        for (m in re.findAll(raw)) {
            try {
                val o = JsonParser.parseString(m.groupValues[1]).asJsonObject
                val tool = o.get("tool")?.asString
                if (tool != null) {
                    val argsEl = o.get("args")
                    val args = when {
                        argsEl != null && argsEl.isJsonObject -> argsEl.asJsonObject
                        argsEl != null && argsEl.isJsonPrimitive ->
                            JsonObject().apply { addProperty("_value", argsEl.asString) }
                        else -> JsonObject().also { j ->
                            o.entrySet().forEach { (k, v) -> if (k != "tool") j.add(k, v) }
                        }
                    }
                    actions.add(ParsedAction(tool, args))
                }
            } catch (e: Exception) {
                // acción mal formada: se ignora
            }
        }
        return Parsed(re.replace(raw, "").trim(), actions)
    }
}
