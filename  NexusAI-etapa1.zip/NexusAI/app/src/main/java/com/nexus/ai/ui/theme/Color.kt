package com.nexus.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta Neón Ciberpunk: base #05050A con acentos cian, magenta y dorado.
val Violet500 = Color(0xFF7C4DFF)
val Violet300 = Color(0xFFB8A6FF)
val Purple700 = Color(0xFF5B2DD6)
val Magenta = Color(0xFFFF0055)
val Cyan400 = Color(0xFF00FFCC)
val Gold = Color(0xFFFFB700)
val NeonGreen = Color(0xFF00E676)
val AmoledBlack = Color(0xFF05050A)
val SurfaceDark = Color(0xFF0A0A14)
val SurfaceDark2 = Color(0xFF14141F)
val LightBg = Color(0xFFF6F8FB)
