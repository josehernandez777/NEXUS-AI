package com.nexus.ai.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.nexus.ai.fx.Aura
import com.nexus.ai.fx.AuraKind
import com.nexus.ai.fx.Haptics
import com.nexus.ai.fx.Sfx
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Gold

/** Vista previa a pantalla completa de un proyecto servido por el servidor local embebido. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewDialog(url: String, title: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val web = remember { mutableStateOf<WebView?>(null) }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "▶ $title",
                    style = MaterialTheme.typography.titleMedium,
                    color = Gold,
                    modifier = Modifier.weight(1f).padding(start = 8.dp)
                )
                IconButton(onClick = { web.value?.reload() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Recargar", tint = Cyan400)
                }
                IconButton(onClick = {
                    runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }) {
                    Icon(Icons.Filled.OpenInBrowser, contentDescription = "Abrir en el navegador", tint = Cyan400)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Cerrar")
                }
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.allowFileAccess = false
                        settings.setSupportZoom(false)
                        setBackgroundColor(android.graphics.Color.parseColor("#05050A"))
                        webViewClient = WebViewClient()
                        webChromeClient = object : WebChromeClient() {
                            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                                    Aura.flash(AuraKind.ERROR, 2200L)
                                    Haptics.error(c)
                                    Sfx.play(c, "error")
                                }
                                return true
                            }
                        }
                        loadUrl(url)
                        web.value = this
                    }
                },
                onRelease = { it.destroy() }
            )
        }
    }
}
