package com.nexus.ai.fx

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.VibrationEffect
import android.os.Vibrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/** Preferencias de efectos (borde de luz, vibración, sonidos). */
object FxPrefs {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("nexus_fx", Context.MODE_PRIVATE)

    fun aura(ctx: Context) = sp(ctx).getBoolean("aura", true)
    fun haptics(ctx: Context) = sp(ctx).getBoolean("haptics", true)
    fun sounds(ctx: Context) = sp(ctx).getBoolean("sounds", true)
    fun setAura(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("aura", v).apply()
    fun setHaptics(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("haptics", v).apply()
    fun setSounds(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("sounds", v).apply()
}

enum class AuraKind { NONE, THINKING, SUCCESS, ERROR }

/** Borde de pantalla reactivo: cian pensando, verde éxito, rojo error. */
object Aura {
    private val _kind = MutableStateFlow(AuraKind.NONE)
    val kind: StateFlow<AuraKind> = _kind.asStateFlow()
    private var hold: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun thinking() {
        if (hold?.isActive != true) _kind.value = AuraKind.THINKING
    }

    fun idle() {
        if (_kind.value == AuraKind.THINKING) _kind.value = AuraKind.NONE
    }

    fun flash(k: AuraKind, ms: Long = 1800L) {
        hold?.cancel()
        _kind.value = k
        hold = scope.launch {
            delay(ms)
            _kind.value = AuraKind.NONE
        }
    }
}

/** Patrones de vibración: doble pulso (listo), pulso suave (trabajando), triplete (error). */
object Haptics {
    private fun play(ctx: Context, timings: LongArray, amps: IntArray) {
        if (!FxPrefs.haptics(ctx)) return
        runCatching {
            val v = ctx.getSystemService(Vibrator::class.java) ?: return
            if (!v.hasVibrator()) return
            val fx = if (v.hasAmplitudeControl()) VibrationEffect.createWaveform(timings, amps, -1)
            else VibrationEffect.createWaveform(timings, -1)
            v.vibrate(fx)
        }
    }

    fun done(ctx: Context) =
        play(ctx, longArrayOf(0, 45, 80, 45), intArrayOf(0, 220, 0, 220))

    fun working(ctx: Context) =
        play(ctx, longArrayOf(0, 90, 90, 90, 90, 90), intArrayOf(0, 35, 70, 105, 70, 35))

    fun error(ctx: Context) =
        play(ctx, longArrayOf(0, 35, 55, 35, 55, 35), intArrayOf(0, 255, 0, 255, 0, 255))
}

/** Micro-sonidos sintéticos generados por frecuencia: no ocupan almacenamiento. */
object Sfx {
    private const val SR = 22050
    private val cache = HashMap<String, ShortArray>()

    private fun seq(vararg tones: Pair<Double, Int>): ShortArray {
        val total = tones.sumOf { it.second * SR / 1000 }
        val out = ShortArray(total)
        var pos = 0
        for ((f, ms) in tones) {
            val n = ms * SR / 1000
            for (i in 0 until n) {
                val env = minOf(1.0, i / (0.01 * SR), (n - i) / (0.03 * SR)).coerceAtLeast(0.0)
                val t = i.toDouble() / SR
                val s = if (f <= 0.0) 0.0 else (sin(2 * PI * f * t) + 0.25 * sin(4 * PI * f * t)) * env * 0.22
                out[pos + i] = (s * Short.MAX_VALUE).toInt().toShort()
            }
            pos += n
        }
        return out
    }

    private fun buffer(kind: String): ShortArray = cache.getOrPut(kind) {
        when (kind) {
            "send" -> seq(700.0 to 40, 1000.0 to 60)
            "done" -> seq(660.0 to 70, 0.0 to 30, 990.0 to 120)
            "working" -> seq(440.0 to 70)
            "error" -> seq(330.0 to 100, 220.0 to 180)
            else -> seq(900.0 to 30)
        }
    }

    /** kind: send | done | working | error | tap */
    fun play(ctx: Context, kind: String) {
        if (!FxPrefs.sounds(ctx)) return
        Thread {
            runCatching {
                val data = buffer(kind)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.play()
                Thread.sleep(data.size * 1000L / SR + 120L)
                track.release()
            }
        }.start()
    }
}
