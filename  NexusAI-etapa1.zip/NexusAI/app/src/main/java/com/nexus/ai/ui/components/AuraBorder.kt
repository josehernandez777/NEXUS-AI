package com.nexus.ai.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nexus.ai.fx.Aura
import com.nexus.ai.fx.AuraKind
import com.nexus.ai.fx.FxPrefs
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.NeonGreen

/** Borde de pantalla reactivo: cian = pensando, verde = éxito, rojo/magenta = error. */
@Composable
fun AuraBorder() {
    val ctx = LocalContext.current
    val kind by Aura.kind.collectAsState()
    var shown by remember { mutableStateOf(AuraKind.THINKING) }
    LaunchedEffect(kind) { if (kind != AuraKind.NONE) shown = kind }
    val enabled = remember(kind) { FxPrefs.aura(ctx) }
    val alphaK by animateFloatAsState(
        if (enabled && kind != AuraKind.NONE) 1f else 0f, tween(420), label = "auraA"
    )
    val t = rememberInfiniteTransition(label = "aura")
    val pulse by t.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(if (shown == AuraKind.THINKING) 1200 else 600), RepeatMode.Reverse),
        label = "auraP"
    )
    if (alphaK < 0.01f) return
    val color = when (shown) {
        AuraKind.SUCCESS -> NeonGreen
        AuraKind.ERROR -> Magenta
        else -> Cyan400
    }
    Canvas(Modifier.fillMaxSize()) {
        val th = 40.dp.toPx() * (0.75f + 0.5f * pulse)
        val a = alphaK * (0.30f + 0.45f * pulse)
        val c0 = color.copy(alpha = a)
        val c1 = Color.Transparent
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(c0, c1), 0f, th), Offset.Zero, Size(w, th))
        drawRect(Brush.verticalGradient(listOf(c1, c0), h - th, h), Offset(0f, h - th), Size(w, th))
        drawRect(Brush.horizontalGradient(listOf(c0, c1), 0f, th), Offset.Zero, Size(th, h))
        drawRect(Brush.horizontalGradient(listOf(c1, c0), w - th, w), Offset(w - th, 0f), Size(th, h))
        drawRoundRect(
            color.copy(alpha = alphaK * (0.45f + 0.5f * pulse)),
            topLeft = Offset(1.dp.toPx(), 1.dp.toPx()),
            size = Size(w - 2.dp.toPx(), h - 2.dp.toPx()),
            cornerRadius = CornerRadius(26.dp.toPx()),
            style = Stroke(2.dp.toPx())
        )
    }
}
