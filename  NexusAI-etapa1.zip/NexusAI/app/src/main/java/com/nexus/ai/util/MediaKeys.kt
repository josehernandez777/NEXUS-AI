package com.nexus.ai.util

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Teclas multimedia (play/pausa, siguiente, anterior) para controlar el reproductor activo. */
object MediaKeys {
    const val PLAY_PAUSE = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
    const val NEXT = KeyEvent.KEYCODE_MEDIA_NEXT
    const val PREVIOUS = KeyEvent.KEYCODE_MEDIA_PREVIOUS

    fun send(ctx: Context, code: Int) {
        runCatching {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }
}
