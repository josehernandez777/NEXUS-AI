package com.nexus.ai.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.nexus.ai.dev.LocalServer
import com.nexus.ai.fx.Haptics
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Gold
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.NeonGreen
import com.nexus.ai.util.MediaKeys
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/** (url, título) -> abre la vista previa a pantalla completa. */
val LocalPreview = staticCompositionLocalOf<(String, String) -> Unit> { { _, _ -> } }

private fun JsonObject.s(k: String): String =
    get(k)?.takeIf { it.isJsonPrimitive }?.asString.orEmpty()

private fun JsonObject.d(k: String): Double =
    get(k)?.takeIf { it.isJsonPrimitive }?.asDouble ?: 0.0

/** Tarjeta de cristal: translúcida, con brillo y borde neón sutil. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    accent: Color = Cyan400,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .widthIn(max = 360.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.11f), Color.White.copy(alpha = 0.03f))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(accent.copy(alpha = 0.7f), Color.White.copy(alpha = 0.08f), Magenta.copy(alpha = 0.4f))),
                shape
            )
            .padding(16.dp),
        content = content
    )
}

@Composable
fun WidgetCard(json: String) {
    val o = remember(json) { runCatching { JsonParser.parseString(json).asJsonObject }.getOrNull() } ?: return
    when (o.s("type")) {
        "battery" -> BatteryWidget(o)
        "time" -> TimeWidget()
        "weather" -> WeatherWidget(o)
        "media" -> MediaWidget(o)
        "diagram" -> DiagramWidget(o)
        "project" -> ProjectWidget(o)
    }
}

@Composable
private fun BatteryWidget(o: JsonObject) {
    val pct = o.d("pct").toInt().coerceIn(0, 100)
    val charging = o.get("charging")?.asBoolean ?: false
    val color = when {
        charging || pct > 50 -> NeonGreen
        pct > 20 -> Gold
        else -> Magenta
    }
    val k = remember { Animatable(0f) }
    LaunchedEffect(pct) { k.animateTo(pct / 100f, tween(1000, easing = FastOutSlowInEasing)) }
    GlassCard(accent = color) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(84.dp)) {
                    val w = 9.dp.toPx()
                    val inset = w / 2
                    val sz = Size(size.width - w, size.height - w)
                    drawArc(color.copy(alpha = 0.16f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
                    drawArc(color, -90f, 360f * k.value, false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
                }
                Text("$pct%", style = MaterialTheme.typography.titleLarge, color = color)
            }
            Column(Modifier.padding(start = 16.dp)) {
                Text("Batería", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (charging) "⚡ Cargando" else "Sin cargar",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TimeWidget() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000)
        }
    }
    val hm = SimpleDateFormat("HH:mm", Locale("es")).format(Date(now))
    val sec = SimpleDateFormat("ss", Locale("es")).format(Date(now))
    val date = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es")).format(Date(now))
    GlassCard(accent = Gold) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                hm,
                style = MaterialTheme.typography.displayMedium.copy(
                    brush = Brush.linearGradient(listOf(Cyan400, Gold)),
                    fontWeight = FontWeight.ExtraBold
                )
            )
            Text(
                " $sec",
                style = MaterialTheme.typography.titleLarge,
                color = Gold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        Text(
            date.replaceFirstChar { it.uppercase() },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun weatherEmoji(desc: String): String = when {
    desc.contains("tormenta") -> "⛈️"
    desc.contains("nieve") -> "❄️"
    desc.contains("lluvia") || desc.contains("llovizna") || desc.contains("chubasco") -> "🌧️"
    desc.contains("niebla") -> "🌫️"
    desc.contains("parcialmente") -> "⛅"
    desc.contains("mayormente") -> "🌤️"
    desc.contains("nublado") -> "☁️"
    desc.contains("despejado") -> "☀️"
    else -> "🌡️"
}

@Composable
private fun WeatherWidget(o: JsonObject) {
    val desc = o.s("desc")
    GlassCard(accent = Cyan400) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(weatherEmoji(desc), fontSize = 48.sp)
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(
                    "%.0f°".format(o.d("temp")),
                    style = MaterialTheme.typography.displaySmall.copy(
                        brush = Brush.linearGradient(listOf(Cyan400, Gold)),
                        fontWeight = FontWeight.ExtraBold
                    )
                )
                Text(
                    desc.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(o.s("place"), style = MaterialTheme.typography.labelLarge, color = Gold, modifier = Modifier.padding(top = 6.dp))
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Sensación %.0f°".format(o.d("feels")))
            Chip("💧 %.0f%%".format(o.d("humidity")))
            Chip("💨 %.0f km/h".format(o.d("wind")))
        }
        val days = o.getAsJsonArray("days")
        if (days != null && days.size() > 0) {
            Row(Modifier.padding(top = 12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 0 until days.size()) {
                    val d = days[i].asJsonObject
                    val label = runCatching {
                        LocalDate.parse(d.s("date")).dayOfWeek
                            .getDisplayName(java.time.format.TextStyle.SHORT, Locale("es"))
                            .replaceFirstChar { it.uppercase() }
                    }.getOrDefault("")
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.06f))
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(weatherEmoji(d.s("desc")), fontSize = 22.sp)
                        Text("%.0f° / %.0f°".format(d.d("max"), d.d("min")), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
private fun MediaWidget(o: JsonObject) {
    val ctx = LocalContext.current
    var playing by remember { mutableStateOf(true) }
    val title = o.s("title")
    GlassCard(accent = Magenta) {
        Text("♪ REPRODUCTOR", style = MaterialTheme.typography.labelSmall, color = Magenta)
        Text(
            if (title.isBlank()) "Controles de medios" else title,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 2,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MediaBtn(Icons.Filled.SkipPrevious, 48) {
                Haptics.done(ctx)
                MediaKeys.send(ctx, MediaKeys.PREVIOUS)
            }
            MediaBtn(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, 62, big = true) {
                playing = !playing
                MediaKeys.send(ctx, MediaKeys.PLAY_PAUSE)
            }
            MediaBtn(Icons.Filled.SkipNext, 48) {
                Haptics.done(ctx)
                MediaKeys.send(ctx, MediaKeys.NEXT)
            }
        }
    }
}

@Composable
private fun MediaBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, size: Int, big: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(
                if (big) Brush.linearGradient(listOf(Cyan400, Magenta))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.06f)))
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = if (big) Color.Black else Color.White, modifier = Modifier.size((size * 0.5f).dp))
    }
}

@Composable
private fun DiagramWidget(o: JsonObject) {
    val edges = remember(o) {
        o.s("edges").split(';', '\n').mapNotNull { seg ->
            val parts = seg.split(Regex("\\s*(?:->|→|>)\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size >= 2) parts.zipWithNext() else null
        }.flatten()
    }
    val nodes = remember(edges) { edges.flatMap { listOf(it.first, it.second) }.distinct() }
    // Nivel de cada nodo = camino más largo desde una raíz (con tope para ciclos).
    val level = remember(edges) {
        val lv = HashMap<String, Int>()
        nodes.forEach { lv[it] = 0 }
        repeat(nodes.size.coerceAtMost(12)) {
            edges.forEach { (a, b) -> lv[b] = maxOf(lv[b] ?: 0, (lv[a] ?: 0) + 1).coerceAtMost(10) }
        }
        lv
    }
    val rows = remember(level) { nodes.groupBy { level[it] ?: 0 }.toSortedMap() }
    GlassCard(accent = Gold) {
        Text("◇ " + o.s("title").uppercase(), style = MaterialTheme.typography.labelMedium, color = Gold)
        Spacer(Modifier.height(10.dp))
        rows.entries.forEachIndexed { idx, (_, names) ->
            if (idx > 0) {
                Text("↓", color = Cyan400, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 18.sp)
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                names.forEach { n ->
                    Text(
                        n,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Cyan400.copy(alpha = 0.10f))
                            .border(1.dp, Cyan400.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
        val multi = edges.filter { e -> edges.count { it.second == e.second } > 1 || edges.count { it.first == e.first } > 1 }
        if (multi.isNotEmpty()) {
            Text(
                multi.joinToString("   ") { "${it.first} → ${it.second}" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun ProjectWidget(o: JsonObject) {
    val ctx = LocalContext.current
    val preview = LocalPreview.current
    val name = o.s("name")
    val entry = o.s("entry")
    val files = o.getAsJsonArray("files")?.map { it.asString }.orEmpty()
    val export = o.s("export")
    GlassCard(accent = NeonGreen) {
        Text("📁 " + name, style = MaterialTheme.typography.titleMedium, color = NeonGreen)
        val saved = o.s("saved")
        if (saved.isNotEmpty()) {
            Text("Guardado: $saved", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            files.take(8).forEach { f ->
                val icon = when (f.substringAfterLast('.', "")) {
                    "html", "htm" -> "🌐"
                    "css" -> "🎨"
                    "js", "mjs" -> "⚙️"
                    "json" -> "🧾"
                    else -> "📄"
                }
                Text("$icon  $f", style = MaterialTheme.typography.bodySmall)
            }
            if (files.size > 8) Text("… y ${files.size - 8} más", style = MaterialTheme.typography.labelSmall)
        }
        if (export.isNotEmpty()) {
            Text("Copia en $export", style = MaterialTheme.typography.labelSmall, color = Gold, modifier = Modifier.padding(top = 6.dp))
        }
        if (entry.isNotEmpty()) {
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(Brush.linearGradient(listOf(Cyan400, NeonGreen)))
                    .clickable {
                        Haptics.done(ctx)
                        preview(LocalServer.urlFor(ctx, name, entry), name)
                    }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("▶  Vista previa", color = Color.Black, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
