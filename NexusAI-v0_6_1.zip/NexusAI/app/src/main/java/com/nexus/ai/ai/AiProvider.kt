package com.nexus.ai.ai

import com.nexus.ai.data.ChatTurn

/** Abstracción del proveedor de IA: backend propio, Gemini directo, y mañana Claude u otro. */
data class AiOptions(
    val system: String,
    val models: List<String>,
    val maxTokens: Int,
    val temperature: Float,
    /** Prompt compacto para el modelo local (sin herramientas, cabe en poco contexto). */
    val localSystem: String = ""
)

interface AiProvider {
    suspend fun reply(history: List<ChatTurn>, options: AiOptions): Result<String>
}

sealed class AiError(message: String) : Exception(message) {
    object NotConfigured : AiError("Falta configurar la IA. Ve a Ajustes y pega tu clave de Gemini.")
    object InvalidUrl : AiError("La URL del backend debe empezar con https://")
    object Unauthorized : AiError("Token incorrecto. Revísalo en Ajustes.")
    object InvalidKey : AiError("La clave de Gemini no es válida. Revísala en Ajustes.")
    object Quota : AiError("Demasiadas solicitudes seguidas. Espera un momento e intenta de nuevo.")
    object ModelNotFound : AiError("Gemini no encontró ningún modelo disponible para tu clave (404).")
    object Busy : AiError("Gemini está saturado en este momento. Intenta de nuevo en unos segundos.")
    object Network : AiError("No se pudo conectar. Revisa tu internet.")
    object LocalNotReady : AiError("El modo sin conexión es opcional y no está configurado. Usa Automático o Nube.")
    object LocalNoMedia : AiError("El modo local aún no entiende imágenes ni audio. Cambia a Automático o Nube.")
    object PrivateOnly : AiError("Modo Privado activo: no salgo a internet. Cambia la ruta en Ajustes si lo necesitas.")
    class Server(msg: String) : AiError("Error: $msg")
}
