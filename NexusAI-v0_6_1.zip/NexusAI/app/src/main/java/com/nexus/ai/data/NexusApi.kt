package com.nexus.ai.data

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

/** Un turno de la conversación (role: "user" o "assistant"). */
data class ChatTurn(
    val role: String,
    val content: String,
    /** Adjunto opcional (imagen o audio) en base64 y su tipo MIME. Solo viaja a la nube. */
    val mime: String? = null,
    val media: String? = null
)
data class ChatRequest(val messages: List<ChatTurn>, val system: String? = null)
data class ChatResponse(val reply: String? = null, val error: String? = null)

interface NexusApi {
    @POST
    suspend fun chat(
        @Url url: String,
        @Header("X-App-Token") token: String,
        @Body body: ChatRequest
    ): ChatResponse
}
