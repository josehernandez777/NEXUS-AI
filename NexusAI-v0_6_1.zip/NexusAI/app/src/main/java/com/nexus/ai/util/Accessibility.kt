package com.nexus.ai.util

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import com.nexus.ai.service.NexusAccessibilityService

fun isAccessibilityEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val me = ComponentName(ctx, NexusAccessibilityService::class.java).flattenToString()
    return enabled.split(':').any { it.equals(me, ignoreCase = true) }
}
