package com.nexus.ai.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.nexus.ai.ui.assist.AssistActivity

/** Mosaico de Ajustes rápidos: un toque desde el panel de notificaciones abre NEXUS. */
class NexusTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "NEXUS"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val i = Intent(this, AssistActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivityAndCollapse(i)
    }
}
