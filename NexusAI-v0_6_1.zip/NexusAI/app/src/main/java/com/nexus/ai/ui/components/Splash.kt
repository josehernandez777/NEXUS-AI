package com.nexus.ai.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet300
import com.nexus.ai.ui.theme.Violet500
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Animación de entrada: el logo se dibuja trazo a trazo, florece un halo,
 * el nombre aparece letra por letra y todo se disuelve hacia la app.
 */
@Composable
fun NexusSplash(onFinished: () -> Unit) {
    val draw = remember { Animatable(0f) }
    val letters = remember { Animatable(0f) }
    val tagline = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { draw.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
            launch { burst.animateTo(1f, tween(1900, easing = LinearEasing)) }
            launch {
                delay(800)
                letters.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
            }
            launch {
                delay(1500)
                tagline.animateTo(1f, tween(600))
            }
        }
        delay(450)
        exit.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = 1f - exit.value
                val s = 1f + 0.10f * exit.value
                scaleX = s
                scaleY = s
            }
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {}
            ),
        contentAlignment = Alignment.Center
    ) {
        // Auroras de fondo que se encienden con el logo.
        Canvas(Modifier.fillMaxSize()) {
            val k = draw.value
            drawRect(
                Brush.radialGradient(
                    listOf(Violet500.copy(alpha = 0.34f * k), Color.Transparent),
                    Offset(size.width * 0.5f, size.height * 0.42f), size.width * 1.0f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(Cyan400.copy(alpha = 0.16f * k), Color.Transparent),
                    Offset(size.width * 0.9f, size.height * 0.9f), size.width * 0.9f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(Magenta.copy(alpha = 0.14f * k), Color.Transparent),
                    Offset(size.width * 0.1f, size.height * 0.15f), size.width * 0.8f
                )
            )
            // Onda expansiva cuando el logo termina de dibujarse.
            val b = burst.value
            if (b > 0.45f) {
                val q = ((b - 0.45f) / 0.55f).coerceIn(0f, 1f)
                drawCircle(
                    Cyan400.copy(alpha = 0.35f * (1f - q)),
                    radius = size.width * (0.18f + 0.55f * q),
                    center = Offset(size.width / 2f, size.height * 0.42f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.graphicsLayer {
                    val s = 0.82f + 0.18f * draw.value
                    scaleX = s
                    scaleY = s
                }
            ) {
                NexusLogo(Modifier.size(190.dp), animated = true, progress = draw.value)
            }
            Spacer(Modifier.height(26.dp))
            val word = "NEXUS"
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                word.forEachIndexed { i, ch ->
                    val p = (letters.value * (word.length + 1.5f) - i).coerceIn(0f, 1f)
                    Text(
                        ch.toString(),
                        style = MaterialTheme.typography.displaySmall.copy(
                            brush = Brush.linearGradient(listOf(Cyan400, Violet300, Magenta)),
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        ),
                        modifier = Modifier.graphicsLayer {
                            alpha = p
                            translationY = (1f - p) * 28.dp.toPx()
                            val s = 0.8f + 0.2f * p
                            scaleX = s
                            scaleY = s
                        }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "INTELIGENCIA ARTIFICIAL",
                style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 4.sp),
                color = Violet300.copy(alpha = 0.85f),
                modifier = Modifier.graphicsLayer {
                    alpha = tagline.value
                    translationY = (1f - tagline.value) * 10.dp.toPx()
                }
            )
        }
    }
}
