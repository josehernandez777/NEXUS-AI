package com.nexus.ai.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet500
import com.nexus.ai.util.launchAssistant
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Slider
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.ai.util.isAccessibilityEnabled

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val ctx = LocalContext.current
    val cfg by vm.config.collectAsStateWithLifecycle()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val voices by vm.voices.collectAsStateWithLifecycle()
    var rate by remember(prefs.rate) { mutableFloatStateOf(prefs.rate) }
    var pitch by remember(prefs.pitch) { mutableFloatStateOf(prefs.pitch) }
    var menuOpen by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var gKey by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var a11yOn by remember { mutableStateOf(isAccessibilityEnabled(ctx)) }
    var canWrite by remember { mutableStateOf(Settings.System.canWrite(ctx)) }
    var canOverlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var advOpen by remember { mutableStateOf(false) }
    var memText by remember { mutableStateOf("") }
    var confirmClearMemory by remember { mutableStateOf(false) }
    val memories by vm.memories.collectAsStateWithLifecycle()
    val modelMsg by vm.modelMsg.collectAsStateWithLifecycle()
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        a11yOn = isAccessibilityEnabled(ctx)
        canWrite = Settings.System.canWrite(ctx)
        canOverlay = Settings.canDrawOverlays(ctx)
    }
    LaunchedEffect(cfg) {
        cfg?.let { url = it.url; token = it.token; gKey = it.geminiKey }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium.copy(brush = Brush.linearGradient(listOf(com.nexus.ai.ui.theme.Cyan400, com.nexus.ai.ui.theme.Violet300, Magenta))))

        SectionHeader("Invocar a NEXUS")
        Text(
            "Habla con NEXUS desde cualquier app, sin abrirla. Elígelo como asistente del sistema " +
                "(mantener Inicio o el botón lateral), usa el mosaico «NEXUS» en Ajustes rápidos " +
                "o el doble toque de volumen.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { launchAssistant(ctx) }) { Text("Probar ahora") }
            OutlinedButton(onClick = {
                val i = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { ctx.startActivity(i) }.onFailure {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }) { Text("Elegir como asistente") }
        }
        SettingSwitch(
            "Doble toque de volumen",
            if (a11yOn) "Toca dos veces Vol+ o Vol− para abrir NEXUS (con la pantalla encendida)"
            else "Requiere activar la accesibilidad de NEXUS (más abajo)",
            prefs.volumeTrigger
        ) { vm.setVolumeTrigger(it) }
        Text(
            if (canOverlay) "Mostrar sobre otras apps: permitido ✓" else "Mostrar sobre otras apps: sin permiso",
            color = if (canOverlay) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!canOverlay) {
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("Permitir (recomendado para el doble volumen)") }
        }

        SectionHeader("Control del teléfono")
        Text(
            if (a11yOn) "Accesibilidad: activada ✓" else "Accesibilidad: desactivada",
            color = if (a11yOn) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "Con accesibilidad NEXUS puede leer la pantalla, tocar, escribir y navegar cuando tú se lo pidas. " +
                "Entra, busca «NEXUS AI» y actívalo.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Abrir ajustes de accesibilidad") }

        Text(
            if (canWrite) "Cambiar brillo: permitido ✓" else "Cambiar brillo: sin permiso",
            color = if (canWrite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!canWrite) {
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("Permitir cambiar el brillo") }
        }
        SettingSwitch(
            "Pedir confirmación",
            "Antes de tocar o escribir en otras apps",
            prefs.confirm
        ) { vm.setConfirm(it) }

        SectionHeader("IA y privacidad")
        val hasModel = prefs.localModel.isNotBlank()
        Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val routes = if (hasModel) listOf("AUTO" to "Automático", "LOCAL" to "Privado (sin internet)", "CLOUD" to "Solo nube")
            else listOf("AUTO" to "Automático", "CLOUD" to "Solo nube")
            routes.forEach { (k, label) ->
                SettingPill(label, (if (!hasModel && prefs.route == "LOCAL") "AUTO" else prefs.route) == k) { vm.setRoute(k) }
            }
        }
        Text(
            when {
                prefs.route == "LOCAL" && hasModel -> "Todo se procesa en el teléfono. Sin internet, sin herramientas web ni imágenes. Nada sale del dispositivo."
                prefs.route == "CLOUD" -> "Siempre usa la IA en la nube (Gemini), con todas las herramientas."
                else -> "NEXUS usa la IA en la nube (más capaz, con herramientas). No necesitas descargar nada."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // IA sin conexión: totalmente opcional y escondida por defecto.
        TextButton(onClick = { advOpen = !advOpen }) {
            Text(if (advOpen) "Ocultar opciones avanzadas ▲" else "Avanzado: IA sin conexión (opcional) ▼")
        }
        androidx.compose.animation.AnimatedVisibility(visible = advOpen) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Solo si quieres usar NEXUS sin internet: elige un archivo de modelo (.task) que ya tengas en el teléfono. " +
                        "NEXUS funciona perfectamente sin esto, no hace falta descargar nada.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    if (!hasModel) "Modelo sin conexión: ninguno" else "Modelo sin conexión: " + prefs.localModel.substringAfterLast('/'),
                    color = if (!hasModel) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.tertiary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickModel.launch(arrayOf("*/*")) }) { Text("Elegir archivo") }
                    if (hasModel) {
                        OutlinedButton(onClick = { vm.removeModel() }) { Text("Quitar") }
                    }
                }
                modelMsg?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }

SectionHeader("Memoria")
        SettingSwitch(
            "Memoria a largo plazo",
            "NEXUS recuerda tus preferencias, rutinas y proyectos. Se guarda solo en este teléfono.",
            prefs.memoryOn
        ) { vm.setMemoryOn(it) }
        if (prefs.memoryOn && !(prefs.route == "LOCAL" && prefs.localModel.isNotBlank())) {
            Text(
                "Con la IA en la nube, los recuerdos viajan dentro de cada petición. Puedes desactivar la memoria si no quieres eso.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = memText,
                onValueChange = { memText = it },
                label = { Text("Añadir recuerdo") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { vm.addMemory(memText); memText = "" }, enabled = memText.isNotBlank()) { Text("Guardar") }
        }
        if (memories.isEmpty()) {
            Text(
                "Aún no recuerdo nada. Cuéntame tus gustos o proyectos y los guardaré, o añade uno arriba.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            memories.take(60).forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = { vm.deleteMemory(m.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Olvidar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            OutlinedButton(onClick = { confirmClearMemory = true }) { Text("Borrar toda la memoria") }
        }

        SectionHeader("Apariencia")
        SettingSwitch("Fondo animado", "Auroras suaves (solo en modo oscuro)", prefs.aurora) { vm.setAurora(it) }
        if (Build.VERSION.SDK_INT >= 31) {
            SettingSwitch("Colores del sistema", "Usa la paleta de tu fondo de pantalla (Material You)", prefs.dynamicColor) {
                vm.setDynamicColor(it)
            }
        }

        SectionHeader("Voz")
        SettingSwitch("Leer respuestas en voz alta", "NEXUS habla cada respuesta nueva", prefs.autoSpeak) {
            vm.setAutoSpeak(it)
        }
        Text("Velocidad: ${"%.1f".format(rate)}x")
        Slider(
            value = rate,
            onValueChange = { rate = it },
            onValueChangeFinished = { vm.setRate(rate) },
            valueRange = 0.5f..2f
        )
        Text("Tono: ${"%.1f".format(pitch)}")
        Slider(
            value = pitch,
            onValueChange = { pitch = it },
            onValueChangeFinished = { vm.setPitch(pitch) },
            valueRange = 0.5f..2f
        )
        Box {
            OutlinedButton(onClick = { menuOpen = true }) {
                Text("Voz: " + (voices.firstOrNull { it.name == prefs.voiceName }?.label ?: "Predeterminada"))
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Predeterminada") },
                    onClick = { vm.setVoice(""); menuOpen = false }
                )
                voices.forEach { v ->
                    DropdownMenuItem(
                        text = { Text(v.label) },
                        onClick = { vm.setVoice(v.name); menuOpen = false }
                    )
                }
            }
        }
        OutlinedButton(onClick = { vm.previewVoice() }) { Text("Probar voz") }

        SectionHeader("Conexión con la IA")
        Text(
            "Modo directo: pega tu clave de aistudio.google.com (se guarda solo en este teléfono).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = gKey,
            onValueChange = { gKey = it; saved = false },
            label = { Text("Clave de Gemini") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Modo backend (opcional): si pones un token, se usa el backend en vez de la clave directa.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = url,
            onValueChange = { url = it; saved = false },
            label = { Text("URL del backend (https://…)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = token,
            onValueChange = { token = it; saved = false },
            label = { Text("Token del backend") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.save(url, token, gKey); saved = true }) {
            Text(if (saved) "Guardado ✓" else "Guardar")
        }

        SectionHeader("Historial")
        OutlinedButton(onClick = { confirmClear = true }) { Text("Borrar todo el historial") }

        Text(
            "NEXUS AI v0.6.0",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (confirmClearMemory) {
        AlertDialog(
            onDismissRequest = { confirmClearMemory = false },
            title = { Text("¿Borrar la memoria?") },
            text = { Text("NEXUS olvidará todo lo que recuerda de ti. No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { vm.clearMemory(); confirmClearMemory = false }) { Text("Borrar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearMemory = false }) { Text("Cancelar") }
            }
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("¿Borrar historial?") },
            text = { Text("Se eliminarán todas las conversaciones de este teléfono.") },
            confirmButton = {
                TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Borrar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier =
    this.horizontalScroll(rememberScrollState())

@Composable
private fun SettingPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    val base = Modifier.clip(shape)
    val styled = if (selected) base.background(Brush.linearGradient(listOf(Violet500, Magenta)))
    else base.border(1.dp, cs.outline.copy(alpha = 0.5f), shape)
    Text(
        label,
        color = if (selected) Color.White else cs.onSurfaceVariant,
        style = MaterialTheme.typography.labelLarge,
        modifier = styled.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SectionHeader(title: String) {
    Row(
        Modifier.padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(20.dp)
                .clip(RoundedCornerShape(50))
                .background(Brush.verticalGradient(listOf(com.nexus.ai.ui.theme.Cyan400, Violet500, Magenta)))
        )
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.padding(start = 10.dp)
        )
    }
}
