package com.nexus.ai.ai

import com.nexus.ai.data.ChatRequest
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.NexusApi
import com.nexus.ai.data.SettingsRepo
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import retrofit2.HttpException

class BackendAiProvider(
    private val api: NexusApi,
    private val settings: SettingsRepo
) : AiProvider {

    override suspend fun reply(history: List<ChatTurn>, options: AiOptions): Result<String> {
        val cfg = settings.config.first()
        if (cfg.url.isBlank() || cfg.token.isBlank()) return Result.failure(AiError.NotConfigured)
        if (!cfg.url.startsWith("https://")) return Result.failure(AiError.InvalidUrl)
        return try {
            val res = api.chat(cfg.url, cfg.token, ChatRequest(history, options.system))
            val text = res.reply
            if (text.isNullOrBlank()) Result.failure(AiError.Server(res.error ?: "respuesta vacía"))
            else Result.success(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            when (e.code()) {
                401 -> Result.failure(AiError.Unauthorized)
                404 -> Result.failure(
                    AiError.Server("backend no encontrado (404). Deja vacío el token para usar el modo directo.")
                )
                else -> Result.failure(AiError.Server("HTTP ${e.code()}"))
            }
        } catch (e: IOException) {
            Result.failure(AiError.Network)
        } catch (e: Exception) {
            Result.failure(AiError.Server("respuesta no válida"))
        }
    }
}
