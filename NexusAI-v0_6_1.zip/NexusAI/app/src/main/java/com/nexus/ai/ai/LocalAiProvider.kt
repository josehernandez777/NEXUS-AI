package com.nexus.ai.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.SettingsRepo
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * IA 100 % en el teléfono (MediaPipe LLM Inference + modelo Gemma .task que eliges tú).
 * Nada sale del dispositivo. Sin herramientas: es conversación privada con memoria.
 */
class LocalAiProvider(
    private val ctx: Context,
    private val settings: SettingsRepo
) : AiProvider {

    private val lock = Mutex()
    private var llm: LlmInference? = null
    private var loadedPath: String? = null

    companion object {
        fun modelDir(ctx: Context): File = File(ctx.filesDir, "models").apply { mkdirs() }
        private const val MAX_PROMPT_CHARS = 3600
    }

    suspend fun isAvailable(): Boolean {
        val path = settings.prefs.first().localModel
        return path.isNotBlank() && File(path).let { it.exists() && it.length() > 1_000_000 }
    }

    override suspend fun reply(history: List<ChatTurn>, options: AiOptions): Result<String> {
        val path = settings.prefs.first().localModel
        if (path.isBlank() || !File(path).exists()) return Result.failure(AiError.LocalNotReady)
        if (history.lastOrNull()?.media != null) return Result.failure(AiError.LocalNoMedia)
        return try {
            withContext(Dispatchers.Default) {
                lock.withLock {
                    val engine = load(path)
                    val text = engine.generateResponse(buildPrompt(history, options.localSystem)).trim()
                    if (text.isBlank()) Result.failure(AiError.Server("el modelo local no devolvió texto"))
                    else Result.success(text.removeSuffix("<end_of_turn>").trim())
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            llm = null
            loadedPath = null
            Result.failure(AiError.Server("memoria insuficiente para el modelo local; prueba uno más pequeño"))
        } catch (e: Exception) {
            Result.failure(AiError.Server("modelo local: " + (e.message ?: "falló").take(120)))
        }
    }

    private fun load(path: String): LlmInference {
        val cur = llm
        if (cur != null && loadedPath == path) return cur
        llm?.close()
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(1536)
            .build()
        return LlmInference.createFromOptions(ctx.applicationContext, options).also {
            llm = it
            loadedPath = path
        }
    }

    /** Plantilla de turnos de Gemma. Se recorta desde el turno más viejo para caber en el contexto. */
    private fun buildPrompt(history: List<ChatTurn>, system: String): String {
        val turns = history.filter { it.content.isNotBlank() }.toMutableList()
        fun render(list: List<ChatTurn>): String {
            val sb = StringBuilder()
            list.forEachIndexed { i, t ->
                val role = if (t.role == "assistant") "model" else "user"
                sb.append("<start_of_turn>").append(role).append('\n')
                if (i == 0 && role == "user" && system.isNotBlank()) sb.append(system).append("\n\n")
                sb.append(t.content.take(1200)).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
            return sb.toString()
        }
        while (turns.size > 1 && render(turns).length > MAX_PROMPT_CHARS) turns.removeAt(0)
        while (turns.isNotEmpty() && turns.first().role == "assistant") turns.removeAt(0)
        return render(turns)
    }
}
