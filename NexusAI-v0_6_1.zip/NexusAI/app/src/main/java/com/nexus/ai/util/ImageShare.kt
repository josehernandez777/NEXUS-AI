package com.nexus.ai.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import java.io.File

private fun mimeOf(file: File) = if (file.extension.lowercase() == "png") "image/png" else "image/jpeg"

/** Guarda la imagen en Imágenes/NEXUS (no necesita permisos en Android 10+). */
fun saveToGallery(ctx: Context, file: File): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Images.Media.MIME_TYPE, mimeOf(file))
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NEXUS")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    ctx.contentResolver.openOutputStream(uri)?.use { out ->
        file.inputStream().use { it.copyTo(out) }
    }
    return uri
}

fun shareImage(ctx: Context, file: File) {
    val uri = saveToGallery(ctx, file) ?: return
    val send = Intent(Intent.ACTION_SEND).apply {
        type = mimeOf(file)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, "Compartir imagen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
