package com.nexus.ai.ui.theme

import androidx.compose.ui.graphics.Color

val Violet500 = Color(0xFF8B5CF6)
val Violet300 = Color(0xFFC4B5FD)
val Purple700 = Color(0xFF6D28D9)
val Magenta = Color(0xFFD946EF)
val AmoledBlack = Color(0xFF000000)
val SurfaceDark = Color(0xFF0E0A18)
val SurfaceDark2 = Color(0xFF1A1229)
val LightBg = Color(0xFFF8F5FF)
val Cyan400 = Color(0xFF22D3EE)
