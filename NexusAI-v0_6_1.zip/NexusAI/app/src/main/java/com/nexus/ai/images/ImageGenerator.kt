package com.nexus.ai.images

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.nexus.ai.data.GContent
import com.nexus.ai.data.GGenConfig
import com.nexus.ai.data.GPart
import com.nexus.ai.data.GRequest
import com.nexus.ai.data.GeminiApi
import com.nexus.ai.data.Net
import com.nexus.ai.data.SettingsRepo
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.Request
import retrofit2.HttpException

/**
 * Genera imágenes: primero con Gemini (tu clave) y, si no está disponible,
 * con Pollinations (sin clave; la descripción se envía a ese servicio).
 */
class ImageGenerator(
    private val ctx: Context,
    private val api: GeminiApi,
    private val settings: SettingsRepo
) {
    suspend fun generate(prompt: String): Result<File> = withContext(Dispatchers.IO) {
        val p = prompt.trim().take(500)
        if (p.isEmpty()) return@withContext Result.failure(Exception("falta la descripción de la imagen"))
        var geminiError: String? = null
        val key = settings.config.first().geminiKey.trim()
        if (key.isNotEmpty()) {
            val r = viaGemini(key, p)
            if (r.isSuccess) return@withContext r
            geminiError = r.exceptionOrNull()?.message
        }
        val f = viaPollinations(p)
        if (f.isSuccess) {
            f
        } else {
            Result.failure(Exception(listOfNotNull(geminiError, f.exceptionOrNull()?.message).joinToString(" | ")))
        }
    }

    private suspend fun viaGemini(key: String, prompt: String): Result<File> {
        return try {
            val res = api.generate(
                "gemini-2.5-flash-image",
                key,
                GRequest(
                    contents = listOf(GContent("user", listOf(GPart(prompt)))),
                    generationConfig = GGenConfig(responseModalities = listOf("TEXT", "IMAGE"))
                )
            )
            val inline = res.candidates?.firstOrNull()?.content?.parts
                ?.firstOrNull { it.inlineData?.data != null }?.inlineData
                ?: return Result.failure(Exception("Gemini no devolvió imagen"))
            val bytes = Base64.decode(inline.data, Base64.DEFAULT)
            val ext = if (inline.mimeType?.contains("jpeg") == true) "jpg" else "png"
            saveValid(bytes, ext)
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            Result.failure(Exception("Gemini imágenes: HTTP ${e.code()}"))
        } catch (e: Exception) {
            Result.failure(Exception("Gemini imágenes: ${e.message}"))
        }
    }

    private fun viaPollinations(prompt: String): Result<File> {
        return try {
            val url = "https://image.pollinations.ai/prompt/" + Uri.encode(prompt) +
                "?width=1024&height=1024&nologo=true"
            Net.client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                val type = resp.header("Content-Type").orEmpty()
                val bytes = resp.body?.bytes()
                if (!resp.isSuccessful || !type.startsWith("image/") || bytes == null) {
                    Result.failure(Exception("Pollinations: HTTP ${resp.code}"))
                } else {
                    saveValid(bytes, if (type.contains("png")) "png" else "jpg")
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("Pollinations: ${e.message}"))
        }
    }

    private fun saveValid(bytes: ByteArray, ext: String): Result<File> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0) return Result.failure(Exception("la imagen recibida no es válida"))
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        val f = File(dir, "nexus_${System.currentTimeMillis()}.$ext")
        f.writeBytes(bytes)
        return Result.success(f)
    }
}
