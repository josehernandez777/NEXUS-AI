package com.nexus.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.ai.ui.navigation.NexusRoot
import com.nexus.ai.ui.screens.SettingsViewModel
import com.nexus.ai.ui.theme.NexusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings: SettingsViewModel = viewModel()
            val prefs by settings.prefs.collectAsStateWithLifecycle()
            NexusTheme(dynamic = prefs.dynamicColor) { NexusRoot() }
        }
    }
}
