package com.nexus.ai.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Graba unos segundos de audio ambiental (WAV 16 kHz mono) para que la IA lo analice. */
object AudioCapture {
    private const val RATE = 16000

    /** Devuelve el WAV en base64, o un mensaje de error. */
    suspend fun record(ctx: Context, seconds: Int): Result<String> = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return@withContext Result.failure(IllegalStateException("falta el permiso del micrófono"))
        }
        val secs = seconds.coerceIn(2, 20)
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return@withContext Result.failure(IllegalStateException("el micrófono no está disponible"))
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return@withContext Result.failure(IllegalStateException("el micrófono está ocupado"))
        }
        val pcm = ByteArrayOutputStream()
        val buf = ByteArray(min)
        val total = RATE * 2 * secs
        try {
            rec.startRecording()
            while (pcm.size() < total) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) break
                pcm.write(buf, 0, n)
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        val data = pcm.toByteArray()
        if (data.isEmpty()) return@withContext Result.failure(IllegalStateException("no se captó audio"))
        Result.success(Base64.encodeToString(wav(data), Base64.NO_WRAP))
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
            .putInt(RATE).putInt(RATE * 2).putShort(2).putShort(16)
        h.put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }
}
