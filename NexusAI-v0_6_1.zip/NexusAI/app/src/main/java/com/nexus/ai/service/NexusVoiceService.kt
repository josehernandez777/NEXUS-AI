package com.nexus.ai.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import com.nexus.ai.ui.assist.AssistActivity

/**
 * Permite elegir a NEXUS como «Asistente digital» del teléfono
 * (Ajustes > Aplicaciones > Aplicaciones predeterminadas > Asistente).
 * Así el gesto o botón del sistema (mantener Inicio, botón lateral, etc.) abre el panel de NEXUS.
 */
class NexusVoiceInteractionService : VoiceInteractionService()

class NexusVoiceSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = NexusVoiceSession(this)
}

class NexusVoiceSession(context: Context) : VoiceInteractionSession(context) {
    override fun onCreate() {
        super.onCreate()
        setUiEnabled(false)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, AssistActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        runCatching { context.startActivity(i) }
        hide()
    }
}

/** Requerido por la declaración del servicio de asistente; NEXUS usa el reconocedor del sistema. */
class NexusRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
