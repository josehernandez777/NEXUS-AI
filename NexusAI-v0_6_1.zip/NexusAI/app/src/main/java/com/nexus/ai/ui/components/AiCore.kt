package com.nexus.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Purple700
import com.nexus.ai.ui.theme.Violet300
import com.nexus.ai.ui.theme.Violet500

enum class CoreState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * Núcleo animado de la IA: orbe con ondas, anillos giratorios y reacción a tu voz.
 * [level] (0..1) es el volumen del micrófono mientras escuchas.
 */
@Composable
fun AiCore(state: CoreState, modifier: Modifier = Modifier.size(220.dp), level: Float = 0f) {
    val spin = when (state) {
        CoreState.IDLE -> 9000
        CoreState.LISTENING -> 4200
        CoreState.THINKING -> 1300
        CoreState.SPEAKING -> 2600
    }
    val pulseMs = when (state) {
        CoreState.IDLE -> 3000
        CoreState.LISTENING -> 1400
        CoreState.THINKING -> 800
        CoreState.SPEAKING -> 560
    }
    val energy by animateFloatAsState(
        when (state) {
            CoreState.IDLE -> 0f
            CoreState.LISTENING -> 0.55f
            CoreState.SPEAKING -> 0.8f
            CoreState.THINKING -> 1f
        },
        tween(700), label = "energy"
    )
    val voice by animateFloatAsState(
        if (state == CoreState.LISTENING) level.coerceIn(0f, 1f) else 0f,
        spring(dampingRatio = 0.55f, stiffness = 300f), label = "voice"
    )
    val t = rememberInfiniteTransition(label = "core")
    val rotation by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(spin, easing = LinearEasing)), label = "rot"
    )
    val counter by t.animateFloat(
        360f, 0f, infiniteRepeatable(tween((spin * 1.6f).toInt(), easing = LinearEasing)), label = "rot2"
    )
    val pulse by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(pulseMs), RepeatMode.Reverse), label = "pulse"
    )
    val wave by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(pulseMs * 3, easing = LinearEasing)), label = "wave"
    )

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val amp = 0.05f + 0.10f * energy + 0.18f * voice
        val k = 1f - amp / 2f + pulse * amp

        // Halo exterior.
        drawCircle(
            Brush.radialGradient(
                listOf(Violet500.copy(alpha = 0.32f + 0.25f * energy + 0.2f * voice), Color.Transparent), c, r
            ),
            radius = r * (k + 0.05f * voice), center = c
        )

        // Ondas que se expanden (más visibles con energía).
        for (i in 0 until 3) {
            val q = (wave + i / 3f) % 1f
            val a = (1f - q) * (0.10f + 0.28f * energy + 0.3f * voice)
            drawCircle(
                Brush.sweepGradient(listOf(Cyan400, Violet500, Magenta, Cyan400), c).let { it },
                radius = r * (0.52f + 0.46f * q), center = c, alpha = a,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Esfera central con brillo.
        val coreR = r * 0.46f
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.95f), Violet300, Violet500, Purple700),
                Offset(c.x - coreR * 0.25f, c.y - coreR * 0.3f), coreR * 1.25f
            ),
            radius = coreR * k, center = c
        )
        drawCircle(
            Brush.radialGradient(
                listOf(Color.Transparent, Cyan400.copy(alpha = 0.35f)), c, coreR * k
            ),
            radius = coreR * k, center = c
        )

        // Anillos orbitales.
        val sweepLen = 70f + 70f * energy
        val ring = r * 0.78f
        val tl = Offset(c.x - ring, c.y - ring)
        val sz = Size(ring * 2, ring * 2)
        rotate(rotation, pivot = c) {
            val st = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Magenta, 0f, sweepLen, false, tl, sz, style = st)
            drawArc(Violet300, 180f, sweepLen, false, tl, sz, style = st)
        }
        val ring2 = r * 0.9f
        rotate(counter, pivot = c) {
            val st = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            drawArc(
                Cyan400.copy(alpha = 0.85f), 90f, 40f + 50f * energy, false,
                Offset(c.x - ring2, c.y - ring2), Size(ring2 * 2, ring2 * 2), style = st
            )
            drawArc(
                Cyan400.copy(alpha = 0.5f), 270f, 24f + 30f * energy, false,
                Offset(c.x - ring2, c.y - ring2), Size(ring2 * 2, ring2 * 2), style = st
            )
        }
    }
}
