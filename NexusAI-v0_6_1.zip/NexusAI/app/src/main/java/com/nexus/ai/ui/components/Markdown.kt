package com.nexus.ai.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

sealed interface Block
data class TextBlock(val md: String) : Block
data class CodeBlock(val lang: String, val code: String) : Block

/** Separa el texto en párrafos Markdown y bloques de código (```lenguaje ... ```). */
fun parseBlocks(src: String): List<Block> {
    val out = mutableListOf<Block>()
    val text = StringBuilder()
    val code = StringBuilder()
    var inCode = false
    var lang = ""
    for (line in src.split("\n")) {
        if (line.trimStart().startsWith("```")) {
            if (!inCode) {
                if (text.isNotBlank()) out.add(TextBlock(text.toString()))
                text.clear()
                lang = line.trim().removePrefix("```").trim()
                inCode = true
            } else {
                out.add(CodeBlock(lang, code.toString().trimEnd('\n')))
                code.clear()
                inCode = false
            }
        } else if (inCode) {
            code.append(line).append('\n')
        } else {
            text.append(line).append('\n')
        }
    }
    if (inCode) out.add(CodeBlock(lang, code.toString().trimEnd('\n')))
    else if (text.isNotBlank()) out.add(TextBlock(text.toString()))
    return out
}

/** Markdown básico: **negrita**, `código`, listas con * o -, y títulos con #. */
fun renderMarkdown(src: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    val lines = src.split("\n")
    lines.forEachIndexed { i, raw ->
        val t = raw.trimStart()
        when {
            t.startsWith("### ") || t.startsWith("## ") || t.startsWith("# ") -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    appendInline(t.trimStart('#').trim(), codeBg)
                }
            }
            t.startsWith("* ") || t.startsWith("- ") -> {
                append("•  ")
                appendInline(t.drop(2), codeBg)
            }
            else -> appendInline(raw, codeBg)
        }
        if (i < lines.lastIndex) append("\n")
    }
}

private fun AnnotatedString.Builder.appendInline(text: String, codeBg: Color) {
    var i = 0
    while (i < text.length) {
        if (text.startsWith("**", i)) {
            val end = text.indexOf("**", i + 2)
            if (end > 0) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(text.substring(i + 2, end)) }
                i = end + 2
            } else {
                append("**")
                i += 2
            }
        } else if (text[i] == '`') {
            val end = text.indexOf('`', i + 1)
            if (end > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(text.substring(i + 1, end))
                }
                i = end + 1
            } else {
                append('`')
                i++
            }
        } else {
            append(text[i])
            i++
        }
    }
}
