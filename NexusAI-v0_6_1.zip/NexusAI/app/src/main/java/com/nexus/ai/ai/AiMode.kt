package com.nexus.ai.ai

private val FLASH_FIRST = listOf(
    "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite",
    "gemini-2.5-flash", "gemini-2.5-flash-lite"
)
private val LITE_FIRST = listOf(
    "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite",
    "gemini-3.5-flash", "gemini-2.5-flash"
)

/** Modos de pensar: cambian el estilo de razonamiento, el orden de modelos y la longitud. */
enum class AiMode(
    val label: String,
    val models: List<String>,
    val maxTokens: Int,
    val temperature: Float,
    val prompt: String
) {
    RAPIDO(
        "Rápido", LITE_FIRST, 4096, 0.8f,
        "ESTILO: responde en 1 a 3 frases, directo al punto."
    ),
    EQUILIBRADO(
        "Equilibrado", FLASH_FIRST, 8192, 0.8f,
        "ESTILO: respuestas claras y útiles, con la extensión justa. Usa Markdown ligero (listas, **negritas**) cuando ayude."
    ),
    PROFUNDO(
        "Profundo", FLASH_FIRST, 8192, 0.6f,
        "ESTILO: modo profundo. Antes de responder, razona con calma: descompón el problema, considera alternativas, " +
            "verifica cada paso y señala tus supuestos. Después da una respuesta final completa, bien estructurada y fácil de seguir."
    ),
    CODIGO(
        "Código", FLASH_FIRST, 8192, 0.4f,
        "ESTILO: modo programador. Eres un ingeniero de software senior. Entrega código completo, correcto y listo para ejecutar, " +
            "en bloques con la etiqueta del lenguaje (```kotlin, ```python, etc.). Incluye manejo de errores, buenas prácticas y pruebas cuando aporten. " +
            "Si la tarea es grande, primero un plan breve de arquitectura; luego el código; al final cómo ejecutarlo y cómo extenderlo. " +
            "Si falta contexto, asume lo razonable y dilo."
    );

    companion object {
        fun from(name: String): AiMode = entries.firstOrNull { it.name == name } ?: EQUILIBRADO
    }
}
