package com.nexus.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet500
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private fun trimPath(path: Path, fraction: Float): Path {
    val pm = PathMeasure()
    pm.setPath(path, false)
    val out = Path()
    pm.getSegment(0f, pm.length * fraction.coerceIn(0f, 1f), out, true)
    return out
}

/**
 * Logo de NEXUS: hexágono de red + «N» hecha de trazos con nodos en las esquinas.
 * [progress] (0..1) dibuja el logo trazo a trazo (para la animación de entrada).
 * Con [animated] un satélite orbita el hexágono y el brillo respira.
 */
@Composable
fun NexusLogo(
    modifier: Modifier = Modifier.size(120.dp),
    animated: Boolean = true,
    progress: Float = 1f
) {
    val t = rememberInfiniteTransition(label = "logo")
    val glowAnim by t.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val orbitAnim by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "orbit"
    )

    Canvas(modifier) {
        val glow = if (animated) glowAnim else 0.85f
        val w = size.minDimension
        val c = center
        val brush = Brush.linearGradient(
            listOf(Cyan400, Violet500, Magenta),
            Offset(c.x - w / 2, c.y - w / 2),
            Offset(c.x + w / 2, c.y + w / 2)
        )
        val sw = w * 0.034f
        val r = w * 0.42f

        // Halo suave detrás del logo.
        drawCircle(
            Brush.radialGradient(
                listOf(Violet500.copy(alpha = 0.30f * glow * progress), Color.Transparent),
                c, w * 0.62f
            ),
            radius = w * 0.62f, center = c
        )

        // Hexágono (punta arriba).
        val hex = Path().apply {
            for (k in 0 until 6) {
                val a = (-90.0 + 60.0 * k) * PI / 180.0
                val x = c.x + r * cos(a).toFloat()
                val y = c.y + r * sin(a).toFloat()
                if (k == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        val hexFrac = (progress / 0.6f).coerceIn(0f, 1f)
        val hexDraw = if (hexFrac >= 1f) hex else trimPath(hex, hexFrac)
        val joinStyle = StrokeJoin.Round
        drawPath(hexDraw, brush, alpha = 0.22f * glow, style = Stroke(sw * 3.6f, cap = StrokeCap.Round, join = joinStyle))
        drawPath(hexDraw, brush, style = Stroke(sw, cap = StrokeCap.Round, join = joinStyle))

        // «N».
        val nx = r * 0.46f
        val ny = r * 0.52f
        val nPath = Path().apply {
            moveTo(c.x - nx, c.y + ny)
            lineTo(c.x - nx, c.y - ny)
            lineTo(c.x + nx, c.y + ny)
            lineTo(c.x + nx, c.y - ny)
        }
        val nFrac = ((progress - 0.35f) / 0.5f).coerceIn(0f, 1f)
        if (nFrac > 0f) {
            val nDraw = if (nFrac >= 1f) nPath else trimPath(nPath, nFrac)
            drawPath(nDraw, brush, alpha = 0.25f * glow, style = Stroke(sw * 3.8f, cap = StrokeCap.Round, join = joinStyle))
            drawPath(nDraw, brush, style = Stroke(sw * 1.7f, cap = StrokeCap.Round, join = joinStyle))
        }

        // Nodos en los vértices de la N.
        val nodeK = ((progress - 0.8f) / 0.2f).coerceIn(0f, 1f)
        if (nodeK > 0f) {
            val pts = listOf(
                Offset(c.x - nx, c.y - ny), Offset(c.x + nx, c.y - ny),
                Offset(c.x - nx, c.y + ny), Offset(c.x + nx, c.y + ny)
            )
            for (p in pts) {
                drawCircle(Color.White.copy(alpha = 0.25f * nodeK), radius = sw * 1.9f * nodeK, center = p)
                drawCircle(Color.White, radius = sw * 0.95f * nodeK, center = p)
            }
        }

        // Nodos del hexágono y satélite orbitando.
        if (progress >= 1f) {
            val pm = PathMeasure()
            pm.setPath(hex, false)
            val len = pm.length
            for (k in 0 until 6) {
                val a = (-90.0 + 60.0 * k) * PI / 180.0
                drawCircle(
                    Color.White.copy(alpha = 0.9f), radius = sw * 0.55f,
                    center = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                )
            }
            if (animated) {
                val pos = pm.getPosition(len * orbitAnim)
                drawCircle(Cyan400.copy(alpha = 0.35f), radius = sw * 2.6f, center = pos)
                drawCircle(Color.White, radius = sw * 1.05f, center = pos)
            }
        }
    }
}
