package com.nexus.ai.data

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

data class GInlineData(val mimeType: String? = null, val data: String? = null)
data class GPart(val text: String? = null, val inlineData: GInlineData? = null)
data class GContent(val role: String? = null, val parts: List<GPart>? = null)
data class GGenConfig(
    val maxOutputTokens: Int? = null,
    val temperature: Float? = null,
    val responseModalities: List<String>? = null
)
data class GRequest(
    val systemInstruction: GContent? = null,
    val contents: List<GContent>,
    val generationConfig: GGenConfig? = null
)
data class GCandidate(val content: GContent? = null)
data class GResponse(val candidates: List<GCandidate>? = null)

interface GeminiApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generate(
        @Path("model") model: String,
        @Header("x-goog-api-key") key: String,
        @Body body: GRequest
    ): GResponse
}
