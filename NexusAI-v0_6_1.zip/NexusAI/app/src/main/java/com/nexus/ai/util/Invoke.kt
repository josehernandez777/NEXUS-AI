package com.nexus.ai.util

import android.content.Context
import android.content.Intent
import android.os.VibrationEffect
import android.os.Vibrator
import com.nexus.ai.ui.assist.AssistActivity

/** Abre el panel flotante de NEXUS sobre cualquier app. */
fun launchAssistant(ctx: Context, vibrate: Boolean = false) {
    if (vibrate) {
        runCatching {
            val v = ctx.getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
    val i = Intent(ctx, AssistActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
    ctx.startActivity(i)
}
