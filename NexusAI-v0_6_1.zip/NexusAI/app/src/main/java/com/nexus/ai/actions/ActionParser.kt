package com.nexus.ai.actions

import com.google.gson.JsonObject
import com.google.gson.JsonParser

data class ParsedAction(val tool: String, val args: JsonObject)
data class Parsed(val text: String, val actions: List<ParsedAction>)

private val ALIASES = mapOf(
    "query" to listOf("q", "search", "search_query", "searchQuery", "term", "keywords", "consulta", "busqueda", "búsqueda", "text", "title", "song", "video", "name"),
    "app" to listOf("name", "app_name", "appName", "nombre", "package", "application"),
    "place" to listOf("destination", "location", "address", "destino", "lugar", "query"),
    "number" to listOf("phone", "phone_number", "phoneNumber", "telefono", "teléfono", "numero", "número", "tel"),
    "text" to listOf("message", "msg", "content", "texto", "body", "mensaje"),
    "url" to listOf("link", "uri", "address", "enlace"),
    "page" to listOf("section", "setting", "screen"),
    "percent" to listOf("level", "value", "porcentaje", "volume", "brightness"),
    "action" to listOf("type", "name", "accion", "acción"),
    "prompt" to listOf("description", "descripcion", "descripción", "query", "text", "image", "idea"),
    "seconds" to listOf("duration", "segundos", "time"),
    "hour" to listOf("hora", "hours"),
    "fact" to listOf("memory", "recuerdo", "dato", "text", "info", "note"),
    "minute" to listOf("minuto", "minutes", "min")
)

// Claves de texto principal: si solo llega un valor, se usa para cualquiera de ellas.
private val MAIN_KEYS = setOf("query", "app", "place", "url", "text", "page", "action", "prompt", "fact")

private fun JsonObject.direct(key: String): String? {
    val e = get(key) ?: return null
    return if (e.isJsonPrimitive) e.asString else null
}

fun JsonObject.str(key: String): String? {
    direct(key)?.let { return it }
    ALIASES[key]?.forEach { alt -> direct(alt)?.let { return it } }
    if (key in MAIN_KEYS) {
        val prims = entrySet().filter { it.value.isJsonPrimitive }
        if (prims.size == 1) return prims[0].value.asString
    }
    return null
}

fun JsonObject.num(key: String): Double? = str(key)?.toDoubleOrNull()

fun JsonObject.bool(key: String): Boolean? = str(key)?.lowercase()?.let { it == "true" }

object ActionParser {
    private val re = Regex("""\[\[ACTION\s*(\{.*?\})\s*\]\]""", RegexOption.DOT_MATCHES_ALL)

    fun parse(raw: String): Parsed {
        val actions = mutableListOf<ParsedAction>()
        for (m in re.findAll(raw)) {
            try {
                val o = JsonParser.parseString(m.groupValues[1]).asJsonObject
                val tool = o.get("tool")?.asString
                if (tool != null) {
                    val argsEl = o.get("args")
                    val args = when {
                        argsEl != null && argsEl.isJsonObject -> argsEl.asJsonObject
                        argsEl != null && argsEl.isJsonPrimitive ->
                            JsonObject().apply { addProperty("_value", argsEl.asString) }
                        else -> JsonObject().also { j ->
                            o.entrySet().forEach { (k, v) -> if (k != "tool") j.add(k, v) }
                        }
                    }
                    actions.add(ParsedAction(tool, args))
                }
            } catch (e: Exception) {
                // acción mal formada: se ignora
            }
        }
        return Parsed(re.replace(raw, "").trim(), actions)
    }
}
