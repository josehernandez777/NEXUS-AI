package com.nexus.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.data.db.ConversationEntity
import com.nexus.ai.ui.chat.ChatViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(vm: ChatViewModel, onOpened: () -> Unit) {
    val convs by vm.conversations.collectAsStateWithLifecycle()
    val currentId by vm.currentConversationId.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Historial",
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(com.nexus.ai.ui.theme.Cyan400, com.nexus.ai.ui.theme.Violet300, com.nexus.ai.ui.theme.Magenta)
                    )
                ),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { vm.newChat(); onOpened() }) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("  Nuevo")
            }
        }

        if (convs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Aún no hay conversaciones",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(convs, key = { it.id }) { c ->
                    ConversationRow(
                        c = c,
                        selected = c.id == currentId,
                        onClick = { vm.open(c.id); onOpened() },
                        onDelete = { vm.delete(c.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationRow(
    c: ConversationEntity,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val fmt = SimpleDateFormat("d MMM · HH:mm", Locale("es"))
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) cs.primary.copy(alpha = 0.22f) else cs.surfaceContainerHigh.copy(alpha = 0.9f))
            .border(
                1.dp,
                if (selected) androidx.compose.ui.graphics.Brush.linearGradient(listOf(com.nexus.ai.ui.theme.Cyan400.copy(alpha = 0.6f), com.nexus.ai.ui.theme.Magenta.copy(alpha = 0.6f)))
                else androidx.compose.ui.graphics.Brush.linearGradient(listOf(cs.outlineVariant, cs.outlineVariant)),
                RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                c.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                fmt.format(Date(c.updatedAt)),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = "Borrar", tint = cs.onSurfaceVariant)
        }
    }
}
