package com.nexus.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.ai.ui.theme.Violet300
import kotlinx.coroutines.delay

private val KEYWORDS = Regex(
    """\b(fun|val|var|class|object|interface|def|import|from|return|if|else|elif|for|while|when|function|const|let|public|private|protected|static|void|int|float|double|bool|boolean|string|true|false|null|None|True|False|async|await|try|catch|except|finally|throw|new|package|in|is|as|self|this|lambda|with|yield|switch|case|break|continue|struct|enum|type|override|suspend|data|sealed|extends|implements)\b"""
)
private val NUMBERS = Regex("""\b\d+(\.\d+)?\b""")
private val STRINGS = Regex("""\"(\\.|[^\"\\])*\"|'(\\.|[^'\\])*'""")
private val COMMENTS = Regex("""(//|#).*""")

private fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    fun paint(r: Regex, c: Color) {
        r.findAll(code).forEach { addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
    }
    paint(KEYWORDS, Color(0xFFC4A1FF))
    paint(NUMBERS, Color(0xFFFFB86C))
    paint(STRINGS, Color(0xFF8AE9A0))
    paint(COMMENTS, Color(0xFF7C7A91))
}

@Composable
fun CodeBlockView(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    val styled = remember(code) { highlight(code) }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0B0714))
    ) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF1A1229)).padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                lang.ifBlank { "código" },
                style = MaterialTheme.typography.labelMedium,
                color = Violet300,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)); copied = true }) {
                Icon(
                    if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = Violet300
                )
                Text(if (copied) "  Copiado" else "  Copiar", color = Violet300, fontSize = 12.sp)
            }
        }
        Text(
            styled,
            color = Color(0xFFE9E3FF),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)
        )
    }
}
