package com.nexus.ai.memory

import com.nexus.ai.data.db.MemoryDao
import com.nexus.ai.data.db.MemoryEntity
import java.text.Normalizer

/** Memoria a largo plazo. Guarda hechos breves en Room (solo en el teléfono). */
class MemoryStore(private val dao: MemoryDao) {

    sealed class Saved {
        object New : Saved()
        object Duplicate : Saved()
        class Rejected(val reason: String) : Saved()
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    private val secret = Regex(
        "(contrase[nñ]a|password|passwd|\\bpin\\b|\\bcvv\\b|token|api ?key|clave secreta)|(\\d[ -]?){13,}",
        RegexOption.IGNORE_CASE
    )

    suspend fun remember(raw: String, category: String = "general"): Saved {
        val text = raw.trim().replace(Regex("\\s+"), " ").take(220)
        if (text.length < 4) return Saved.Rejected("demasiado corto")
        if (secret.containsMatchIn(text)) {
            return Saved.Rejected("parece un dato sensible (contraseña, clave o tarjeta); no lo guardo")
        }
        val n = norm(text)
        val now = System.currentTimeMillis()
        val existing = dao.allOnce()
        existing.firstOrNull {
            val e = norm(it.text)
            e == n || (n.length > 12 && e.contains(n)) || (e.length > 12 && n.contains(e))
        }?.let {
            dao.touch(it.id, now)
            return Saved.Duplicate
        }
        dao.insert(MemoryEntity(text = text, category = category.trim().take(20).ifBlank { "general" }, createdAt = now, updatedAt = now))
        // Tope de 200 recuerdos: se descartan los menos recientes.
        existing.drop(199).forEach { dao.delete(it.id) }
        return Saved.New
    }

    /** Borra los recuerdos que contengan [query]. Devuelve cuántos se borraron. */
    suspend fun forget(query: String): Int {
        val q = norm(query)
        if (q.length < 3) return 0
        val hits = dao.allOnce().filter { norm(it.text).contains(q) }
        hits.forEach { dao.delete(it.id) }
        return hits.size
    }

    /** Texto que se inyecta en el prompt: los recuerdos más recientes dentro de [maxChars]. */
    suspend fun promptBlock(maxChars: Int = 1800): String {
        val sb = StringBuilder()
        for (m in dao.allOnce()) {
            val line = "- ${m.text}\n"
            if (sb.length + line.length > maxChars) break
            sb.append(line)
        }
        return sb.toString().trim()
    }
}
