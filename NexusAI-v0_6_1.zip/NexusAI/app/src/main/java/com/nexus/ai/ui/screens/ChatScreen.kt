package com.nexus.ai.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Violet300
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.ai.AiMode
import com.nexus.ai.ui.chat.ACTION_PREFIX
import com.nexus.ai.ui.chat.ATTACH_PREFIX
import com.nexus.ai.ui.chat.ChatMessage
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.chat.IMAGE_PREFIX
import com.nexus.ai.ui.components.CodeBlock
import com.nexus.ai.ui.components.CodeBlockView
import com.nexus.ai.ui.components.NexusLogo
import com.nexus.ai.ui.components.TextBlock
import com.nexus.ai.ui.components.TypingDots
import com.nexus.ai.ui.components.parseBlocks
import com.nexus.ai.ui.components.rememberMicGate
import com.nexus.ai.ui.components.renderMarkdown
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Purple700
import com.nexus.ai.ui.theme.Violet500
import com.nexus.ai.util.saveToGallery
import com.nexus.ai.util.shareImage
import com.nexus.ai.voice.VoiceEngine
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenVoice: () -> Unit = {}) {
    val state by vm.state.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val voiceState by vm.voiceState.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val voiceError by vm.voiceError.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    var input by remember { mutableStateOf("") }
    var attach by remember { mutableStateOf<Uri?>(null) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attach = uri
    }
    val listState = rememberLazyListState()
    val total = state.messages.size + (if (state.thinking) 1 else 0) + (if (state.error != null) 1 else 0)
    val listening = voiceState == VoiceEngine.State.LISTENING

    val micGate = rememberMicGate {
        vm.dictate { text -> input = (input + " " + text).trim() }
    }

    LaunchedEffect(total) {
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexusLogo(Modifier.size(40.dp), animated = true)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(
                    "NEXUS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        brush = Brush.linearGradient(listOf(Cyan400, Violet300, Magenta)),
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 5.sp
                    )
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(active = state.thinking)
                    Text(
                        if (state.thinking) "  pensando…" else "  listo · " + mode.label.lowercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            IconButton(onClick = { vm.newChat() }) {
                Icon(Icons.Filled.Add, contentDescription = "Nuevo chat")
            }
        }
        ModeRow(mode) { vm.setMode(it) }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(state.messages, key = { _, m -> m.id }) { index, m ->
                    MessageRow(
                        m,
                        animate = index == state.messages.lastIndex,
                        typewriter = m.id == state.liveId,
                        onSpeak = { vm.speak(it) }
                    )
                }
                if (state.thinking) {
                    item(key = "typing") { TypingBubble(state.status) }
                }
                state.error?.let { err ->
                    item(key = "error") { ErrorBubble(err, onRetry = { vm.retry() }) }
                }
            }
            if (state.messages.isEmpty() && !state.thinking && state.error == null) {
                EmptyState(onPick = { vm.send(it) })
            }
        }

        voiceError?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }

        AnimatedVisibility(visible = attach != null, enter = fadeIn(tween(200)), exit = fadeOut(tween(150))) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📎 Imagen lista para enviar", color = MaterialTheme.colorScheme.tertiary)
                    IconButton(onClick = { attach = null }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Quitar imagen", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        val cs = MaterialTheme.colorScheme
        val canSend = input.isNotBlank() || attach != null
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val barBorder = if (listening)
                Brush.linearGradient(listOf(Cyan400, Violet500, Magenta))
            else Brush.linearGradient(listOf(cs.outline.copy(alpha = 0.55f), cs.outlineVariant))
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = cs.surfaceContainer.copy(alpha = 0.94f),
                border = BorderStroke(if (listening) 1.5.dp else 1.dp, barBorder),
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { pickImage.launch("image/*") }) {
                        Icon(
                            Icons.Filled.Image,
                            contentDescription = "Adjuntar imagen",
                            tint = cs.onSurfaceVariant
                        )
                    }
                    TextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = {
                            Text(
                                if (listening) (if (partial.isBlank()) "Te escucho…" else partial)
                                else if (attach != null) "Pregunta sobre la imagen…" else "Escribe a NEXUS…",
                                maxLines = 1
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent
                        ),
                        maxLines = 5
                    )
                    MicButton(listening = listening) { if (listening) vm.finishListening() else micGate() }
                }
            }
            val mode3 = when {
                state.thinking -> 0
                canSend -> 1
                else -> 2
            }
            Crossfade(targetState = mode3, animationSpec = tween(220), label = "sendstop") { m3 ->
                RoundGradientButton(
                    onClick = {
                        when (m3) {
                            0 -> vm.stop()
                            1 -> {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val img = attach
                                if (img != null) vm.sendWithImage(input, img) else vm.send(input)
                                input = ""
                                attach = null
                            }
                            else -> onOpenVoice()
                        }
                    }
                ) {
                    Icon(
                        when (m3) {
                            0 -> Icons.Filled.Stop
                            1 -> Icons.AutoMirrored.Filled.Send
                            else -> Icons.Filled.GraphicEq
                        },
                        contentDescription = when (m3) {
                            0 -> "Detener"
                            1 -> "Enviar"
                            else -> "Conversar por voz"
                        },
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun RoundGradientButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed) 0.9f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press")
    Box(
        Modifier
            .size(52.dp)
            .graphicsLayer { scaleX = k; scaleY = k }
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Cyan400, Violet500, Magenta)))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "mic")
    val pulse by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "micpulse"
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(48.dp)) {
        if (listening) {
            Box(
                Modifier
                    .size((30 + 14 * pulse).dp)
                    .alpha(0.35f * (1f - pulse * 0.5f))
                    .background(Brush.radialGradient(listOf(Magenta, Color.Transparent)), CircleShape)
            )
        }
        IconButton(onClick = onClick) {
            Icon(
                if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
                contentDescription = if (listening) "Terminar de dictar" else "Dictar",
                tint = if (listening) Magenta else cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StatusDot(active: Boolean) {
    val t = rememberInfiniteTransition(label = "dot")
    val a by t.animateFloat(
        0.35f, 1f, infiniteRepeatable(tween(if (active) 450 else 1800), RepeatMode.Reverse), label = "dota"
    )
    Box(
        Modifier
            .size(7.dp)
            .alpha(a)
            .background(if (active) Magenta else Cyan400, CircleShape)
    )
}

@Composable
private fun ModeRow(selected: AiMode, onSelect: (AiMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AiMode.entries.forEach { m ->
            ModePill(m.label, selected = m == selected) { onSelect(m) }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    val a by animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "pill")
    val k by animateFloatAsState(if (selected) 1.04f else 1f, spring(dampingRatio = 0.6f, stiffness = 400f), label = "pillk")
    Text(
        label,
        color = if (selected) Color.White else cs.onSurfaceVariant,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier
            .graphicsLayer { scaleX = k; scaleY = k }
            .clip(shape)
            .background(Brush.linearGradient(listOf(Violet500, Magenta)), shape, alpha = a)
            .border(1.dp, cs.outline.copy(alpha = 0.5f * (1f - a)), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    val draw = remember { androidx.compose.animation.core.Animatable(0f) }
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        appeared = true
        draw.animateTo(1f, tween(1100, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }
    @Composable
    fun Reveal(delayMs: Int, content: @Composable () -> Unit) {
        AnimatedVisibility(
            visible = appeared,
            enter = fadeIn(tween(520, delayMillis = delayMs)) +
                slideInVertically(tween(520, delayMillis = delayMs)) { it / 3 }
        ) { content() }
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NexusLogo(Modifier.size(150.dp), progress = draw.value)
        Spacer(Modifier.height(16.dp))
        Reveal(250) {
            Text(
                "Hola, soy NEXUS",
                style = MaterialTheme.typography.headlineSmall.copy(
                    brush = Brush.linearGradient(listOf(Cyan400, Violet300, Magenta))
                )
            )
        }
        Reveal(380) {
            Text(
                "Pregúntame, créame código, imágenes o pídeme que use tu teléfono.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(20.dp))
        listOf(
            "Crea una imagen de un lobo neón en la ciudad",
            "Abre YouTube y busca música lo-fi",
            "Escríbeme una app de notas en Kotlin"
        ).forEachIndexed { i, it ->
            Reveal(520 + i * 120) {
                Column {
                    SuggestionPill(it) { onPick(it) }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun SuggestionPill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed) 0.96f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "sug")
    Text(
        text,
        color = MaterialTheme.colorScheme.tertiary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .graphicsLayer { scaleX = k; scaleY = k }
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f))
            .border(1.dp, Brush.linearGradient(listOf(Cyan400.copy(alpha = 0.5f), Violet500.copy(alpha = 0.6f), Magenta.copy(alpha = 0.5f))), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp)
    )
}

@Composable
private fun MessageRow(m: ChatMessage, animate: Boolean, typewriter: Boolean, onSpeak: (String) -> Unit) {
    if (animate) {
        val visible = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = visible,
            enter = fadeIn(tween(280)) + slideInVertically(spring(dampingRatio = 0.75f, stiffness = 380f)) { it / 3 }
        ) { MessageContent(m, typewriter, onSpeak) }
    } else {
        MessageContent(m, false, onSpeak)
    }
}

@Composable
private fun MessageContent(m: ChatMessage, typewriter: Boolean, onSpeak: (String) -> Unit) {
    when {
        m.text.startsWith(ACTION_PREFIX) -> ActionChip(m.text)
        m.text.startsWith(IMAGE_PREFIX) -> ImageBubble(m.text)
        m.text.startsWith(ATTACH_PREFIX) -> AttachBubble(m.text)
        m.fromUser -> UserBubble(m.text)
        else -> AssistantBubble(m, typewriter, onSpeak)
    }
}

@Composable
private fun UserBubble(text: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                .background(Brush.linearGradient(listOf(Violet500, Purple700, Magenta.copy(alpha = 0.9f))))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text, color = Color.White)
        }
    }
}

@Composable
private fun AttachBubble(text: String) {
    val body = text.removePrefix(ATTACH_PREFIX)
    val path = body.substringBefore('\n')
    val caption = body.substringAfter('\n', "")
    val bmp by produceState<ImageBitmap?>(initialValue = null, path) {
        value = withContext(Dispatchers.IO) { decodeImage(path) }
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                .background(Brush.linearGradient(listOf(Violet500, Purple700, Magenta.copy(alpha = 0.9f))))
                .padding(6.dp)
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = "Imagen adjunta",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(it.width.toFloat() / it.height.toFloat())
                        .clip(RoundedCornerShape(14.dp))
                )
            }
            if (caption.isNotBlank()) {
                Text(caption, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun ActionChip(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = cs.tertiary.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, cs.tertiary.copy(alpha = 0.25f))
    ) {
        Text(
            text,
            color = cs.tertiary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

private fun decodeImage(path: String): ImageBitmap? {
    val f = File(path)
    if (!f.exists()) return null
    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
    return BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
}

@Composable
private fun ImageBubble(text: String) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val body = text.removePrefix(IMAGE_PREFIX)
    val path = body.substringBefore('\n')
    val caption = body.substringAfter('\n', "")
    val loaded by produceState(initialValue = Pair<ImageBitmap?, Boolean>(null, false), path) {
        val bmp = withContext(Dispatchers.IO) { decodeImage(path) }
        value = Pair(bmp, true)
    }
    val bmp = loaded.first

    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = cs.surfaceVariant.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.25f)),
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column {
            when {
                bmp != null -> Image(
                    bitmap = bmp,
                    contentDescription = caption,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                )
                loaded.second -> Text(
                    "La imagen ya no está disponible.",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
                else -> Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            if (caption.isNotBlank()) {
                Text(
                    caption,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            if (bmp != null) {
                Row {
                    TextButton(onClick = {
                        val uri = saveToGallery(ctx, File(path))
                        Toast.makeText(
                            ctx,
                            if (uri != null) "Guardada en Imágenes/NEXUS" else "No se pudo guardar",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) { Text("Guardar") }
                    TextButton(onClick = { shareImage(ctx, File(path)) }) { Text("Compartir") }
                }
            }
        }
    }
}

@Composable
private fun AssistantBubble(m: ChatMessage, typewriter: Boolean, onSpeak: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var shown by remember(m.id) { mutableIntStateOf(if (typewriter) 0 else m.text.length) }
    LaunchedEffect(m.id, typewriter) {
        if (typewriter) {
            val step = maxOf(5, m.text.length / 150)
            while (shown < m.text.length) {
                shown = minOf(m.text.length, shown + step)
                delay(16)
            }
        } else {
            shown = m.text.length
        }
    }
    val visible = m.text.take(shown)
    val blocks = remember(visible) { parseBlocks(visible) }
    val codeBg = cs.background.copy(alpha = 0.6f)

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NexusLogo(Modifier.padding(top = 4.dp).size(26.dp), animated = false)
        Surface(
            shape = RoundedCornerShape(6.dp, 20.dp, 20.dp, 20.dp),
            color = cs.surfaceContainerHigh.copy(alpha = 0.92f),
            border = BorderStroke(1.dp, Brush.linearGradient(listOf(Cyan400.copy(alpha = 0.35f), cs.outline.copy(alpha = 0.25f), Magenta.copy(alpha = 0.3f)))),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Column(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                blocks.forEach { b ->
                    when (b) {
                        is TextBlock -> {
                            if (b.md.isNotBlank()) {
                                Text(renderMarkdown(b.md.trimEnd(), codeBg), color = cs.onSurface)
                            }
                        }
                        is CodeBlock -> {
                            CodeBlockView(b.lang, b.code)
                        }
                    }
                }
            }
        }
        }
        if (shown >= m.text.length) {
            Row(Modifier.padding(start = 34.dp)) {
                CopyButton(m.text)
                IconButton(onClick = { onSpeak(m.text) }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Leer en voz alta",
                        modifier = Modifier.size(16.dp),
                        tint = cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CopyButton(text: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    IconButton(
        onClick = { clipboard.setText(AnnotatedString(text)); copied = true },
        modifier = Modifier.size(32.dp)
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = "Copiar",
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TypingBubble(status: String?) {
    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TypingDots()
            Crossfade(targetState = status, animationSpec = tween(300), label = "status") { st ->
                if (st != null) {
                    Text(
                        st,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ErrorBubble(message: String, onRetry: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
            TextButton(onClick = onRetry) { Text("Reintentar") }
        }
    }
}
