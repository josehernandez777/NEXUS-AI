const DEFAULT_SYSTEM = "Eres NEXUS, un asistente personal. Responde siempre en español, de forma clara y breve.";
const MODEL = "gemini-2.5-flash";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });

// Cada mensaje puede traer un adjunto (imagen o audio) en base64: { mime, media }.
function toContents(msgs) {
  const out = [];
  for (const m of msgs) {
    const role = m.role === "assistant" ? "model" : "user";
    const text = String(m.content ?? "").slice(0, 4000);
    const parts = [];
    if (m.media && m.mime) parts.push({ inlineData: { mimeType: m.mime, data: m.media } });
    if (text) parts.push({ text });
    if (!parts.length) continue;
    const last = out[out.length - 1];
    if (last && last.role === role) last.parts.push(...parts);
    else out.push({ role, parts });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return new Response("NEXUS backend OK");
    if (request.headers.get("X-App-Token") !== env.APP_TOKEN) {
      return json({ error: "unauthorized" }, 401);
    }
    let body;
    try { body = await request.json(); } catch { return json({ error: "JSON inválido" }); }
    const msgs = Array.isArray(body.messages) ? body.messages.slice(-30) : [];
    const contents = toContents(msgs);
    if (!contents.length) return json({ error: "Mensaje vacío" });

    // La app manda su propio prompt (herramientas, memoria, modo). Se limita el tamaño por seguridad.
    const system = typeof body.system === "string" && body.system.trim()
      ? body.system.slice(0, 24000)
      : DEFAULT_SYSTEM;

    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents }),
      }
    );
    if (r.status === 429) return json({ error: "Límite gratuito alcanzado. Intenta en un minuto." });
    if (!r.ok) return json({ error: `Gemini respondió ${r.status}` });
    const data = await r.json();
    const text = (data.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("");
    return json(text ? { reply: text } : { error: "Gemini no devolvió texto." });
  },
};
