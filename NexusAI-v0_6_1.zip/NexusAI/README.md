# NEXUS AI (Android, Kotlin + Compose)

Asistente personal con IA para Galaxy Note 9 (Android 10, ARM64). Versión actual: **v0.5.0**.

## Estado por etapas
| Etapa | Contenido | Estado |
|---|---|---|
| 1 | Estructura, tema AMOLED/violeta, núcleo animado, navegación, pantallas | Funciona en dispositivo |
| 2 | Chat + IA en la nube (Retrofit + backend propio) | Pendiente |
| 3 | SpeechRecognizer + TextToSpeech (español) | Pendiente |
| 4 | Room + DataStore + motor offline | Pendiente |
| 5 | Intents: abrir apps, volumen, brillo | Pendiente |
| 6 | Pruebas, optimización, APK | Pendiente |

## Requisitos
- Android Studio Koala o superior, JDK 17.
- Dispositivo con Depuración USB activada, o emulador API 29+.

## Abrir y ejecutar
1. Descomprime y abre la carpeta `NexusAI` en Android Studio.
2. Espera a que Gradle sincronice (si falta `gradle-wrapper.jar`, Studio lo resuelve
   con `gradle-wrapper.properties`; si no, ejecuta `gradle wrapper --gradle-version 8.7`).
3. Conecta el Note 9 y pulsa **Run**.
4. APK: `Build > Build APK(s)` (debug) o `Build > Generate Signed Bundle / APK` (release).

## Claves de API
Nunca van en la app. Desde la Etapa 2 la app llamará a tu backend por HTTPS,
y es el backend quien guarda la clave de Claude.

## Pendiente conocido
- Ícono de lanzador provisional (usa el del sistema).
- Los ajustes aún no persisten (DataStore en Etapa 4).

## Compilar el APK sin Android Studio (GitHub Actions)
1. Crea un repositorio en github.com y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** > **Build APK** > **Run workflow**.
3. Al terminar (~5-8 min), abre la ejecución y descarga **nexus-ai-debug-apk** (Artifacts).
4. Descomprime, copia `app-debug.apk` al Note 9 y ábrelo (permite "instalar apps desconocidas").

## Etapa 2: IA en la nube (dos modos)
- **Directo:** la app llama a Gemini con la clave pegada en Ajustes (DataStore, solo en el teléfono).
- **Backend:** si hay token, la app usa el Worker de `backend/worker.js` (la clave vive en Cloudflare).
- Selección automática: `ai/HybridAiProvider.kt`. Proveedor intercambiable: `ai/AiProvider.kt`.
- Al reinstalar una nueva compilación debug, desinstala antes la anterior (la firma cambia).

## v0.2.0
- Logo minimalista (vector) + ícono adaptable de la app.
- Historial de chats con Room (abrir, borrar, nuevo chat).
- Reintentos automáticos y cambio de modelo si Gemini está saturado (503) o no disponible (404).
- Markdown básico, botón copiar, indicador de escritura, animaciones de entrada.
- Se quitaron del menú de Ajustes los controles que aún no hacían nada (memoria, voz); vuelven con sus etapas.

## v0.3.0
- **Control del teléfono** (`actions/`): abrir apps, YouTube, música, web, mapas, marcador, SMS (solo prepara), alarmas, temporizadores, volumen, brillo, linterna, batería, fecha y ajustes.
- **Accesibilidad** (`service/NexusAccessibilityService.kt`): leer pantalla, tocar texto, escribir, desplazar, atrás/inicio/recientes/notificaciones/captura/bloqueo. Nunca lee ni escribe en campos de contraseña. Con confirmación por defecto.
- **Modos de pensar:** Rápido, Equilibrado, Profundo y Código (cambian prompt, orden de modelos y longitud).
- **Código avanzado:** bloques con resaltado de sintaxis y botón copiar.
- **Visual:** fondo de auroras, burbujas con degradado, efecto de escritura, vibración al enviar.
- Protocolo de acciones por texto `[[ACTION {...}]]`, independiente del modelo.
- La pantalla Voz queda marcada "muy pronto" hasta implementar reconocimiento y síntesis.

## v0.4.0
- **Voz** (`voice/VoiceEngine.kt`): dictado en el chat, conversación manos libres en la pestaña Voz (escucha, piensa, responde hablando y vuelve a escuchar), leer cualquier respuesta con el botón de altavoz. Ajustes: voz, velocidad, tono y lectura automática.
- **Imágenes** (`images/ImageGenerator.kt`): herramienta `generate_image`. Usa Gemini (gemini-2.5-flash-image) con tu clave y, si no está disponible, Pollinations (sin clave; la descripción se envía a ese servicio). Guardar en Imágenes/NEXUS y compartir.
- El reconocimiento de voz de Android usa el servicio de Google y necesita internet; las voces de síntesis son las instaladas en el teléfono.

## v0.5.0 — Asistente de sistema, IA local/híbrida, agente y memoria

### 1. Integración nativa y segundo plano
- **Panel flotante** (`ui/assist/AssistActivity.kt`): se abre sobre cualquier app y conversa por voz sin abrir NEXUS completo.
- **Asistente digital del sistema** (`service/NexusVoiceService.kt`): en Ajustes > «Elegir como asistente» (o Ajustes del teléfono > Apps predeterminadas > Asistente) selecciona NEXUS; el gesto/botón de asistente del sistema abre el panel.
- **Doble toque de volumen** (Vol+ o Vol−, ventana de 350 ms, con la pantalla encendida): lo detecta el servicio de accesibilidad. El primer toque mueve el volumen un paso y el gesto lo deshace. Actívalo en Ajustes > Invocar a NEXUS (requiere accesibilidad). Se recomienda conceder «Mostrar sobre otras apps».
- **Mosaico de Ajustes rápidos** «NEXUS» y **acceso directo** «Hablar con NEXUS» (mantén pulsado el ícono de la app).
- No hay palabra de activación siempre-escuchando: Android no lo permite a apps normales sin gastar mucha batería.

### 2. Núcleo de IA
- **Ruta de IA** (Ajustes > IA y privacidad): *Automático* (nube con conexión; modelo local sin internet o si la nube falla), *Privado (local)* (nada sale del teléfono; sin herramientas web ni imágenes) y *Solo nube*.
- **IA local** (`ai/LocalAiProvider.kt`, MediaPipe LLM Inference): elige en Ajustes un modelo Gemma `.task` (p. ej. Gemma 3 1B int4). Se copia al almacenamiento privado. Sin herramientas: es conversación privada con memoria.
- **Multimodal**: botón de imagen en el chat (analiza fotos con Gemini) y herramienta `listen_environment` (graba 2–20 s de audio ambiente y la IA lo analiza; siempre pide permiso). Vídeo en tiempo real: no incluido.
- **Agente**: hasta 12 pasos encadenados, botón **Detener**, estado en vivo («Leyendo la pantalla…»). Herramientas nuevas que resuelven sin abrir otras apps: `get_weather` (Open-Meteo), `web_lookup` (Wikipedia), `fetch_url`, `wait`.
- Sin suscripciones: todo usa tu propia clave gratuita de Gemini o el modelo local; no hay servidores propios ni cobros.

### 3. Memoria (`memory/MemoryStore.kt`)
- Tabla `memories` en Room (migración 1→2, no pierde tu historial). La IA guarda datos duraderos con `remember` y se inyectan en cada prompt.
- Ajustes > Memoria: ver, añadir, borrar uno o todo. No guarda contraseñas ni datos de tarjeta.
- Con IA en la nube los recuerdos viajan dentro de cada petición; en modo Privado no.

### 4. Diseño
- Tema oscuro AMOLED con capas de superficie y contornos afinados; «Colores del sistema» (Material You, solo Android 12+; el Note 9 con Android 10 usa la paleta violeta).
- Núcleo animado con transiciones suaves entre estados, puntos de escritura con ola, transiciones de navegación con deslizamiento, estado de proceso con fundido.

### Importante al actualizar
- **Redespliega `backend/worker.js`** si usas el modo backend (ahora recibe el prompt y los adjuntos de la app).
- Desinstala la versión debug anterior antes de instalar (la firma cambia).
- Esta versión **no se pudo compilar en el entorno donde se generó**; si Gradle marca un error, pásame el mensaje exacto.
- Dependencia nueva: `com.google.mediapipe:tasks-genai:0.10.24` (ARM64). Aumenta el tamaño del APK.


## v0.6.0 — rediseño visual y arreglos

- **Animación de entrada**: el logo se dibuja trazo a trazo, aparece el nombre «NEXUS» letra por letra y se disuelve hacia la app.
- **Logo nuevo**: hexágono de red con una «N» y nodos luminosos; ícono adaptable con fondo degradado e ícono monocromo (Android 13+).
- **Interfaz**: tipografía nueva, barra inferior animada, transiciones direccionales, burbujas con borde degradado, barra de escritura tipo píldora, orbe de voz con ondas que reacciona a tu voz.
- **Ya no se pide ningún modelo Gemma**: la IA en la nube funciona sin descargar nada. El modelo sin conexión quedó como opción avanzada y escondida (Ajustes > IA y privacidad > Avanzado). Si un ajuste antiguo estaba en «Privado» sin modelo, se usa la nube automáticamente.
- **Micrófono y doble volumen**: el reconocimiento de voz ahora se reinicia solo ante errores (ocupado, cliente, servidor), espera más tiempo a que termines de hablar, toma el foco de audio, y el doble toque de volumen abre el panel al soltar el botón para que el micrófono quede libre. El botón de la barra de chat muestra la onda de voz (abre la conversación por voz) cuando el cuadro está vacío.
