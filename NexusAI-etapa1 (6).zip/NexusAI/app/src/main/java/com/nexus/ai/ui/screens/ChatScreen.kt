package com.nexus.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.ai.ai.AiMode
import com.nexus.ai.ui.chat.ACTION_PREFIX
import com.nexus.ai.ui.chat.ChatMessage
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.components.CodeBlock
import com.nexus.ai.ui.components.CodeBlockView
import com.nexus.ai.ui.components.NexusLogo
import com.nexus.ai.ui.components.TextBlock
import com.nexus.ai.ui.components.TypingDots
import com.nexus.ai.ui.components.parseBlocks
import com.nexus.ai.ui.components.renderMarkdown
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Purple700
import com.nexus.ai.ui.theme.Violet500
import kotlinx.coroutines.delay

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val total = state.messages.size + (if (state.thinking) 1 else 0) + (if (state.error != null) 1 else 0)

    LaunchedEffect(total) {
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NexusLogo(Modifier.size(36.dp), animated = false)
            Text(
                "NEXUS",
                style = MaterialTheme.typography.titleLarge,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
            IconButton(onClick = { vm.newChat() }) {
                Icon(Icons.Filled.Add, contentDescription = "Nuevo chat")
            }
        }
        ModeRow(mode) { vm.setMode(it) }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(state.messages, key = { _, m -> m.id }) { index, m ->
                    MessageRow(
                        m,
                        animate = index == state.messages.lastIndex,
                        typewriter = m.id == state.liveId
                    )
                }
                if (state.thinking) {
                    item(key = "typing") { TypingBubble() }
                }
                state.error?.let { err ->
                    item(key = "error") { ErrorBubble(err, onRetry = { vm.retry() }) }
                }
            }
            if (state.messages.isEmpty() && !state.thinking && state.error == null) {
                EmptyState(onPick = { vm.send(it) })
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe a NEXUS…") },
                shape = RoundedCornerShape(24.dp),
                maxLines = 5
            )
            FilledIconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    vm.send(input)
                    input = ""
                },
                enabled = input.isNotBlank() && !state.thinking
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar") }
        }
    }
}

@Composable
private fun ModeRow(selected: AiMode, onSelect: (AiMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AiMode.entries.forEach { m ->
            ModePill(m.label, selected = m == selected) { onSelect(m) }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    val base = Modifier.clip(shape)
    val styled = if (selected) base.background(Brush.linearGradient(listOf(Violet500, Magenta)))
    else base.border(1.dp, cs.outline.copy(alpha = 0.5f), shape)
    Text(
        label,
        color = if (selected) Color.White else cs.onSurfaceVariant,
        style = MaterialTheme.typography.labelLarge,
        modifier = styled.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NexusLogo(Modifier.size(150.dp))
        Spacer(Modifier.height(16.dp))
        Text("Hola, soy NEXUS", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Pregúntame, créame código o pídeme que use tu teléfono.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        listOf(
            "Abre YouTube y busca música lo-fi",
            "Pon el volumen al 50%",
            "Escríbeme una app de notas en Kotlin"
        ).forEach {
            SuggestionPill(it) { onPick(it) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SuggestionPill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        text,
        color = MaterialTheme.colorScheme.tertiary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, MaterialTheme.colorScheme.outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    )
}

@Composable
private fun MessageRow(m: ChatMessage, animate: Boolean, typewriter: Boolean) {
    if (animate) {
        val visible = remember { MutableTransitionState(false).apply { targetState = true } }
        AnimatedVisibility(
            visibleState = visible,
            enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 4 }
        ) { MessageContent(m, typewriter) }
    } else {
        MessageContent(m, false)
    }
}

@Composable
private fun MessageContent(m: ChatMessage, typewriter: Boolean) {
    when {
        m.text.startsWith(ACTION_PREFIX) -> ActionChip(m.text)
        m.fromUser -> UserBubble(m.text)
        else -> AssistantBubble(m, typewriter)
    }
}

@Composable
private fun UserBubble(text: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                .background(Brush.linearGradient(listOf(Violet500, Purple700, Magenta.copy(alpha = 0.9f))))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text, color = Color.White)
        }
    }
}

@Composable
private fun ActionChip(text: String) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = cs.tertiary.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, cs.tertiary.copy(alpha = 0.25f))
    ) {
        Text(
            text,
            color = cs.tertiary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun AssistantBubble(m: ChatMessage, typewriter: Boolean) {
    val cs = MaterialTheme.colorScheme
    var shown by remember(m.id) { mutableIntStateOf(if (typewriter) 0 else m.text.length) }
    LaunchedEffect(m.id, typewriter) {
        if (typewriter) {
            val step = maxOf(5, m.text.length / 150)
            while (shown < m.text.length) {
                shown = minOf(m.text.length, shown + step)
                delay(16)
            }
        } else {
            shown = m.text.length
        }
    }
    val visible = m.text.take(shown)
    val blocks = remember(visible) { parseBlocks(visible) }
    val codeBg = cs.background.copy(alpha = 0.6f)

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
            color = cs.surfaceVariant.copy(alpha = 0.92f),
            border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.25f)),
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Column(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                blocks.forEach { b ->
                    when (b) {
                        is TextBlock -> {
                            if (b.md.isNotBlank()) {
                                Text(renderMarkdown(b.md.trimEnd(), codeBg), color = cs.onSurface)
                            }
                        }
                        is CodeBlock -> {
                            CodeBlockView(b.lang, b.code)
                        }
                    }
                }
            }
        }
        if (shown >= m.text.length) CopyButton(m.text)
    }
}

@Composable
private fun CopyButton(text: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    IconButton(
        onClick = { clipboard.setText(AnnotatedString(text)); copied = true },
        modifier = Modifier.size(32.dp)
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = "Copiar",
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TypingBubble() {
    Surface(
        shape = RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        TypingDots(Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
    }
}

@Composable
private fun ErrorBubble(message: String, onRetry: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
            TextButton(onClick = onRetry) { Text("Reintentar") }
        }
    }
}
