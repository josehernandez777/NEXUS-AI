package com.nexus.ai.data

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

data class GPart(val text: String? = null)
data class GContent(val role: String? = null, val parts: List<GPart>? = null)
data class GGenConfig(val maxOutputTokens: Int, val temperature: Float)
data class GRequest(
    val systemInstruction: GContent,
    val contents: List<GContent>,
    val generationConfig: GGenConfig? = null
)
data class GCandidate(val content: GContent? = null)
data class GResponse(val candidates: List<GCandidate>? = null)

interface GeminiApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generate(
        @Path("model") model: String,
        @Header("x-goog-api-key") key: String,
        @Body body: GRequest
    ): GResponse
}
