package com.nexus.ai.data

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

/** Un turno de la conversación (role: "user" o "assistant"). */
data class ChatTurn(val role: String, val content: String)
data class ChatRequest(val messages: List<ChatTurn>)
data class ChatResponse(val reply: String? = null, val error: String? = null)

interface NexusApi {
    @POST
    suspend fun chat(
        @Url url: String,
        @Header("X-App-Token") token: String,
        @Body body: ChatRequest
    ): ChatResponse
}
