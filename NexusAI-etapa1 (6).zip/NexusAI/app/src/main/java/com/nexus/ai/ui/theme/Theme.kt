package com.nexus.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Violet500,
    onPrimary = Color.White,
    secondary = Magenta,
    tertiary = Violet300,
    background = AmoledBlack,
    onBackground = Color(0xFFEDE9FE),
    surface = SurfaceDark,
    onSurface = Color(0xFFEDE9FE),
    surfaceVariant = SurfaceDark2,
    onSurfaceVariant = Violet300,
)

private val LightColors = lightColorScheme(
    primary = Purple700,
    onPrimary = Color.White,
    secondary = Magenta,
    tertiary = Violet500,
    background = LightBg,
    surface = Color.White,
    surfaceVariant = Color(0xFFEDE5FF),
    onSurfaceVariant = Purple700,
)

@Composable
fun NexusTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
