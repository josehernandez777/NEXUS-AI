package com.nexus.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nexus_settings")

// La URL del Worker no es secreta; se puede cambiar en Ajustes.
private const val DEFAULT_URL = "https://misty-frost-3862.josehernandezochoa876.workers.dev"

data class BackendConfig(
    val url: String = "",
    val token: String = "",
    val geminiKey: String = ""
)

data class UiPrefs(
    val mode: String = "EQUILIBRADO",
    val confirm: Boolean = true,
    val aurora: Boolean = true
)

class SettingsRepo(private val context: Context) {
    private val keyUrl = stringPreferencesKey("backend_url")
    private val keyToken = stringPreferencesKey("backend_token")
    private val keyGemini = stringPreferencesKey("gemini_api_key")
    private val keyMode = stringPreferencesKey("mode")
    private val keyConfirm = booleanPreferencesKey("confirm_actions")
    private val keyAurora = booleanPreferencesKey("aurora")

    val config: Flow<BackendConfig> = context.dataStore.data.map {
        BackendConfig(it[keyUrl] ?: DEFAULT_URL, it[keyToken] ?: "", it[keyGemini] ?: "")
    }

    val prefs: Flow<UiPrefs> = context.dataStore.data.map {
        UiPrefs(it[keyMode] ?: "EQUILIBRADO", it[keyConfirm] ?: true, it[keyAurora] ?: true)
    }

    suspend fun save(c: BackendConfig) {
        context.dataStore.edit {
            it[keyUrl] = c.url.trim()
            it[keyToken] = c.token.trim()
            it[keyGemini] = c.geminiKey.trim()
        }
    }

    suspend fun setMode(mode: String) { context.dataStore.edit { it[keyMode] = mode } }
    suspend fun setConfirm(value: Boolean) { context.dataStore.edit { it[keyConfirm] = value } }
    suspend fun setAurora(value: Boolean) { context.dataStore.edit { it[keyAurora] = value } }
}
