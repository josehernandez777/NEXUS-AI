package com.nexus.ai.data

import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object Net {
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private fun retrofit(baseUrl: String): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    /** Modo backend: la URL real se pasa con @Url desde Ajustes. */
    val api: NexusApi by lazy { retrofit("https://localhost/").create(NexusApi::class.java) }

    /** Modo directo: llamadas a Gemini con la clave del usuario. */
    val gemini: GeminiApi by lazy {
        retrofit("https://generativelanguage.googleapis.com/").create(GeminiApi::class.java)
    }
}
