package com.nexus.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet500

/** Logo minimalista de NEXUS: anillo de cuatro arcos + "N" con degradado neón. */
@Composable
fun NexusLogo(modifier: Modifier = Modifier.size(120.dp), animated: Boolean = true) {
    val t = rememberInfiniteTransition(label = "logo")
    val glowAnim by t.animateFloat(
        0.55f, 1f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val rotAnim by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(24000, easing = LinearEasing)),
        label = "rot"
    )

    Canvas(modifier) {
        val glow = if (animated) glowAnim else 1f
        val rot = if (animated) rotAnim else 0f
        val w = size.minDimension
        val c = center
        val brush = Brush.linearGradient(
            listOf(Cyan400, Violet500, Magenta),
            Offset(0f, 0f),
            Offset(size.width, size.height)
        )
        val ringR = w * 0.44f
        val sw = w * 0.032f
        val arcTopLeft = Offset(c.x - ringR, c.y - ringR)
        val arcSize = Size(ringR * 2, ringR * 2)

        rotate(rot, pivot = c) {
            for (k in 0 until 4) {
                val start = k * 90f - 27f
                drawArc(
                    brush = brush, startAngle = start, sweepAngle = 54f, useCenter = false,
                    topLeft = arcTopLeft, size = arcSize, alpha = 0.22f * glow,
                    style = Stroke(sw * 3.5f, cap = StrokeCap.Round)
                )
                drawArc(
                    brush = brush, startAngle = start, sweepAngle = 54f, useCenter = false,
                    topLeft = arcTopLeft, size = arcSize,
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }

        val nx = ringR * 0.55f
        val ny = ringR * 0.78f
        val path = Path().apply {
            moveTo(c.x - nx, c.y + ny)
            lineTo(c.x - nx, c.y - ny)
            lineTo(c.x + nx, c.y + ny)
            lineTo(c.x + nx, c.y - ny)
        }
        drawPath(
            path, brush, alpha = 0.22f * glow,
            style = Stroke(sw * 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(path, brush, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))

        val dots = listOf(
            Offset(c.x - nx, c.y - ny), Offset(c.x + nx, c.y - ny),
            Offset(c.x - nx, c.y + ny), Offset(c.x + nx, c.y + ny)
        )
        for (p in dots) drawCircle(color = Color.White, radius = sw * 0.8f, center = p)
    }
}
