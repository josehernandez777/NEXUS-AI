package com.nexus.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nexus.ai.ui.components.AiCore
import com.nexus.ai.ui.components.CoreState

/** La voz real (reconocimiento + síntesis en español) llega en la siguiente versión. */
@Composable
fun VoiceScreen() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically)
    ) {
        AiCore(CoreState.IDLE, Modifier.size(240.dp))
        Text("Voz — muy pronto", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.tertiary)
        Text(
            "Muy pronto podrás hablar con NEXUS en español y escuchar sus respuestas.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
