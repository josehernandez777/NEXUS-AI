package com.nexus.ai.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.data.BackendConfig
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.data.UiPrefs
import com.nexus.ai.data.db.NexusDb
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val dao = NexusDb.get(app).chatDao()

    val config: StateFlow<BackendConfig?> =
        repo.config.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val prefs: StateFlow<UiPrefs> =
        repo.prefs.stateIn(viewModelScope, SharingStarted.Eagerly, UiPrefs())

    fun save(url: String, token: String, geminiKey: String) {
        viewModelScope.launch { repo.save(BackendConfig(url, token, geminiKey)) }
    }

    fun setConfirm(value: Boolean) {
        viewModelScope.launch { repo.setConfirm(value) }
    }

    fun setAurora(value: Boolean) {
        viewModelScope.launch { repo.setAurora(value) }
    }

    fun clearHistory() {
        viewModelScope.launch { dao.deleteAll() }
    }
}
