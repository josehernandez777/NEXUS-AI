package com.nexus.ai.ai

import com.nexus.ai.data.ChatTurn
import com.nexus.ai.data.GContent
import com.nexus.ai.data.GGenConfig
import com.nexus.ai.data.GPart
import com.nexus.ai.data.GRequest
import com.nexus.ai.data.GeminiApi
import com.nexus.ai.data.SettingsRepo
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import retrofit2.HttpException

/** Modo directo: la app llama a Gemini con la clave que el usuario pegó en Ajustes. */
class GeminiAiProvider(
    private val api: GeminiApi,
    private val settings: SettingsRepo
) : AiProvider {

    override suspend fun reply(history: List<ChatTurn>, options: AiOptions): Result<String> {
        val key = settings.config.first().geminiKey.trim()
        if (key.isEmpty()) return Result.failure(AiError.NotConfigured)
        val contents = toContents(history)
        if (contents.isEmpty()) return Result.failure(AiError.Server("mensaje vacío"))
        val req = GRequest(
            GContent(null, listOf(GPart(options.system))),
            contents,
            GGenConfig(options.maxTokens, options.temperature)
        )

        var last: Result<String> = Result.failure(AiError.ModelNotFound)
        for (model in options.models) {
            var attempt = 0
            while (true) {
                val r = call(model, key, req)
                if (r.isSuccess) return r
                last = r
                val err = r.exceptionOrNull()
                val transient = err === AiError.Busy || err === AiError.Network
                if (transient && attempt < 1) {
                    attempt++
                    delay(1500L)
                    continue
                }
                if (err === AiError.ModelNotFound || err === AiError.Busy || err === AiError.Quota) break
                return r
            }
        }
        return last
    }

    private suspend fun call(model: String, key: String, req: GRequest): Result<String> {
        return try {
            val res = api.generate(model, key, req)
            val text = res.candidates?.firstOrNull()?.content?.parts
                ?.joinToString("") { it.text ?: "" }
            if (text.isNullOrBlank()) Result.failure(AiError.Server("Gemini no devolvió texto"))
            else Result.success(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            val code = e.code()
            val detail = errorDetail(e)
            when {
                code == 404 -> Result.failure(AiError.ModelNotFound)
                code == 429 -> Result.failure(AiError.Quota)
                code == 500 || code == 502 || code == 503 || code == 504 -> Result.failure(AiError.Busy)
                detail.contains("API key", ignoreCase = true) -> Result.failure(AiError.InvalidKey)
                else -> Result.failure(AiError.Server("HTTP $code $detail".trim()))
            }
        } catch (e: IOException) {
            Result.failure(AiError.Network)
        } catch (e: Exception) {
            Result.failure(AiError.Server("respuesta no válida"))
        }
    }

    private suspend fun errorDetail(e: HttpException): String = withContext(Dispatchers.IO) {
        try {
            val body = e.response()?.errorBody()?.string().orEmpty()
            Regex("\"message\"\\s*:\\s*\"([^\"]+)\"").find(body)?.groupValues?.get(1)?.take(160) ?: ""
        } catch (ex: Exception) {
            ""
        }
    }

    /** Gemini exige alternar user/model, empezando por user: unimos turnos seguidos del mismo rol. */
    private fun toContents(history: List<ChatTurn>): List<GContent> {
        val out = mutableListOf<Pair<String, StringBuilder>>()
        for (t in history) {
            val role = if (t.role == "assistant") "model" else "user"
            val text = t.content.take(4000)
            if (text.isBlank()) continue
            val last = out.lastOrNull()
            if (last != null && last.first == role) last.second.append("\n").append(text)
            else out.add(role to StringBuilder(text))
        }
        while (out.isNotEmpty() && out.first().first != "user") out.removeAt(0)
        return out.map { GContent(it.first, listOf(GPart(it.second.toString()))) }
    }
}
