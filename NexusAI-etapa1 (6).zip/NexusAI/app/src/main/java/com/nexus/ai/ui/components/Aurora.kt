package com.nexus.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.nexus.ai.ui.theme.Cyan400
import com.nexus.ai.ui.theme.Magenta
import com.nexus.ai.ui.theme.Violet500

/** Fondo de auroras suaves que se mueven despacio sobre negro AMOLED. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.radialGradient(
                listOf(Violet500.copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.1f + 0.6f * a), h * (0.12f + 0.12f * b)),
                radius = w * 0.95f
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(Cyan400.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(w * (0.9f - 0.5f * b), h * (0.85f - 0.15f * a)),
                radius = w * 0.9f
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(Magenta.copy(alpha = 0.12f), Color.Transparent),
                center = Offset(w * (0.2f + 0.4f * b), h * (0.55f + 0.1f * a)),
                radius = w * 0.8f
            )
        )
    }
}
