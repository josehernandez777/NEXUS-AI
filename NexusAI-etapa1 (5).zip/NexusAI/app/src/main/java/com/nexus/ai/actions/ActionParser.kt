package com.nexus.ai.actions

import com.google.gson.JsonObject
import com.google.gson.JsonParser

data class ParsedAction(val tool: String, val args: JsonObject)
data class Parsed(val text: String, val actions: List<ParsedAction>)

fun JsonObject.str(key: String): String? {
    val e = get(key) ?: return null
    return if (e.isJsonPrimitive) e.asString else null
}

fun JsonObject.num(key: String): Double? = str(key)?.toDoubleOrNull()

fun JsonObject.bool(key: String): Boolean? = str(key)?.lowercase()?.let { it == "true" }

object ActionParser {
    private val re = Regex("""\[\[ACTION\s*(\{.*?\})\s*\]\]""", RegexOption.DOT_MATCHES_ALL)

    fun parse(raw: String): Parsed {
        val actions = mutableListOf<ParsedAction>()
        for (m in re.findAll(raw)) {
            try {
                val o = JsonParser.parseString(m.groupValues[1]).asJsonObject
                val tool = o.get("tool")?.asString
                if (tool != null) {
                    val args = o.getAsJsonObject("args") ?: JsonObject()
                    actions.add(ParsedAction(tool, args))
                }
            } catch (e: Exception) {
                // acción mal formada: se ignora
            }
        }
        return Parsed(re.replace(raw, "").trim(), actions)
    }
}
