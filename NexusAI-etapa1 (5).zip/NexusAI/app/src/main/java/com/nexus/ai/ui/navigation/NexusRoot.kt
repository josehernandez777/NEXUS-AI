package com.nexus.ai.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nexus.ai.ui.chat.ChatViewModel
import com.nexus.ai.ui.components.AuroraBackground
import com.nexus.ai.ui.screens.ChatScreen
import com.nexus.ai.ui.screens.HistoryScreen
import com.nexus.ai.ui.screens.SettingsScreen
import com.nexus.ai.ui.screens.SettingsViewModel
import com.nexus.ai.ui.screens.VoiceScreen

private enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Chat("chat", "Chat", Icons.Filled.Chat),
    History("history", "Historial", Icons.Filled.History),
    Voice("voice", "Voz", Icons.Filled.Mic),
    Settings("settings", "Ajustes", Icons.Filled.Settings)
}

@Composable
fun NexusRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    // ViewModel compartido entre Chat e Historial (ligado a la actividad).
    val chatVm: ChatViewModel = viewModel()
    val settingsVm: SettingsViewModel = viewModel()
    val prefs by settingsVm.prefs.collectAsStateWithLifecycle()
    val pending by chatVm.pending.collectAsStateWithLifecycle()
    val dark = isSystemInDarkTheme()

    fun navigateTo(route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (prefs.aurora && dark) AuroraBackground()

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.88f)) {
                    Dest.entries.forEach { d ->
                        NavigationBarItem(
                            selected = current == d.route,
                            onClick = { navigateTo(d.route) },
                            icon = { Icon(d.icon, contentDescription = d.label) },
                            label = { Text(d.label) }
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Dest.Chat.route,
                modifier = Modifier.padding(padding).consumeWindowInsets(padding),
                enterTransition = { fadeIn(tween(250)) },
                exitTransition = { fadeOut(tween(250)) }
            ) {
                composable(Dest.Chat.route) { ChatScreen(chatVm) }
                composable(Dest.History.route) {
                    HistoryScreen(chatVm, onOpened = { navigateTo(Dest.Chat.route) })
                }
                composable(Dest.Voice.route) { VoiceScreen() }
                composable(Dest.Settings.route) { SettingsScreen() }
            }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { chatVm.answerPending(false) },
            title = { Text("NEXUS quiere actuar") },
            text = { Text(p.description) },
            confirmButton = {
                TextButton(onClick = { chatVm.answerPending(true) }) { Text("Permitir") }
            },
            dismissButton = {
                TextButton(onClick = { chatVm.answerPending(false) }) { Text("Cancelar") }
            }
        )
    }
}
